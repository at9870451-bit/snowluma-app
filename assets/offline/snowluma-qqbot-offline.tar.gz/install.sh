#!/usr/bin/env bash
# SnowLuma + QQBot 离线一键部署脚本
# 适用：Debian/Ubuntu/Debian 系 Linux（树莓派/NUC/家用服务器）
# 用法：sudo bash install.sh
set -euo pipefail

GREEN='\033[0;32m'; YELLOW='\033[1;33m'; RED='\033[0;31m'; NC='\033[0m'
log()  { echo -e "${GREEN}[+]${NC} $*"; }
warn() { echo -e "${YELLOW}[!]${NC} $*"; }
die()  { echo -e "${RED}[x]${NC} $*"; exit 1; }

[ "$(id -u)" -eq 0 ] || die "请用 root 运行：sudo bash install.sh"

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
QQBOT_DIR="/opt/qqbot"
SANDBOX_DIR="/opt/sandbox"

log "1/7 检查系统与依赖"
command -v python3 >/dev/null || die "缺少 python3，请先安装：apt install -y python3 python3-pip"
if ! command -v docker >/dev/null; then
  warn "未检测到 Docker，尝试安装…"
  curl -fsSL https://get.docker.com | sh || die "Docker 安装失败，请手动安装"
fi
systemctl enable --now docker || true

log "2/7 部署 QQBot 程序"
if [ ! -d "$QQBOT_DIR" ]; then
  mkdir -p "$QQBOT_DIR"
fi
if [ -f "$HERE/qqbot.tar.gz" ]; then
  tar -xzf "$HERE/qqbot.tar.gz" -C /opt
  log "QQBot 已解压到 $QQBOT_DIR"
else
  warn "未找到 qqbot.tar.gz，跳过解压（如已安装可忽略）"
fi
cd "$QQBOT_DIR"
python3 -m venv .venv 2>/dev/null || true
[ -f requirements.txt ] && .venv/bin/pip install -q -r requirements.txt || true

log "3/7 安装 QQBot systemd 服务"
cat > /etc/systemd/system/qqbot.service <<'EOF'
[Unit]
Description=QQBot 2.0
After=network-online.target docker.service
Wants=network-online.target

[Service]
Type=simple
WorkingDirectory=/opt/qqbot
ExecStart=/usr/bin/python3 /opt/qqbot/run.py --no-tray
Restart=always
RestartSec=5
Environment=PYTHONUNBUFFERED=1

[Install]
WantedBy=multi-user.target
EOF
mkdir -p /etc/systemd/system/qqbot.service.d
cat > /etc/systemd/system/qqbot.service.d/startlimit.conf <<'EOF'
[Unit]
StartLimitIntervalSec=0
[Service]
Restart=always
RestartSec=5
EOF
systemctl daemon-reload
systemctl enable qqbot

log "4/7 启动 SnowLuma 容器（内置 NapCat/OneBot）"
if docker ps -a --format '{{.Names}}' | grep -qx snowluma; then
  docker start snowluma
else
  docker run -d --name snowluma --restart unless-stopped \
    -p 3000:3000 -p 3001:3001 -p 5099:5099 -p 6081:6081 -p 5900:5900 \
    motricseven7/snowluma:latest || warn "容器启动失败，请检查镜像是否已离线导入"
fi

log "5/7 建立沙盒 rootfs 目录"
mkdir -p "$SANDBOX_DIR"/{bin,usr/bin,etc,opt,root,tmp,home}
[ -x /usr/bin/python3 ] && ln -sf /usr/bin/python3 "$SANDBOX_DIR/usr/bin/python3"
[ -x /usr/bin/openssl ] && ln -sf /usr/bin/openssl "$SANDBOX_DIR/usr/bin/openssl"
[ -x /usr/bin/git ] && ln -sf /usr/bin/git "$SANDBOX_DIR/usr/bin/git"

log "6/7 启动 QQBot"
systemctl restart qqbot
sleep 5
systemctl is-active qqbot >/dev/null && log "QQBot 运行中" || warn "QQBot 启动异常，查看：journalctl -u qqbot -n 50"

log "7/7 完成！局域网访问地址："
IP=$(hostname -I 2>/dev/null | awk '{print $1}')
echo
echo "  控制面板:  http://${IP}:6199"
echo "  OneBot WS: ws://${IP}:3001"
echo "  AI 网关:   http://${IP}:8090（如有）"
echo
echo "在 SnowLuma App 的「接入」页填写：http://${IP}:6199"
echo "然后在面板「AI 配置」里填本机 AI 接口，即可开始使用。"
echo
