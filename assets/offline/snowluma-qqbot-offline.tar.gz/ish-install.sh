#!/bin/sh
# SnowLuma + QQBot — iSH (iPhone/iPad) 沙盒安装脚本
# 用法：在 iSH 里执行
#   sh ish-install.sh
# 说明：iSH 是 Alpine Linux（x86 模拟），本脚本安装 Python 环境并启动 QQBot 服务。
#       QQ 消息协议端（NapCat）无法在 iSH 内运行，需另行解决。

set -e
echo "[1/6] 更新 apk 索引"
apk update

echo "[2/6] 安装基础组件（busybox 自带，补 python/curl/tar）"
apk add --no-cache python3 py3-pip curl tar git openssl || true

echo "[3/6] 解压 QQBot"
mkdir -p /opt/qqbot
if [ -f ./qqbot.tar.gz ]; then
  tar -xzf ./qqbot.tar.gz -C /opt
else
  echo "!! 未找到 qqbot.tar.gz（请与 ish-install.sh 放在同一目录）"
  exit 1
fi

echo "[4/6] 安装 Python 依赖"
cd /opt/qqbot
pip3 install --break-system-packages -q httpx websockets 2>/dev/null || \
  pip3 install -q httpx websockets || true
if [ -f requirements.txt ]; then
  pip3 install --break-system-packages -q -r requirements.txt 2>/dev/null || \
    pip3 install -q -r requirements.txt || true
fi

echo "[5/6] 创建沙盒目录"
mkdir -p /opt/sandbox/{bin,usr/bin,etc,opt,root,tmp,home}
ln -sf /usr/bin/python3 /opt/sandbox/usr/bin/python3 2>/dev/null || true
ln -sf /usr/bin/openssl /opt/sandbox/usr/bin/openssl 2>/dev/null || true

echo "[6/6] 启动 QQBot（前台运行，Ctrl+C 停止）"
echo "    面板地址: http://127.0.0.1:6199"
echo "    在 SnowLuma App「接入」页填: http://127.0.0.1:6199"
cd /opt/qqbot
exec python3 run.py --no-tray
