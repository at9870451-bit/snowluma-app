# SnowLuma + QQBot 离线部署包

## 适用设备
Debian/Ubuntu 系 Linux（树莓派、NUC、家用服务器、云主机均可）

## 安装步骤
1. 把本目录整个拷贝到目标设备（U 盘/scp 均可）
2. 执行：sudo bash install.sh
3. 脚本结束后会打印局域网地址，例如 http://192.168.1.50:6199
4. 打开 SnowLuma App →「接入」→ 填 http://192.168.1.50:6199
5. 面板「AI 配置」里填好模型接口即可使用

## 包含内容
- install.sh       一键安装脚本（Docker + QQBot + systemd + 沙盒目录）
- qqbot.tar.gz     QQBot 程序（已排除 data/日志/缓存）
- README.md        本说明

## 注意事项
- 需要设备能访问 Docker Hub 拉取 SnowLuma 镜像；
  完全离线环境请先在有网机器 docker save 镜像再 docker load
- 首次启动 QQ 需在容器内扫码/密码登录（端口 5099 的 noVNC 或 App 扫码页）
- 开机自启：qqbot.service 与 snowluma 容器均已设置

## iPhone / iPad（iSH）
1. App Store 安装 iSH
2. 把 snowluma-qqbot-offline.tar.gz 导出到「文件」App，iSH 里用 mount 访问
3. 解压后执行：sh ish-install.sh
4. 面板 http://127.0.0.1:6199（SnowLuma App 接入页填这个地址）
注意：iSH 无法运行 NapCat，QQ 消息协议端需另配；iOS 会挂起长时间后台的 iSH。
