"""便捷启动脚本（源码运行 / 开机自启命令均指向此文件）。"""

from __future__ import annotations

import json
import os
import re
import sys
from pathlib import Path


def _activate_update_overlay() -> None:
    """启动前挂载增量更新目录。

    打包后的 exe 体积大、更新频繁；更新包只带改动过的代码与页面，落在
    data/updates/<版本>/ 下，这里把它交给 qqbot 优先加载，避免每次重装 exe。
    """
    root = (
        Path(sys.executable).resolve().parent
        if getattr(sys, "frozen", False)
        else Path(__file__).resolve().parent
    )
    preset = os.environ.get("QQBOT_UPDATE_DIR")
    if preset:
        overlay = Path(preset)
        version = os.environ.get("QQBOT_UPDATE_VERSION") or overlay.name
    else:
        try:
            info = json.loads((root / "data" / "updates" / "current.json").read_text("utf-8"))
        except (OSError, ValueError):
            return
        version = str(info.get("version") or "")
        overlay = root / "data" / "updates" / version
    if not re.fullmatch(r"[0-9A-Za-z._-]{1,32}", version or ""):
        return
    if not (overlay / "qqbot").is_dir():
        return
    os.environ["QQBOT_UPDATE_DIR"] = str(overlay)
    os.environ["QQBOT_UPDATE_VERSION"] = version
    # 静态页面与手机页面在更新时已完整复制到覆盖目录，直接整体切换
    if (overlay / "qqbot" / "webui" / "static").is_dir():
        os.environ["QQBOT_RESOURCE_ROOT"] = str(overlay)


# 源码运行时把项目根加入模块搜索路径并切换工作目录；
# 打包为 exe 后由 PyInstaller 处理路径，无需干预。
if not getattr(sys, "frozen", False):
    _ROOT = Path(__file__).resolve().parent
    sys.path.insert(0, str(_ROOT))
    os.chdir(_ROOT)

_activate_update_overlay()

from qqbot.main import main  # noqa: E402

if __name__ == "__main__":
    sys.exit(main())
