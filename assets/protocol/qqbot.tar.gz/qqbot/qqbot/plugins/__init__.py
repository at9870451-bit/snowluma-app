"""插件系统。"""

from .base import Plugin
from .manager import PluginManager

__all__ = ["Plugin", "PluginManager"]