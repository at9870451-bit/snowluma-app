/* QQBot 移动控制台 */
(function () {
  "use strict";

  const $ = id => document.getElementById(id);
  const PAGES = {
    home: ["总览", "机器人运行状态"],
    qq: ["登录 QQ", "扫码或免密登录"],
    ai: ["AI 与生图", "模型与出图设置"],
    kb: ["知识库", "给群聊准备可检索的资料"],
    mem: ["记忆库", "长期记住群聊与用户信息"],
    stk: ["表情包", "导入与管理表情包"],
    auto: ["自主模式", "被戳 / @ / 关键词时主动回应"],
    safe: ["安全模式", "全局发送节流，降低风控风险"],
    console: ["置控台", "按群开关 AI、人物绑定、身份规则与异常通知"],
    omni: ["全能动作", "自定义触发条件，命中后由 AI 执行动作"],
    adm: ["白话群管", "自然语言下群管理指令"],
    plugins: ["插件", "加载与启停"],
    logs: ["运行日志", "实时查看"],
    settings: ["设置", "运行控制与后台常驻"],
  };

  const state = {
    page: "home",
    status: null,
    qq: null,
    config: null,
    qqTimer: null,
    logTimer: null,
    accountsLoaded: false,
    qrUrl: "",
    admPerms: {},
  };

  const CRED_KEY = "qqbot.mobile.credentials";

  // 手机 App 里界面来自本地 asset，接口通过 Android 桥接转发，避免跨域与 Cookie 限制
  const USE_BRIDGE = location.protocol === "file:" && !!window.AndroidBridge;
  let API_BASE = "";
  if (USE_BRIDGE) {
    try {
      API_BASE = JSON.parse(window.AndroidBridge.getSavedConfig() || "{}").server || "";
    } catch (e) { API_BASE = ""; }
  }
  let bridgeSeq = 0;
  const bridgeWaiters = new Map();

  // 本地壳和远程控制端都用桥接，靠默认地址区分：本地壳永远是 127.0.0.1:6199
  const LOCAL_MODE = USE_BRIDGE && /^http:\/\/127\.0\.0\.1:6199\/?$/.test(API_BASE);

  window.__bridgeResponse = function (id, payload) {
    const waiter = bridgeWaiters.get(id);
    if (!waiter) return;
    bridgeWaiters.delete(id);
    waiter(payload || {});
  };

  function bridgeRequest(method, path, body, timeoutMs) {
    return new Promise((resolve, reject) => {
      if (!window.AndroidBridge) { reject(new Error("no bridge")); return; }
      const id = "r" + (++bridgeSeq);
      const timer = setTimeout(() => {
        if (bridgeWaiters.has(id)) {
          bridgeWaiters.delete(id);
          reject(new Error("timeout"));
        }
      }, Math.max(20000, Number(timeoutMs) || 0));
      bridgeWaiters.set(id, payload => { clearTimeout(timer); resolve(payload); });
      try {
        const text = body == null ? "" : (typeof body === "string" ? body : JSON.stringify(body));
        window.AndroidBridge.apiRequest(id, method || "GET", path, text);
      } catch (e) {
        clearTimeout(timer);
        bridgeWaiters.delete(id);
        reject(e);
      }
    });
  }

  function serverLabel() {
    if (LOCAL_MODE) return "本机 · 127.0.0.1:6199";
    if (API_BASE) return API_BASE.replace(/^https?:\/\//, "");
    return location.host || "未连接";
  }

  function hostLabel() {
    return LOCAL_MODE ? "本机服务" : "服务器";
  }

  function forceLogout() {
    if (USE_BRIDGE) {
      try { window.AndroidBridge.logout(); } catch (e) { /* ignore */ }
    } else {
      location.href = "/m/login";
    }
  }

  function toast(message) {
    const el = $("toast");
    el.textContent = message;
    el.classList.add("show");
    clearTimeout(el._timer);
    el._timer = setTimeout(() => el.classList.remove("show"), 2400);
  }

  function escapeHtml(value) {
    return String(value == null ? "" : value).replace(/[&<>"]/g, ch => ({
      "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;",
    }[ch]));
  }

  function fmtUptime(seconds) {
    let s = Math.floor(Number(seconds) || 0);
    if (!s) return "0 秒";
    const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60);
    if (h) return `${h} 小时 ${m} 分`;
    if (m) return `${m} 分 ${s % 60} 秒`;
    return `${s} 秒`;
  }

  async function api(path, options) {
    const opts = options || {};
    if (USE_BRIDGE) {
      let envelope;
      try {
        envelope = await bridgeRequest(opts.method || "GET", path, opts.body, opts.timeout);
      } catch (e) {
        return { ok: false, error: `无法连接${hostLabel()}` };
      }
      if (envelope.status === 401) {
        forceLogout();
        throw new Error("unauthorized");
      }
      const text = envelope.body || "";
      try {
        return JSON.parse(text);
      } catch (e) {
        return {
          ok: envelope.status >= 200 && envelope.status < 300,
          raw: text,
          error: envelope.error || "",
        };
      }
    }
    const request = Object.assign({ credentials: "same-origin" }, opts);
    if (request.body && typeof request.body === "object") {
      request.headers = Object.assign({ "Content-Type": "application/json" }, request.headers || {});
      request.body = JSON.stringify(request.body);
    }
    const response = await fetch(path, request);
    if (response.status === 401) {
      forceLogout();
      throw new Error("unauthorized");
    }
    const text = await response.text();
    try {
      return JSON.parse(text);
    } catch (e) {
      return { ok: response.ok, raw: text, error: response.ok ? "" : `HTTP ${response.status}` };
    }
  }

  async function apiText(path) {
    if (USE_BRIDGE) {
      try {
        const envelope = await bridgeRequest("GET", path, null);
        if (envelope.status === 401) {
          forceLogout();
          return "";
        }
        return envelope.body || "";
      } catch (e) {
        return "";
      }
    }
    const response = await fetch(path, { credentials: "same-origin" });
    if (response.status === 401) {
      forceLogout();
      return "";
    }
    return response.ok ? response.text() : "";
  }

  /* ---------- 抽屉与页面 ---------- */
  function openDrawer() {
    document.body.classList.add("drawer-open");
  }
  function closeDrawer() {
    document.body.classList.remove("drawer-open");
  }

  /* ---------- 侧边栏显示 ---------- */
  let navItems = [];

  function applyNavConfig(ui) {
    const nav = $("nav");
    if (!nav) return;
    const color = String((ui && ui.nav_text_color) || "").trim();
    if (color) nav.style.setProperty("--nav-text-color", color);
    else nav.style.removeProperty("--nav-text-color");
    const order = Array.isArray(ui && ui.nav_order) ? ui.nav_order : [];
    const hidden = new Set(Array.isArray(ui && ui.nav_hidden) ? ui.nav_hidden : []);
    const nodes = Array.from(nav.querySelectorAll(".nav-item[data-page]"));
    const map = {};
    nodes.forEach(el => { map[el.dataset.page] = el; });
    const done = new Set();
    order.forEach(key => {
      if (map[key] && !done.has(key)) { nav.appendChild(map[key]); done.add(key); }
    });
    nodes.forEach(el => { if (!done.has(el.dataset.page)) nav.appendChild(el); });
    nodes.forEach(el => { el.style.display = hidden.has(el.dataset.page) ? "none" : ""; });
  }

  function defaultNavItems() {
    return Object.keys(PAGES).map(page => ({
      page, title: (PAGES[page] || [page])[0], hidden: false,
    }));
  }

  async function loadNavConfig() {
    let ui = {};
    try {
      const c = await api("/api/config");
      ui = (c && c.ui) || {};
    } catch (e) { /* 默认布局 */ }
    applyNavConfig(ui);
    return ui;
  }

  async function loadNavSettings() {
    const ui = await loadNavConfig();
    const order = Array.isArray(ui.nav_order) ? ui.nav_order : [];
    const hidden = new Set(Array.isArray(ui.nav_hidden) ? ui.nav_hidden : []);
    const base = defaultNavItems();
    const ordered = [];
    order.forEach(key => {
      const item = base.find(x => x.page === key);
      if (item && !ordered.includes(item)) ordered.push(item);
    });
    base.forEach(item => { if (!ordered.includes(item)) ordered.push(item); });
    navItems = ordered.map(item => ({ ...item, hidden: hidden.has(item.page) }));
    const colorInput = $("mobile-nav-color");
    if (colorInput) {
      const color = String(ui.nav_text_color || "");
      colorInput.value = /^#[0-9a-fA-F]{6}$/.test(color) ? color : "#8ba0b3";
    }
    renderNavSettings();
  }

  function renderNavSettings() {
    const box = $("mobile-nav-config");
    if (!box) return;
    box.innerHTML = navItems.map((item, idx) => `
      <div class="row" style="align-items:center;gap:8px;padding:6px 0">
        <label class="check" style="flex:1;margin:0">
          <input type="checkbox" ${item.hidden ? "" : "checked"}
                 onchange="toggleNavItem(${idx}, this.checked)" /> ${escapeHtml(item.title)}
        </label>
        <button class="btn ghost sm" onclick="moveNavItem(${idx}, -1)">↑</button>
        <button class="btn ghost sm" onclick="moveNavItem(${idx}, 1)">↓</button>
      </div>`).join("");
  }

  function toggleNavItem(idx, shown) {
    if (navItems[idx]) navItems[idx].hidden = !shown;
  }

  function moveNavItem(idx, delta) {
    const to = idx + delta;
    if (to < 0 || to >= navItems.length) return;
    const item = navItems.splice(idx, 1)[0];
    navItems.splice(to, 0, item);
    renderNavSettings();
  }

  async function saveNavConfig() {
    const colorInput = $("mobile-nav-color");
    const ui = {
      nav_hidden: navItems.filter(x => x.hidden).map(x => x.page),
      nav_order: navItems.map(x => x.page),
      nav_text_color: colorInput ? colorInput.value : "",
    };
    applyNavConfig(ui);
    try {
      const d = await api("/api/config", { method: "PUT", body: { ui } });
      toast(d.ok ? "侧边栏设置已保存" : "保存失败");
    } catch (e) { toast("保存失败"); }
  }

  function gotoPage(page) {
    if (!PAGES[page]) return;
    state.page = page;
    document.querySelectorAll(".nav-item[data-page]").forEach(el => {
      el.classList.toggle("active", el.dataset.page === page);
    });
    document.querySelectorAll(".page").forEach(el => {
      el.classList.toggle("active", el.id === "page-" + page);
    });
    $("page-title").textContent = PAGES[page][0];
    $("page-sub").textContent = PAGES[page][1];
    closeDrawer();
    const container = $("pages");
    if (container) container.scrollTop = 0;

    if (page === "qq") {
      state.accountsLoaded = false;
      refreshQQ();
      startQQTimer();
    } else {
      stopQQTimer();
    }
    if (page === "ai") loadConfig();
    if (page === "kb") loadKb();
    if (page === "mem") loadMem();
    if (page === "stk") loadStickers();
    if (page === "auto") loadAuto();
    if (page === "safe") loadSafe();
    if (page === "console") loadConsole();
    if (page === "omni") loadOmni();
    if (page === "adm") loadAdm();
    if (page === "plugins") { loadPlugins(); loadNavSettings(); }
    if (page === "logs") {
      loadLogs();
      startLogTimer();
    } else {
      stopLogTimer();
    }
    if (page === "settings") {
      loadAndroidStatus();
      loadDiagnostics();
    }
  }

  function startQQTimer() {
    stopQQTimer();
    state.qqTimer = setInterval(refreshQQ, 3000);
  }
  function stopQQTimer() {
    if (state.qqTimer) clearInterval(state.qqTimer);
    state.qqTimer = null;
  }
  function startLogTimer() {
    stopLogTimer();
    state.logTimer = setInterval(() => {
      if (($("log-auto") || {}).checked) loadLogs();
    }, 4000);
  }
  function stopLogTimer() {
    if (state.logTimer) clearInterval(state.logTimer);
    state.logTimer = null;
  }

  /* ---------- 状态 ---------- */
  function setConn(mode, text) {
    const badge = $("conn-badge");
    badge.className = "conn " + mode;
    $("conn-text").textContent = text;
    const dot = $("drawer-dot");
    dot.style.background = mode === "online" ? "var(--ok)" : mode === "offline" ? "var(--err)" : "var(--warn)";
    $("drawer-conn-label").textContent = text;
  }

  async function refreshStatus() {
    try {
      const d = await api("/api/status");
      state.status = d;
      renderStatus(d);
      renderQQStat();
      setConn(d.connected ? "online" : d.running ? "waiting" : "offline",
        d.connected ? "在线" : d.running ? "等待连接" : "已停止");
      if (state.page === "home") refreshQqSummary();
    } catch (e) {
      const bridge = LOCAL_MODE ? androidBridge() : null;
      let local = null;
      if (bridge && bridge.getLocalStatus) {
        try { local = JSON.parse(bridge.getLocalStatus() || "{}"); } catch (ignored) { /* ignore */ }
      }
      if (local && local.error) {
        setConn("offline", "启动失败");
        $("home-status").textContent = "本地启动失败：" + local.error;
      } else if (local && !local.ready) {
        setConn("offline", "准备中");
        $("home-status").textContent = (local.message || "本地环境准备中")
          + (local.progress ? "（" + local.progress + "%）" : "");
      } else {
        setConn("offline", "连接失败");
        $("home-status").textContent = `无法连接${hostLabel()}`;
      }
    }
  }

  async function refreshQqSummary() {
    try {
      const d = await api("/api/qq/status");
      const status = d && d.ok ? (d.status || {}) : {};
      state.qq = {
        loggedIn: Boolean(status.isLogin) || status.loginPhase === "ready",
        phase: status.loginPhase || "",
      };
    } catch (e) {
      state.qq = null;
    }
    renderQQStat();
  }

  function renderStatus(d) {
    if (!d) return;
    const online = Boolean(d.connected);
    $("home-pill").className = "pill " + (online ? "ok" : "off");
    $("home-pill").innerHTML = '<i class="dot"></i>' + (online ? "在线" : d.running ? "等待连接" : "已停止");
    $("home-status").textContent = online ? "在线运行" : d.running ? "等待网关连接" : "机器人未运行";
    $("home-version").textContent = "v" + (d.version || "—");
    $("home-self").textContent = d.self_id || "—";
    $("home-backend").textContent = d.backend || "—";
    $("home-uptime").textContent = fmtUptime(d.uptime);
    $("stat-conn").textContent = online ? "已连接" : "未连接";
    $("stat-plugins").textContent = (d.plugins || []).length;
    $("stat-version").textContent = d.version || "—";
    $("drawer-server").textContent = serverLabel();
    $("drawer-version").textContent = "版本 " + (d.version || "—");
    $("drawer-auth").textContent = d.auth ? "已加密" : "无密码";
    $("set-server").textContent = LOCAL_MODE ? "手机本地运行" : (API_BASE || location.origin);
    $("set-version").textContent = d.version || "—";
    $("set-auth").textContent = d.auth ? "已开启访问密码" : "未设置";
    if (state.page === "home") loadHomeLogs();
  }

  function renderQQStat() {
    const qq = state.qq;
    const el = $("stat-qq");
    if (!el) return;
    if (!qq) { el.textContent = "—"; return; }
    el.textContent = qq.loggedIn ? "已登录" : qq.phase ? "未登录" : "未知";
  }

  async function refreshAll() {
    await refreshStatus();
    if (state.page === "qq") await refreshQQ();
  }

  async function loadHomeLogs() {
    try {
      const d = await api("/api/logs?limit=60");
      const lines = (d.lines || []).filter(Boolean).slice(-4).reverse();
      const box = $("home-logs");
      if (!lines.length) {
        box.innerHTML = '<div class="hint">暂无日志</div>';
        return;
      }
      box.innerHTML = lines.map(line => {
        const cls = /\[ERROR\]/.test(line) ? "err" : /\[WARNING\]/.test(line) ? "warn" : "";
        return `<div class="line ${cls}">${escapeHtml(line)}</div>`;
      }).join("");
    } catch (e) { /* ignore */ }
  }

  /* ---------- QQ 登录 ---------- */
  function readCred() {
    try {
      const raw = localStorage.getItem(CRED_KEY);
      return raw ? JSON.parse(raw) : null;
    } catch (e) { return null; }
  }
  function saveCred(uin, passwordMd5) {
    try { localStorage.setItem(CRED_KEY, JSON.stringify({ uin, passwordMd5 })); } catch (e) { /* ignore */ }
  }
  function clearCred() {
    try { localStorage.removeItem(CRED_KEY); } catch (e) { /* ignore */ }
  }
  function loadSavedCred() {
    const saved = readCred();
    if (!saved || !saved.uin) return;
    if (!$("qq-uin").value) $("qq-uin").value = saved.uin;
    $("qq-remember").checked = true;
    $("qq-pwd").placeholder = "已记住密码，留空直接登录";
  }

  function setQrMask(show, text) {
    const qr = $("qq-qr");
    qr.classList.toggle("show-mask", show);
    if (text) $("qq-mask-text").textContent = text;
  }

  async function loadQr(force) {
    try {
      const svg = await apiText(`/api/qq/qrcode.svg?t=${Date.now()}${force ? "&refresh=1" : ""}`);
      if (!svg || svg.indexOf("<svg") === -1) {
        setQrMask(true, "暂无二维码");
        state.qrUrl = "";
        return false;
      }
      if (state.qrUrl && state.qrUrl.indexOf("blob:") === 0) {
        URL.revokeObjectURL(state.qrUrl);
      }
      state.qrUrl = URL.createObjectURL(new Blob([svg], { type: "image/svg+xml" }));
      $("qq-qr-img").src = state.qrUrl;
      setQrMask(false);
      return true;
    } catch (e) {
      setQrMask(true, "暂无二维码");
      state.qrUrl = "";
      return false;
    }
  }

  async function refreshQr() {
    toast("正在刷新二维码…");
    const ok = await loadQr(true);
    if (ok) toast("二维码已刷新");
  }

  async function restartGateway() {
    toast("正在重启网关…");
    try {
      const d = await api("/api/qq/restart", { method: "POST" });
      toast(d.ok ? "已发起重启" : (d.error || "重启失败"));
      setTimeout(refreshQQ, 2000);
    } catch (e) {
      toast("重启失败");
    }
  }

  function friendlyQQError(error) {
    const text = String(error || "");
    if (!text) return `请确认${hostLabel()}已启动`;
    if (text.indexOf("未找到 NapCat") !== -1 || text.indexOf("网关还没起来") !== -1) {
      return "QQ 网关还没起来，可以稍等一会或点上方重启";
    }
    return text.length > 90 ? text.slice(0, 90) + "…" : text;
  }

  async function refreshQQ() {
    let d = null;
    try {
      d = await api("/api/qq/status");
    } catch (e) { /* ignore */ }
    const pill = $("qq-pill");
    if (!d || !d.ok) {
      state.qq = { loggedIn: false, phase: "", error: (d && d.error) || "网关不可用" };
      pill.className = "pill off";
      pill.innerHTML = '<i class="dot"></i>异常';
      $("qq-name").textContent = "无法连接网关";
      $("qq-sub").textContent = friendlyQQError(d && d.error);
      setQrMask(true, "网关不可用");
      renderQQStat();
      return;
    }

    const status = d.status || {};
    const info = d.info || {};
    const loggedIn = Boolean(status.isLogin) || status.loginPhase === "ready";
    const phase = status.loginPhase || "";
    state.qq = { loggedIn, phase, error: status.loginError || "", info };
    renderQQStat();

    if (loggedIn) {
      pill.className = "pill ok";
      pill.innerHTML = '<i class="dot"></i>已登录';
      $("qq-name").textContent = info.nick || "已登录";
      $("qq-sub").textContent = `QQ ${info.uin || status.uin || "—"} · ${info.online ? "在线" : "在线状态未知"}`;
      $("qq-qr-img").removeAttribute("src");
      state.qrUrl = "";
      setQrMask(true, "已登录");
    } else {
      pill.className = "pill " + (phase === "qrcode_scanned" || phase === "initializing" ? "wait" : "off");
      const labels = {
        waiting_qrcode: "等待扫码",
        qrcode_scanned: "已扫码，请在手机确认",
        initializing: "正在启动",
        reconnecting: "重新连接中",
      };
      pill.innerHTML = '<i class="dot"></i>' + (labels[phase] || "未登录");
      $("qq-name").textContent = "等待登录";
      $("qq-sub").textContent = status.loginError
        ? `登录失败：${status.loginError}`
        : (phase === "qrcode_scanned" ? "已扫码，请在手机上确认登录" : "用手机 QQ 扫描二维码，或使用账号密码登录");
      if (phase === "qrcode_scanned" || phase === "initializing") {
        setQrMask(true, phase === "qrcode_scanned" ? "请在手机上确认" : "正在启动…");
      } else if (!state.qrUrl) {
        state.qrUrl = "pending";
        loadQr(false).then(ok => { if (!ok) state.qrUrl = ""; });
      }
    }
    if (!state.accountsLoaded) {
      state.accountsLoaded = true;
      loadAccounts(false);
    }
  }

  async function loadAccounts(force) {
    const box = $("qq-accounts");
    if (force) box.innerHTML = '<div class="hint">正在读取…</div>';
    try {
      const d = await api("/api/qq/accounts");
      if (!d.ok) {
        box.innerHTML = `<div class="hint">${escapeHtml(d.error || "读取失败")}</div>`;
        return;
      }
      const list = d.accounts || [];
      if (!list.length) {
        box.innerHTML = '<div class="hint">暂无可免密登录的账号，请用二维码或账号密码登录。</div>';
        return;
      }
      box.innerHTML = list.map(item => {
        const uin = String(item.uin || "");
        const face = (item.faceUrl && /^https?:/.test(item.faceUrl))
          ? item.faceUrl
          : `https://q1.qlogo.cn/g?b=qq&nk=${encodeURIComponent(uin)}&s=100`;
        return `<div class="acct" data-uin="${escapeHtml(uin)}">
          <img src="${escapeHtml(face)}" alt="" onerror="this.style.visibility='hidden'" />
          <div style="flex:1;min-width:0"><div class="nick">${escapeHtml(item.nickName || item.nick || "未知昵称")}</div>
          <div class="uin">QQ ${escapeHtml(uin)}</div></div>
          <span class="go">登录</span>
        </div>`;
      }).join("");
      box.querySelectorAll(".acct").forEach(el => {
        el.addEventListener("click", () => quickLogin(el.dataset.uin));
      });
    } catch (e) {
      box.innerHTML = '<div class="hint">读取失败，请稍后重试</div>';
    }
  }

  async function quickLogin(uin) {
    toast("正在免密登录…");
    try {
      const d = await api("/api/qq/quicklogin", { method: "POST", body: { uin } });
      toast(d.ok ? "已发起免密登录" : (d.error || "登录失败"));
      if (!d.ok) $("qq-hint").textContent = (d.error || "登录失败") + "，可点「修复免密登录」后再试。";
      state.accountsLoaded = false;
      setTimeout(refreshQQ, 900);
    } catch (e) {
      toast("登录失败");
    }
  }

  async function passwordLogin() {
    const uin = $("qq-uin").value.trim();
    const pwd = $("qq-pwd").value;
    const remember = $("qq-remember").checked;
    const saved = readCred();
    if (!/^\d{5,12}$/.test(uin)) { toast("请填写正确的 QQ 号"); return; }
    const payload = { uin };
    if (pwd) payload.password = pwd;
    else if (saved && saved.passwordMd5 && String(saved.uin) === uin) payload.passwordMd5 = saved.passwordMd5;
    else { toast("请填写密码"); return; }

    toast("正在登录…");
    let d;
    try {
      d = await api("/api/qq/passwordlogin", { method: "POST", body: payload });
    } catch (e) {
      toast("登录失败");
      return;
    }
    if (!d.ok) {
      toast(d.error || "登录失败");
      $("qq-hint").textContent = d.error || "登录失败";
      return;
    }
    const data = d.data || {};
    if (data.needCaptcha) {
      const url = data.proofWaterUrl || "";
      $("qq-hint").innerHTML = `需要先过验证码：<a href="${escapeHtml(url)}" target="_blank" rel="noreferrer">打开验证页面</a>，完成后重新登录。`;
      toast("需要先完成验证码");
      return;
    }
    if (data.needNewDevice) {
      const url = data.jumpUrl || "";
      $("qq-hint").innerHTML = `新设备需要手机确认：<a href="${escapeHtml(url)}" target="_blank" rel="noreferrer">打开验证链接</a>，完成后重新登录。`;
      toast("新设备需要确认");
      return;
    }
    if (remember && d.passwordMd5) saveCred(uin, d.passwordMd5);
    else clearCred();
    $("qq-pwd").value = "";
    $("qq-hint").textContent = "已发起登录，正在等待 QQ 完成验证…";
    toast("已发起密码登录");
    state.accountsLoaded = false;
    setTimeout(refreshQQ, 1200);
  }

  async function repairQuickLogin() {
    const saved = readCred();
    const uin = (saved && saved.uin) || "";
    toast("正在修复免密登录…");
    try {
      const d = await api("/api/qq/repair", { method: "POST", body: { uin } });
      if (!d.ok) { toast("修复失败，请稍后重试"); return; }
      toast(d.retried ? "已修复并重新发起登录" : "已修复，请再点免密登录");
      state.accountsLoaded = false;
      setTimeout(refreshQQ, 1200);
    } catch (e) {
      toast("修复失败");
    }
  }

  /* ---------- AI 与生图 ---------- */
  async function loadConfig() {
    try {
      const c = await api("/api/config");
      state.config = c;
      const ai = c.ai || {};
      $("ai-enabled").checked = Boolean(ai.enabled);
      $("ai-base").value = ai.base_url || "";
      $("ai-key").value = ai.api_key || "";
      $("ai-model").value = ai.model || "";
      $("ai-triggers").value = (ai.triggers || []).join(",");
      $("ai-reply-mode").value = ai.reply_mode || "direct";

      const img = c.image || {};
      $("img-enabled").checked = Boolean(img.enabled);
      $("img-base").value = img.base_url || "";
      $("img-key").value = img.api_key || "";
      $("img-model").value = img.model || "";
      $("img-path").value = img.path || "";
      $("img-ratio").value = img.default_ratio || "1:1";
      $("img-resolution").value = img.default_resolution || "480P";

      const models = Object.keys(ai.model_status || {});
      const datalist = $("model-options");
      datalist.innerHTML = models.map(name => `<option value="${escapeHtml(name)}"></option>`).join("");
    } catch (e) {
      toast("读取配置失败");
    }
  }

  async function saveAiConfig() {
    const payload = {
      ai: {
        enabled: $("ai-enabled").checked,
        base_url: $("ai-base").value.trim(),
        api_key: $("ai-key").value,
        model: $("ai-model").value.trim(),
        triggers: $("ai-triggers").value.split(/[,，]/).map(s => s.trim()).filter(Boolean),
        reply_mode: $("ai-reply-mode").value,
      },
    };
    try {
      const d = await api("/api/config", { method: "PUT", body: payload });
      toast(d.ok ? "AI 配置已保存" : "保存失败");
    } catch (e) {
      toast("保存失败");
    }
  }

  async function saveImageConfig() {
    const payload = {
      image: {
        enabled: $("img-enabled").checked,
        base_url: $("img-base").value.trim(),
        api_key: $("img-key").value,
        model: $("img-model").value.trim(),
        path: $("img-path").value.trim() || "/images/generations",
        default_ratio: $("img-ratio").value,
        default_resolution: $("img-resolution").value,
      },
    };
    try {
      const d = await api("/api/config", { method: "PUT", body: payload });
      toast(d.ok ? "生图配置已保存" : "保存失败");
    } catch (e) {
      toast("保存失败");
    }
  }

  /* ---------- 插件 ---------- */
  async function loadPlugins() {
    const box = $("plugin-list");
    box.innerHTML = '<div class="skeleton"></div><div class="skeleton"></div>';
    try {
      const d = await api("/api/plugins");
      const loaded = d.loaded || [];
      const disabled = new Set(d.disabled || []);
      if (!loaded.length) {
        box.innerHTML = '<div class="hint">没有已加载的插件</div>';
        return;
      }
      box.innerHTML = loaded.map(item => {
        const off = disabled.has(item.name);
        return `<div class="plugin ${off ? "disabled" : ""}">
          <div>
            <div class="name">${escapeHtml(item.display_name || item.name)}</div>
            <div class="desc">${escapeHtml(item.description || "")}</div>
            <div class="meta"><span>v${escapeHtml(item.version || "—")}</span><span>·</span><span>优先级 ${escapeHtml(item.priority)}</span><span>·</span><span>${item.source === "builtin" ? "内置" : "外部"}</span></div>
          </div>
          <label class="switch-line inline" style="margin:0">
            <input type="checkbox" data-plugin="${escapeHtml(item.name)}" ${off ? "" : "checked"} />
            <i></i>
          </label>
        </div>`;
      }).join("");
      box.querySelectorAll("input[data-plugin]").forEach(input => {
        input.addEventListener("change", () => togglePlugin(input.dataset.plugin, input.checked, input));
      });
    } catch (e) {
      box.innerHTML = '<div class="hint">读取插件失败</div>';
    }
  }

  async function togglePlugin(name, enabled, input) {
    input.disabled = true;
    try {
      const d = await api(`/api/plugins/${encodeURIComponent(name)}/toggle`, {
        method: "POST", body: { enabled },
      });
      toast(d.ok ? (enabled ? "已启用" : "已停用") : "操作失败");
      if (!d.ok) input.checked = !enabled;
    } catch (e) {
      input.checked = !enabled;
      toast("操作失败");
    } finally {
      input.disabled = false;
    }
  }

  function pickPluginFile() {
    $("plugin-file").click();
  }

  function renderPluginImportSteps(steps) {
    const box = $("plugin-import-steps");
    if (!Array.isArray(steps) || !steps.length) { box.innerHTML = ""; return; }
    box.innerHTML = steps.map(s => {
      const mark = s.ok ? (s.warn ? "!" : "✓") : "✕";
      const cls = s.ok ? (s.warn ? "warn" : "ok") : "bad";
      return `<div class="plugin-step ${cls}"><b>${mark} ${escapeHtml(s.name || "")}</b>`
        + (s.detail ? `<pre>${escapeHtml(s.detail)}</pre>` : "") + "</div>";
    }).join("");
  }

  async function importPluginFile(input) {
    const file = input.files && input.files[0];
    input.value = "";
    if (!file) return;
    const hint = $("plugin-import-hint");
    if (!confirm(`确定导入插件「${file.name}」？\n\n`
      + "插件代码会被放到本机并立即加载运行。系统会先在独立子进程里试跑它并执行自带自检，"
      + "全部通过才安装；但自动测试挡不住蓄意作恶的插件，请确认来源可信。")) return;

    hint.textContent = "正在上传并在子进程里自检（最长约 1 分钟）…";
    $("plugin-import-steps").innerHTML = "";
    try {
      const content = await readFileBase64(file);
      const d = await api("/api/plugins/import", {
        method: "POST",
        timeout: 95000,
        body: { filename: file.name, content, confirm: true },
      });
      if (!d.ok) {
        hint.textContent = d.error || "导入失败";
        renderPluginImportSteps(d.steps);
        toast("插件导入失败");
        return;
      }
      const p = d.plugin || {};
      let text = `导入成功：${p.display_name || p.name} v${p.version}`
        + `（sha256 ${String(d.sha256 || "").slice(0, 12)}…）`;
      (d.warnings || []).forEach(w => { text += `\n注意：${w}`; });
      hint.textContent = text;
      renderPluginImportSteps(d.steps);
      toast("插件导入成功");
      loadPlugins();
    } catch (e) {
      hint.textContent = "导入失败：" + (e && e.message ? e.message : e);
    }
  }

  /* ---------- 日志 ---------- */
  async function loadLogs() {
    try {
      const d = await api("/api/logs?limit=300");
      const lines = (d.lines || []).filter(Boolean);
      const box = $("log-box");
      box.innerHTML = lines.map(line => {
        const cls = /\[ERROR\]/.test(line) ? "err" : /\[WARNING\]/.test(line) ? "warn" : "";
        return `<div class="line ${cls}">${escapeHtml(line)}</div>`;
      }).join("") || '<div class="hint">暂无日志</div>';
      box.scrollTop = box.scrollHeight;
    } catch (e) { /* ignore */ }
  }

  /* ---------- 知识库 ---------- */
  function kbGroupId() {
    return Number(($("kb-group").value || "").trim() || 0);
  }

  async function loadKb() {
    try {
      const d = await api("/api/kb/overview");
      if (!d.ok) throw new Error(d.error || "读取失败");
      const stats = d.stats || {};
      const groupCount = (d.groups || []).length;
      $("kb-stats").textContent = `已建库群：${groupCount} 个 · 条目：${stats.docs || 0} 条`;
      const groups = d.bot_groups || [];
      $("kb-groups").innerHTML = groups.map(g =>
        `<option value="${escapeHtml(g.group_id)}">${escapeHtml(g.group_name || g.group_id)}</option>`
      ).join("");
    } catch (e) {
      $("kb-stats").textContent = String(e && e.message ? e.message : e);
    }
  }

  async function loadKbDocs() {
    const group = kbGroupId();
    const box = $("kb-docs");
    if (!group) { toast("请先填写群号"); return; }
    box.innerHTML = '<div class="skeleton"></div>';
    try {
      const d = await api(`/api/kb/docs?group_id=${group}`);
      const docs = d.docs || [];
      $("kb-count").textContent = docs.length + " 条";
      if (!docs.length) {
        box.innerHTML = '<div class="hint">这个群还没有知识库条目</div>';
        return;
      }
      box.innerHTML = docs.map(doc => {
        const tags = Array.isArray(doc.tags) ? doc.tags.join(",") : (doc.tags || "");
        return `<div class="acct" style="align-items:flex-start">
          <div style="flex:1;min-width:0">
            <div class="nick">${escapeHtml(doc.title || "未命名")}</div>
            <div class="uin" style="white-space:pre-wrap">${escapeHtml((doc.content || "").slice(0, 180))}</div>
            ${tags ? `<div class="uin">标签：${escapeHtml(tags)}</div>` : ""}
          </div>
          <button class="link" data-del="${doc.id}">删除</button>
        </div>`;
      }).join("");
      box.querySelectorAll("button[data-del]").forEach(btn => {
        btn.addEventListener("click", () => deleteKbDoc(Number(btn.dataset.del)));
      });
    } catch (e) {
      box.innerHTML = '<div class="hint">读取失败</div>';
    }
  }

  async function addKbDoc() {
    const group = kbGroupId();
    const content = $("kb-content").value.trim();
    if (!group || !content) { toast("请填写群号和内容"); return; }
    try {
      const d = await api("/api/kb/docs", {
        method: "POST",
        body: {
          group_id: group,
          title: $("kb-title").value.trim(),
          tags: $("kb-tags").value.trim(),
          content,
        },
      });
      toast(d.ok ? "已保存" : (d.error || "保存失败"));
      if (d.ok) {
        $("kb-content").value = "";
        $("kb-title").value = "";
        loadKbDocs();
      }
    } catch (e) { toast("保存失败"); }
  }

  async function importKbDocs() {
    const group = kbGroupId();
    const text = $("kb-content").value.trim();
    if (!group || !text) { toast("请填写群号和内容"); return; }
    try {
      const d = await api("/api/kb/import", { method: "POST", body: { group_id: group, text } });
      toast(d.ok ? `已导入 ${d.count} 条` : (d.error || "导入失败"));
      if (d.ok) { $("kb-content").value = ""; loadKbDocs(); }
    } catch (e) { toast("导入失败"); }
  }

  async function deleteKbDoc(id) {
    try {
      const d = await api(`/api/kb/docs/${id}`, { method: "DELETE" });
      toast(d.ok ? "已删除" : "删除失败");
      loadKbDocs();
    } catch (e) { toast("删除失败"); }
  }

  async function searchKb() {
    const group = kbGroupId();
    const query = $("kb-query").value.trim();
    if (!group || !query) { toast("请填写群号和问题"); return; }
    try {
      const d = await api("/api/kb/search", { method: "POST", body: { group_id: group, query } });
      const hits = d.hits || [];
      $("kb-search-result").innerHTML = hits.length
        ? hits.map(h => `<div class="acct"><div style="flex:1;min-width:0">
            <div class="nick">${escapeHtml(h.title || "未命名")} <span class="uin">${h.score}</span></div>
            <div class="uin" style="white-space:pre-wrap">${escapeHtml((h.content || "").slice(0, 200))}</div>
          </div></div>`).join("")
        : '<div class="hint">没有命中，换个说法试试</div>';
    } catch (e) { toast("检索失败"); }
  }

  /* ---------- 记忆库 ---------- */
  function memScope() { return $("mem-scope").value; }
  function memTarget() { return Number(($("mem-target").value || "").trim() || 0); }

  async function loadMem() {
    try {
      const d = await api("/api/memory/overview");
      const s = d.stats || {};
      const groups = (d.groups || []).length;
      const users = (d.users || []).length;
      $("mem-stats").textContent = `群聊 ${groups} 个 · 用户 ${users} 个 · 条目 ${s.total || 0} 条`;
    } catch (e) {
      $("mem-stats").textContent = String(e && e.message ? e.message : e);
    }
  }

  async function loadMemList() {
    const scope = memScope();
    const target = memTarget();
    let path = `/api/memory?scope=${encodeURIComponent(scope)}`;
    if (scope === "group" && target) path += `&group_id=${target}`;
    if (scope === "user" && target) path += `&user_id=${target}`;
    const box = $("mem-list");
    box.innerHTML = '<div class="skeleton"></div>';
    try {
      const d = await api(path);
      const items = d.memories || [];
      $("mem-count").textContent = items.length + " 条";
      if (!items.length) { box.innerHTML = '<div class="hint">没有记忆</div>'; return; }
      box.innerHTML = items.map(m => `<div class="acct" style="align-items:flex-start">
        <div style="flex:1;min-width:0">
          <div class="nick">${escapeHtml(m.scope_label || m.scope)}${m.group_id ? " · 群 " + escapeHtml(m.group_id) : ""}${m.user_id ? " · QQ " + escapeHtml(m.user_id) : ""}</div>
          <div class="uin" style="white-space:pre-wrap">${escapeHtml((m.content || "").slice(0, 220))}</div>
        </div>
        <button class="link" data-del="${m.id}">删除</button>
      </div>`).join("");
      box.querySelectorAll("button[data-del]").forEach(btn => {
        btn.addEventListener("click", () => deleteMem(Number(btn.dataset.del)));
      });
    } catch (e) { box.innerHTML = '<div class="hint">读取失败</div>'; }
  }

  async function addMem() {
    const content = $("mem-content").value.trim();
    if (!content) { toast("请填写内容"); return; }
    const scope = memScope();
    const target = memTarget();
    try {
      const d = await api("/api/memory", {
        method: "POST",
        body: {
          content,
          scope,
          group_id: scope === "group" ? target : 0,
          user_id: scope === "user" ? target : 0,
        },
      });
      toast(d.ok ? "已记住" : (d.error || "保存失败"));
      if (d.ok) { $("mem-content").value = ""; loadMemList(); loadMem(); }
    } catch (e) { toast("保存失败"); }
  }

  async function deleteMem(id) {
    try {
      const d = await api(`/api/memory/${id}`, { method: "DELETE" });
      toast(d.ok ? "已删除" : "删除失败");
      loadMemList();
      loadMem();
    } catch (e) { toast("删除失败"); }
  }

  /* ---------- 表情包 ---------- */
  async function loadStickers() {
    const box = $("stk-list");
    try {
      const d = await api("/api/stickers");
      const items = d.stickers || [];
      const stats = d.stats || {};
      $("stk-stats").textContent = `共 ${stats.count || items.length} 张`;
      $("stk-count").textContent = items.length + " 张";
      if (!items.length) { box.innerHTML = '<div class="hint">还没有表情包</div>'; return; }
      const base = USE_BRIDGE ? "http://127.0.0.1:6199" : "";
      box.innerHTML = items.map(item => {
        const tags = Array.isArray(item.tags) ? item.tags.join(",") : "";
        return `<div class="acct">
          <img src="${base}/api/stickers/${encodeURIComponent(item.id)}/raw" alt=""
               style="width:42px;height:42px;object-fit:cover;border-radius:10px"
               onerror="this.style.visibility='hidden'" />
          <div style="flex:1;min-width:0">
            <div class="nick">${escapeHtml(item.name || item.id)}</div>
            <div class="uin">${escapeHtml(tags) || "无标签"}</div>
          </div>
          <button class="link" data-del="${escapeHtml(item.id)}">删除</button>
        </div>`;
      }).join("");
      box.querySelectorAll("button[data-del]").forEach(btn => {
        btn.addEventListener("click", () => deleteSticker(btn.dataset.del));
      });
    } catch (e) { box.innerHTML = '<div class="hint">读取失败</div>'; }
  }

  function readFileBase64(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(String(reader.result || ""));
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });
  }

  async function uploadStickers() {
    const input = $("stk-files");
    const files = Array.from(input.files || []);
    if (!files.length) { toast("请选择图片"); return; }
    const tags = $("stk-tags").value.split(/[,，]/).map(s => s.trim()).filter(Boolean);
    let okCount = 0;
    for (const file of files) {
      if (file.size > 2 * 1024 * 1024) {
        toast(`${file.name} 超过 2MB，已跳过`);
        continue;
      }
      try {
        const data = await readFileBase64(file);
        const d = await api("/api/stickers", {
          method: "POST",
          body: { name: file.name.replace(/\.[^.]+$/, ""), tags, data },
        });
        if (d.ok) okCount++;
        else toast(d.error || "导入失败");
      } catch (e) { toast("导入失败"); }
    }
    toast(`已导入 ${okCount} 张`);
    input.value = "";
    loadStickers();
  }

  async function deleteSticker(id) {
    try {
      const d = await api(`/api/stickers/${encodeURIComponent(id)}`, { method: "DELETE" });
      toast(d.ok ? "已删除" : "删除失败");
      loadStickers();
    } catch (e) { toast("删除失败"); }
  }

  /* ---------- 自主模式 ---------- */
  async function loadAuto() {
    try {
      const c = await api("/api/config");
      const a = c.auto_mode || {};
      $("auto-enabled").checked = Boolean(a.enabled);
      $("auto-poke").checked = Boolean(a.on_poke);
      $("auto-at").checked = Boolean(a.on_at);
      $("auto-any").checked = Boolean(a.on_any);
      $("auto-any-prob").value = Math.round((Number(a.any_probability) || 0.5) * 100);
      $("auto-keywords").value = (a.keywords || []).join(",");
      $("auto-reply-mode").value = a.reply_mode || "direct";
      $("auto-short-enabled").checked = Boolean(a.short_reply_enabled);
      $("auto-short-before").value = a.short_reply_before != null ? a.short_reply_before : 3;
      $("auto-short-after").value = a.short_reply_after != null ? a.short_reply_after : 2;
      $("auto-short-scope").value = a.short_reply_scope === "all" ? "all" : "trigger";
    } catch (e) { toast("读取配置失败"); }
  }

  async function saveAuto() {
    const percent = Math.min(100, Math.max(1, Number($("auto-any-prob").value) || 50));
    try {
      const d = await api("/api/config", {
        method: "PUT",
        body: {
          auto_mode: {
            enabled: $("auto-enabled").checked,
            on_poke: $("auto-poke").checked,
            on_at: $("auto-at").checked,
            on_any: $("auto-any").checked,
            any_probability: percent / 100,
            keywords: $("auto-keywords").value.split(/[,，]/).map(s => s.trim()).filter(Boolean),
            reply_mode: $("auto-reply-mode").value,
            short_reply_enabled: $("auto-short-enabled").checked,
            short_reply_before: Math.max(0, Math.min(20, Number($("auto-short-before").value) || 0)),
            short_reply_after: Math.max(0, Math.min(20, Number($("auto-short-after").value) || 0)),
            short_reply_scope: $("auto-short-scope").value,
          },
        },
      });
      toast(d.ok ? "自主模式已保存" : "保存失败");
    } catch (e) { toast("保存失败"); }
  }

  /* ---------- 安全模式 ---------- */
  async function loadSafe() {
    try {
      const c = await api("/api/config");
      const s = c.safety || {};
      $("safe-enabled").checked = s.enabled !== false;
      $("safe-min-delay").value = s.min_delay != null ? s.min_delay : 0.8;
      $("safe-max-delay").value = s.max_delay != null ? s.max_delay : 2;
      $("safe-cooldown").value = s.group_cooldown != null ? s.group_cooldown : 3;
      $("safe-hourly").value = s.hourly_limit != null ? s.hourly_limit : 60;
      $("safe-dedup").value = s.dedup_window != null ? s.dedup_window : 60;
    } catch (e) { toast("读取配置失败"); }
  }

  async function saveSafe() {
    const num = (id, min, max, fallback) => {
      let value = Number($(id).value);
      if (!isFinite(value)) value = fallback;
      return Math.max(min, Math.min(max, value));
    };
    try {
      const d = await api("/api/config", {
        method: "PUT",
        body: {
          safety: {
            enabled: $("safe-enabled").checked,
            min_delay: num("safe-min-delay", 0, 20, 0.8),
            max_delay: num("safe-max-delay", 0, 20, 2),
            group_cooldown: num("safe-cooldown", 0, 120, 3),
            hourly_limit: Math.round(num("safe-hourly", 0, 1000, 60)),
            dedup_window: num("safe-dedup", 0, 600, 60),
          },
        },
      });
      toast(d.ok ? "安全模式已保存" : "保存失败");
    } catch (e) { toast("保存失败"); }
  }

  /* ---------- 置控台 ---------- */
  let consoleStates = {};   // {群号: 红绿状态}
  let consoleOrder = [];    // 卡片顺序

  async function loadConsole() {
    try {
      const c = await api("/api/config");
      const o = await api("/api/console/overview");
      const botCfg = (c && c.bot) || {};
      const cc = (c && c.console) || {};
      $("admin-list").value = (botCfg.admins || []).join(",");
      $("adm-identity").value = botCfg.admin_identity || "";
      $("mem-identity").value = botCfg.member_identity || "";
      $("console-bindings").value = (cc.bindings || [])
        .map(item => `${item.user_id || ""}=${item.name || ""}=${item.relation || ""}`).join("\n");
      $("console-notify-enabled").checked = Boolean(cc.notify_enabled);
      $("console-notify-email").value = cc.notify_email || "";
      $("console-notify-qq").value = cc.notify_qq || "";
      $("console-notify-code").value = cc.notify_auth_code || "";
      $("console-notify-cooldown").value = cc.notify_cooldown || 1800;

      consoleStates = {};
      consoleOrder = [];
      ((o && o.groups) || []).forEach(g => {
        const gid = String(g.group_id || "");
        if (!gid) return;
        consoleStates[gid] = Object.assign({}, g, { group_id: gid });
        consoleOrder.push(gid);
      });
      renderConsoleGroups();
    } catch (e) { toast("读取置控台失败"); }
  }

  function consoleCard(g) {
    const gid = String(g.group_id || "");
    const on = Boolean(g.can_speak);
    let status = "允许发言";
    if (!on) {
      if (g.permanent || (g.silenced && !g.until)) {
        status = "永久禁言";
      } else if (g.until) {
        const d = new Date(g.until * 1000);
        status = "禁言至 " + d.toLocaleTimeString("zh-CN", { hour: "2-digit", minute: "2-digit" });
        const left = Math.round((g.until * 1000 - Date.now()) / 60000);
        if (left > 0) status += ` · 剩 ${left} 分钟`;
      } else if (!g.enabled) {
        status = "已关闭发言";
      }
    }
    const name = g.group_name || ("群 " + gid);
    return `<div class="group-card ${on ? "on" : "off"}"
        onclick="toggleConsoleGroup('${escapeHtml(gid)}')">
        <span class="gdot"></span>
        <div class="gtext">
          <div class="gname">${escapeHtml(name)}</div>
          <div class="gmeta">${escapeHtml(status)}</div>
          <div class="gid">${escapeHtml(gid)}</div>
        </div>
      </div>`;
  }

  function renderConsoleGroups() {
    const box = $("console-group-list");
    if (!box) return;
    if (!consoleOrder.length) {
      box.innerHTML = '<p class="hint">没有读取到群。可以手动填群号后点「加入列表」。</p>';
      return;
    }
    box.innerHTML = consoleOrder.map(gid => consoleCard(consoleStates[gid] || { group_id: gid })).join("");
  }

  async function toggleConsoleGroup(gid) {
    const cur = consoleStates[gid];
    if (!cur) return;
    try {
      const d = await api("/api/console/group", {
        method: "POST",
        body: { group_id: gid, enabled: !cur.can_speak },
      });
      if (!d.ok) { toast(d.error || "切换失败"); return; }
      consoleStates[gid] = Object.assign({}, d.state, {
        group_id: gid, group_name: cur.group_name || "",
      });
      renderConsoleGroups();
    } catch (e) { toast("切换失败"); }
  }

  function addConsoleGroup() {
    const input = $("console-new-group");
    const gid = String(input.value || "").trim();
    if (!/^\d{4,}$/.test(gid)) { toast("请填写正确的群号"); return; }
    if (!consoleStates[gid]) {
      consoleStates[gid] = {
        group_id: gid, group_name: "", enabled: true, silenced: false,
        permanent: false, until: 0, can_speak: true,
      };
      consoleOrder.push(gid);
    }
    input.value = "";
    renderConsoleGroups();
  }

  async function testNotify() {
    const payload = {
      email: $("console-notify-email").value.trim(),
      qq: $("console-notify-qq").value.trim(),
      auth_code: $("console-notify-code").value.trim(),
    };
    if (!payload.email || !payload.qq || !payload.auth_code) {
      toast("请先填写收件邮箱、发件 QQ 号和授权码");
      return;
    }
    toast("正在发送测试邮件…");
    try {
      const d = await api("/api/notify/test", { method: "POST", body: payload });
      toast(d.ok ? "测试邮件已发出，请查收" : ("发送失败：" + (d.error || "未知原因")));
    } catch (e) { toast("发送失败"); }
  }

  async function saveConsole() {
    const bindings = [];
    String($("console-bindings").value || "").split(/\r?\n/).forEach(line => {
      const parts = line.split("=");
      if (parts.length < 2) return;
      const qq = parts[0].trim();
      const name = parts[1].trim();
      const relation = (parts[2] || "").trim();
      if (/^\d+$/.test(qq) && name) bindings.push({ user_id: qq, name, relation });
    });
    let cooldown = parseInt($("console-notify-cooldown").value, 10);
    if (!isFinite(cooldown)) cooldown = 1800;
    cooldown = Math.max(60, Math.min(86400, cooldown));

    try {
      const d = await api("/api/config", {
        method: "PUT",
        body: {
          bot: {
            admins: String($("admin-list").value || "").split(/[,，]/).map(s => s.trim())
              .filter(s => /^\d+$/.test(s)).map(Number),
            admin_identity: $("adm-identity").value.trim(),
            member_identity: $("mem-identity").value.trim(),
          },
          console: {
            bindings: bindings,
            notify_enabled: $("console-notify-enabled").checked,
            notify_email: $("console-notify-email").value.trim(),
            notify_qq: $("console-notify-qq").value.trim(),
            notify_auth_code: $("console-notify-code").value.trim(),
            notify_cooldown: cooldown,
          },
        },
      });
      toast(d.ok ? "置控台配置已保存" : "保存失败");
    } catch (e) { toast("保存失败"); }
  }

  /* ---------- 全能动作 ---------- */
  let omniEditId = "";
  let omniRules = [];
  let omniMeta = {};

  function omniTriggerText(value) {
    const item = (omniMeta.triggers || []).find(x => x.value === value);
    return item ? item.label : value;
  }

  function onOmniTriggerChange() {
    $("omni-keyword-box").style.display = $("omni-trigger").value === "keyword" ? "" : "none";
  }

  function resetOmniForm() {
    omniEditId = "";
    $("omni-form-title").textContent = "手动新建动作";
    $("omni-edit-hint").style.display = "none";
    $("omni-name").value = "";
    $("omni-trigger").value = "keyword";
    $("omni-keywords").value = "";
    $("omni-mode").value = "contains";
    $("omni-scope").value = "all";
    $("omni-like-times").value = "10";
    $("omni-actions").value = "";
    $("omni-enabled").checked = true;
    onOmniTriggerChange();
  }

  async function loadOmni() {
    const box = $("omni-list");
    try {
      const d = await api("/api/omni");
      if (!d.ok) { box.innerHTML = '<div class="hint">读取失败</div>'; return; }
      omniMeta = d;
      omniRules = d.rules || [];
      renderOmniList();
    } catch (e) {
      box.innerHTML = '<div class="hint">读取失败，请检查连接</div>';
    }
  }

  function renderOmniList() {
    const box = $("omni-list");
    if (!omniRules.length) {
      box.innerHTML = '<div class="hint">还没有动作，先用上面的一句话创建一条。</div>';
      return;
    }
    box.innerHTML = omniRules.map(rule => {
      const detail = rule.action_text || rule.summary || "";
      const stateText = rule.enabled === false ? "已停用" : "启用中";
      return `<div class="field" style="margin-bottom:12px">
        <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap">
          <strong>${escapeHtml(rule.name)}</strong>
          <span class="pill">${escapeHtml(stateText)}</span>
        </div>
        <div class="hint" style="margin-top:4px">${escapeHtml(rule.trigger_label || omniTriggerText((rule.trigger || {}).type))}</div>
        <div class="hint">动作：${escapeHtml(detail)}</div>
        <div class="actions" style="margin-top:8px">
          <button class="btn sm ghost" onclick="toggleOmni('${rule.id}', ${rule.enabled ? "false" : "true"})">${rule.enabled ? "停用" : "启用"}</button>
          <button class="btn sm ghost" onclick="editOmni('${rule.id}')">编辑</button>
          <button class="btn sm ghost" onclick="deleteOmni('${rule.id}')">删除</button>
        </div>
      </div>`;
    }).join("");
  }

  function editOmni(id) {
    const rule = omniRules.find(item => item.id === id);
    if (!rule) return;
    const trigger = rule.trigger || {};
    omniEditId = id;
    $("omni-form-title").textContent = "编辑动作";
    $("omni-edit-hint").style.display = "";
    $("omni-name").value = rule.name || "";
    $("omni-trigger").value = trigger.type || "keyword";
    $("omni-keywords").value = (trigger.keywords || []).join(",");
    $("omni-mode").value = trigger.mode || "contains";
    $("omni-scope").value = trigger.scope || "all";
    $("omni-like-times").value = rule.like_times || 10;
    $("omni-actions").value = rule.action_text || rule.summary || "";
    $("omni-enabled").checked = rule.enabled !== false;
    onOmniTriggerChange();
    $("page-omni").scrollIntoView({ behavior: "smooth", block: "start" });
  }

  async function saveOmni() {
    const triggerType = $("omni-trigger").value;
    const actionText = $("omni-actions").value.trim();
    if (!actionText) { toast("先写一下想要的动作"); return; }
    const keywords = $("omni-keywords").value.split(/[,，]/).map(s => s.trim()).filter(Boolean);
    if (triggerType === "keyword" && !keywords.length) { toast("触发词不能为空"); return; }
    const likeTimes = Math.max(1, Math.min(20, Number($("omni-like-times").value) || 10));
    try {
      const parsed = await api("/api/omni/parse", {
        method: "POST",
        body: {
          trigger: {
            type: triggerType,
            keywords: triggerType === "keyword" ? keywords : [],
            mode: $("omni-mode").value,
            scope: $("omni-scope").value,
          },
          action_text: actionText,
          name: $("omni-name").value.trim(),
        },
      });
      if (!parsed.ok) { toast(parsed.error || "AI 没能理解这条动作"); return; }
      const rule = parsed.rule;
      rule.like_times = likeTimes;
      rule.enabled = $("omni-enabled").checked;
      rule.actions = (rule.actions || []).map(action =>
        action.type === "like" ? { ...action, times: likeTimes } : action);
      const saved = omniEditId
        ? await api(`/api/omni/rules/${omniEditId}`, { method: "PUT", body: rule })
        : await api("/api/omni/rules", { method: "POST", body: rule });
      toast(saved.ok ? "动作已保存" : (saved.error || "保存失败"));
      if (saved.ok) { resetOmniForm(); loadOmni(); }
    } catch (e) { toast("保存失败"); }
  }

  async function createOmniFromIdea() {
    const text = $("omni-idea").value.trim();
    if (!text) { toast("先描述一下想要的效果"); return; }
    try {
      const d = await api("/api/omni/parse", { method: "POST", body: { text, save: true } });
      if (!d.ok) { toast(d.error || "AI 没能理解这句话"); return; }
      $("omni-idea").value = "";
      toast(`已创建「${d.rule.name}」`);
      loadOmni();
    } catch (e) { toast("创建失败"); }
  }

  async function toggleOmni(id, enabled) {
    try {
      const d = await api(`/api/omni/rules/${id}`, { method: "PUT", body: { enabled } });
      toast(d.ok ? (enabled ? "已启用" : "已停用") : (d.error || "操作失败"));
      if (d.ok) loadOmni();
    } catch (e) { toast("操作失败"); }
  }

  async function deleteOmni(id) {
    if (!confirm("确定删除这条动作？")) return;
    try {
      const d = await api(`/api/omni/rules/${id}`, { method: "DELETE" });
      toast(d.ok ? "已删除" : (d.error || "删除失败"));
      if (d.ok) loadOmni();
    } catch (e) { toast("删除失败"); }
  }

  /* ---------- 白话群管 ---------- */
  async function loadAdm() {
    try {
      const c = await api("/api/config");
      const a = c.admin_nl || {};
      $("adm-enabled").checked = Boolean(a.enabled);
      $("adm-callnames").value = (a.call_names || []).join(",");
      $("adm-default-mute").value = a.default_mute_seconds || 600;
      $("adm-max-mute").value = a.max_mute_seconds || 2592000;
      $("adm-free-listen").value = a.free_listen || "admin";
      $("adm-max-rounds").value = a.max_rounds || 3;
      state.admPerms = a.permissions || {};
      loadAdmPerms();
    } catch (e) { toast("读取配置失败"); }
  }

  function permPattern(a, word) {
    if (!word) return a.syntax || "";
    const params = a.params || [];
    if (["recall", "essence", "unessence"].includes(a.action)) return `先回复那条消息，再说「小T，${word}」`;
    if (a.action === "set_group_portrait") return `先发图片，再说「小T，${word}」`;
    const targetActions = ["mute", "unmute", "kick", "poke", "set_card",
      "set_special_title", "set_admin", "unset_admin", "like"];
    if (!params.length && targetActions.includes(a.action)) return `「小T，${word} [目标QQ号 / @ 他]」`;
    if (params.some(p => p.name === "message_id")) return `先回复那条消息，再说「小T，${word}」`;
    if (params.some(p => p.name === "file")) {
      const target = params.some(p => p.name === "user_id") ? " [目标QQ号]"
        : (params.some(p => p.name === "group_id") ? " [群号]" : "");
      return `「小T，${word}${target} [文件路径]」`;
    }
    if (params.some(p => p.name === "user_id")) return `「小T，${word} [目标QQ号]」（也可以 @ 他 / 回复他后说「${word}」）`;
    if (params.some(p => p.name === "group_id")) return `「小T，${word} [群号]」`;
    return `「小T，${word}」`;
  }

  async function loadAdmPerms() {
    const box = $("adm-perms");
    try {
      const d = await api("/api/admin-nl");
      const actions = d.actions || [];
      const levels = d.levels || [];
      const perms = state.admPerms || {};
      box.innerHTML = actions.map(a => {
        const current = perms[a.action] || a.default_level || "admin";
        const options = levels.map(l =>
          `<option value="${escapeHtml(l.value)}" ${l.value === current ? "selected" : ""}>${escapeHtml(l.label)}</option>`
        ).join("");
        const help = [
          `【${a.label || a.action}】${a.action}`,
          `自定义理解词：${a.custom_word || "未设置"}`,
          `完整句式：${a.pattern || a.syntax || ""}`,
          `说明：${a.description || ""}`,
          a.params && a.params.length
            ? "参数：" + a.params.map(p => `${p.name}${p.required ? "（必填）" : ""}：${p.desc}`).join("；")
            : "",
          "触发：在群里先叫机器人名字或 @ 它，再说这句话；私聊直接说。",
        ].filter(Boolean).join("\n");
        return `<div class="field perm-field" style="margin-bottom:10px">
          <label>
            <button type="button" class="perm-help" aria-label="查看用法">?</button>
            ${escapeHtml(a.label || a.action)} <span class="uin">${escapeHtml(a.action)}</span>
          </label>
          <div class="perm-word-line">
            <span>自定义理解词</span>
            <input class="perm-word" data-word="${escapeHtml(a.action)}" value="${escapeHtml(a.custom_word || "")}" placeholder="例如「删好友」" />
          </div>
          <div class="perm-word-full">完整：${escapeHtml(a.pattern || a.syntax || "")}</div>
          <select data-perm="${escapeHtml(a.action)}">${options}</select>
          <div class="perm-help-box" hidden>${escapeHtml(help)}</div>
        </div>`;
      }).join("") || '<div class="hint">没有可用能力</div>';

      box.querySelectorAll(".perm-help").forEach(btn => {
        btn.addEventListener("click", () => {
          const helpBox = btn.closest(".perm-field").querySelector(".perm-help-box");
          if (helpBox) helpBox.hidden = !helpBox.hidden;
        });
      });
      box.querySelectorAll("input[data-word]").forEach(input => {
        input.addEventListener("input", () => {
          const a = actions.find(x => x.action === input.dataset.word);
          if (!a) return;
          const full = input.closest(".perm-field").querySelector(".perm-word-full");
          if (full) full.textContent = "完整：" + permPattern(a, input.value.trim());
        });
      });
    } catch (e) {
      box.innerHTML = '<div class="hint">读取失败</div>';
    }
  }

  async function saveAdm() {
    const perms = {};
    document.querySelectorAll("select[data-perm]").forEach(sel => {
      perms[sel.dataset.perm] = sel.value;
    });
    const words = {};
    document.querySelectorAll("#adm-perms input[data-word]").forEach(el => {
      const value = el.value.trim();
      if (value) words[el.dataset.word] = value;
    });
    try {
      const d = await api("/api/config", {
        method: "PUT",
        body: {
          admin_nl: {
            enabled: $("adm-enabled").checked,
            call_names: $("adm-callnames").value.split(/[,，]/).map(s => s.trim()).filter(Boolean),
            default_mute_seconds: Number($("adm-default-mute").value) || 600,
            max_mute_seconds: Number($("adm-max-mute").value) || 2592000,
            free_listen: $("adm-free-listen").value,
            max_rounds: Number($("adm-max-rounds").value) || 3,
            permissions: perms,
            custom_words: words,
          },
        },
      });
      toast(d.ok ? "白话群管已保存" : "保存失败");
    } catch (e) { toast("保存失败"); }
  }

  /* ---------- 启动时的更新 / 公告弹窗 ---------- */
  const NOTICE_SEEN_KEY = "qqbot.mobile.notice.seen";
  let updateInfo = null;

  async function bootUpdate() {
    try {
      const current = (state.status && state.status.version) || "2.0.0";
      const d = await api(`/api/txgod/version?current=${encodeURIComponent(current)}`);
      if (!d.ok) return false;
      const info = d.data || {};
      if (!info.need_update) return false;
      updateInfo = info;
      $("update-title").textContent = `发现新版本 v${info.latest || ""}`;
      const lines = [];
      if (info.notes) lines.push(info.notes);
      if (info.changelog) lines.push(info.changelog);
      if (info.min_version) lines.push(`最低可用版本：v${info.min_version}`);
      lines.push(`当前版本：v${current}`);
      $("update-body").textContent = lines.join("\n");
      const url = String(info.download_url || "");
      const valid = /^https?:\/\/\S+$/i.test(url) && !/[\u4e00-\u9fa5]/.test(url);
      const link = $("update-download");
      if (valid) { link.href = url; link.style.display = ""; }
      else link.style.display = "none";
      $("update-mask").classList.add("show");
      return true;
    } catch (e) {
      return false;
    }
  }

  async function bootNotice() {
    try {
      const r = await api("/api/txgod/announcement");
      if (!r.ok) return;
      const item = r.data || {};
      if (!item.content) return;
      const key = [item.updated_time || "", item.title || "", (item.content || "").slice(0, 80)].join("|");
      if (localStorage.getItem(NOTICE_SEEN_KEY) === key) return;
      $("notice-title2").textContent = item.title || "公告";
      $("notice-body2").textContent = item.content;
      $("notice-mask").classList.add("show");
      localStorage.setItem(NOTICE_SEEN_KEY, key);
    } catch (e) { /* 静默 */ }
  }

  function closeUpdate() { $("update-mask").classList.remove("show"); }

  async function skipUpdate() {
    const version = updateInfo && updateInfo.latest ? updateInfo.latest : "";
    if (version) {
      try { await api("/api/txgod/skip", { method: "POST", body: { version } }); } catch (e) { /* ignore */ }
    }
    closeUpdate();
    toast("已跳过此版本");
  }

  function closeNotice() { $("notice-mask").classList.remove("show"); }

  /* ---------- Android 壳 ---------- */
  function androidBridge() {
    return (typeof window.AndroidBridge !== "undefined") ? window.AndroidBridge : null;
  }

  function loadAndroidStatus() {
    const bridge = androidBridge();
    const card = $("keepalive-card");
    const runtimeCard = $("runtime-card");
    if (!bridge) {
      card.style.display = "none";
      if (runtimeCard) runtimeCard.style.display = "none";
      $("btn-switch-server").style.display = "none";
      $("mobile-only-tip").style.display = "";
      return;
    }
    try {
      const info = JSON.parse(bridge.getStatusJson() || "{}");
      let local = {};
      try { local = JSON.parse(bridge.getLocalStatus() || "{}"); } catch (ignored) { /* ignore */ }
      const tip = $("mobile-only-tip");
      if (tip) tip.style.display = "none";
      // 远程控制端没有本地运行时，隐藏「本地运行」卡片
      if (runtimeCard && !LOCAL_MODE) runtimeCard.style.display = "none";
      const running = Boolean(info.running);
      const desired = info.desired !== false;
      $("keepalive-switch").checked = desired;
      $("keepalive-pill").className = "pill " + (desired ? "ok" : "off");
      $("keepalive-pill").textContent = desired ? "常驻中" : "已停止";
      if (runtimeCard) {
        const pill = $("runtime-pill");
        const error = local.error || "";
        if (error) {
          pill.className = "pill off";
          pill.textContent = "启动失败";
        } else if (running) {
          pill.className = "pill ok";
          pill.textContent = "运行中";
        } else if (local.ready) {
          pill.className = "pill acc";
          pill.textContent = "已就绪";
        } else {
          pill.className = "pill acc";
          pill.textContent = "准备中";
        }
        const hint = $("runtime-hint");
        if (hint) {
          hint.textContent = error
            ? error + "，可点下方「刷新诊断」查看日志"
            : (local.message || "正在检查本地运行环境");
        }
      }
      $("keepalive-hint").textContent = info.batteryOptimized
        ? "系统当前会对后台做省电限制；建议点「加入省电白名单」。"
        : "已加入省电白名单，后台更稳。";
    } catch (e) {
      $("keepalive-hint").textContent = "读取后台状态失败";
    }
  }

  function loadDiagnostics() {
    const bridge = androidBridge();
    const box = $("diag-log");
    const summary = $("diag-summary");
    const pill = $("diag-pill");
    if (!box) return;
    if (!bridge || !bridge.getDiagnostics) {
      box.textContent = "当前版本不支持启动诊断";
      return;
    }
    try {
      const d = JSON.parse(bridge.getDiagnostics() || "{}");
      if (pill) {
        pill.className = "pill " + (d.error ? "off" : d.rootfsComplete ? "ok" : "acc");
        pill.textContent = d.error ? "异常" : d.rootfsComplete ? "正常" : "准备中";
      }
      if (summary) {
        summary.textContent = `Android ${d.android || "—"} · ${d.abi || "—"} · SDK ${d.sdk || "—"}`
          + ` · 剩余 ${d.freeMb || 0}MB` + (d.error ? ` · ${d.error}` : "");
      }
      const parts = [
        ["运行输出", d.runLog],
        ["机器人日志", d.botLog],
        ["Xvfb", d.xvfbLog],
        ["QQ", d.qqLog],
        ["解压", d.extractLog],
      ];
      box.textContent = parts.filter(item => item[1])
        .map(item => `—— ${item[0]} ——\n${item[1]}`)
        .join("\n\n") || "暂无日志";
    } catch (e) {
      box.textContent = "读取诊断信息失败";
    }
  }

  function startBot() {
    const bridge = androidBridge();
    if (!bridge) { toast("仅在手机 App 内可用"); return; }
    try {
      bridge.startLocal();
      toast("正在启动本地运行环境");
      setTimeout(loadAndroidStatus, 800);
    } catch (e) { toast("启动失败"); }
  }

  function stopBot() {
    const bridge = androidBridge();
    if (!bridge) { toast("仅在手机 App 内可用"); return; }
    try {
      bridge.stopLocal();
      toast("已停止运行");
      setTimeout(loadAndroidStatus, 800);
    } catch (e) { toast("停止失败"); }
  }

  function toggleKeepAlive(enabled) {
    const bridge = androidBridge();
    if (!bridge) return;
    try {
      bridge.setKeepAlive(enabled);
      toast(enabled ? "已开启后台常驻" : "已关闭后台常驻");
      setTimeout(loadAndroidStatus, 400);
    } catch (e) {
      toast("设置失败");
    }
  }

  function requestBattery() {
    const bridge = androidBridge();
    if (!bridge) { toast("仅在手机 App 内可用"); return; }
    try { bridge.requestIgnoreBattery(); } catch (e) { toast("打开设置失败"); }
  }

  function openAppSettings() {
    const bridge = androidBridge();
    if (!bridge) { toast("仅在手机 App 内可用"); return; }
    try { bridge.openAppSettings(); } catch (e) { toast("打开设置失败"); }
  }

  function switchServer() {
    const bridge = androidBridge();
    if (!bridge) { toast("仅在手机 App 内可用"); return; }
    try { bridge.openServerSettings(); } catch (e) { toast("打开设置失败"); }
  }

  function logoutApp() {
    const bridge = androidBridge();
    if (bridge && bridge.logout) {
      try { bridge.logout(); return; } catch (e) { /* fallback */ }
    }
    location.href = "/logout?mobile=1";
  }

  /* ---------- 配置同步 ---------- */
  function readFileBase64(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(String(reader.result || "").split(",")[1] || "");
      reader.onerror = () => reject(reader.error);
      reader.readAsDataURL(file);
    });
  }

  async function exportConfigBundle() {
    const hint = $("config-sync-hint");
    hint.textContent = "正在导出…";
    try {
      if (USE_BRIDGE) {
        const d = await api("/api/config/export", { method: "POST" });
        if (!d.ok) { hint.textContent = ""; toast(d.error || "导出失败"); return; }
        hint.textContent = `已导出到服务端：${d.path}`;
        toast("已导出全部配置");
        return;
      }
      hint.textContent = "已开始下载配置包";
      const link = document.createElement("a");
      link.href = "/api/config/export";
      link.download = "";
      document.body.appendChild(link);
      link.click();
      link.remove();
    } catch (e) {
      hint.textContent = "";
      toast("导出失败");
    }
  }

  async function importConfigBundle(input) {
    const file = input.files && input.files[0];
    input.value = "";
    if (!file) return;
    if (!confirm(`确定导入「${file.name}」？\n当前的表情包、插件数据、界面背景与对应配置会被覆盖；\nAI 配置、知识库、记忆库、API Key、面板端口、密码和网关连接会保留。`)) return;
    const hint = $("config-sync-hint");
    hint.textContent = "正在导入…";
    try {
      const content = await readFileBase64(file);
      const d = await api("/api/config/import", { method: "POST", body: { content } });
      if (!d.ok) { hint.textContent = ""; toast(d.error || "导入失败"); return; }
      hint.textContent = "导入成功，重启后生效。";
      if (confirm("配置已导入，需要重启才能生效。现在重启吗？")) {
        const r = await api("/api/app/restart", { method: "POST" });
        toast(r.manual ? "请先「停止运行」再「启动运行」以生效" : "正在重启…");
      }
    } catch (e) {
      hint.textContent = "";
      toast("导入失败");
    }
  }

  /* ---------- 事件绑定 ---------- */
  $("menu-btn").addEventListener("click", openDrawer);
  $("drawer-close").addEventListener("click", closeDrawer);
  $("scrim").addEventListener("click", closeDrawer);
  $("nav").addEventListener("click", e => {
    const item = e.target.closest(".nav-item[data-page]");
    if (item) gotoPage(item.dataset.page);
  });
  $("keepalive-switch").addEventListener("change", e => toggleKeepAlive(e.target.checked));

  $("qq-pwd").addEventListener("keydown", e => {
    if (e.key === "Enter") passwordLogin();
  });

  document.addEventListener("keydown", e => {
    if (e.key === "Escape") closeDrawer();
  });

  window.onAndroidBack = function () {
    if (document.body.classList.contains("drawer-open")) {
      closeDrawer();
      return true;
    }
    if (state.page !== "home") {
      gotoPage("home");
      return true;
    }
    return false;
  };

  document.addEventListener("visibilitychange", () => {
    if (document.hidden) {
      stopQQTimer();
      stopLogTimer();
    } else if (state.page === "qq") {
      refreshQQ();
      startQQTimer();
    } else if (state.page === "logs") {
      loadLogs();
      startLogTimer();
    }
  });

  /* ---------- 启动 ---------- */
  loadSavedCred();
  loadNavConfig();
  $("drawer-server").textContent = serverLabel();
  if (USE_BRIDGE) {
    const homeStatus = $("home-status");
    if (homeStatus && homeStatus.textContent.indexOf("电脑端") !== -1) {
      homeStatus.textContent = LOCAL_MODE ? "正在连接本机服务" : "正在连接服务器";
    }
    const panelLink = document.getElementById("btn-desktop-panel");
    if (panelLink) panelLink.style.display = "none";
    if (LOCAL_MODE) {
      const switchButton = document.getElementById("btn-switch-server");
      if (switchButton) switchButton.style.display = "none";
      const logoutItem = document.querySelector(".nav-item.danger");
      if (logoutItem) logoutItem.style.display = "none";
    }
  }

  // HTML 里用 onclick 调用的函数需要挂到 window 上
  window.gotoPage = gotoPage;
  window.refreshAll = refreshAll;
  window.refreshQr = refreshQr;
  window.restartGateway = restartGateway;
  window.passwordLogin = passwordLogin;
  window.repairQuickLogin = repairQuickLogin;
  window.loadAccounts = loadAccounts;
  window.saveAiConfig = saveAiConfig;
  window.saveImageConfig = saveImageConfig;
  window.loadPlugins = loadPlugins;
  window.pickPluginFile = pickPluginFile;
  window.importPluginFile = importPluginFile;
  window.loadLogs = loadLogs;
  window.switchServer = switchServer;
  window.requestBattery = requestBattery;
  window.openAppSettings = openAppSettings;
  window.logoutApp = logoutApp;
  window.startBot = startBot;
  window.stopBot = stopBot;
  window.exportConfigBundle = exportConfigBundle;
  window.importConfigBundle = importConfigBundle;
  window.loadKb = loadKb;
  window.loadKbDocs = loadKbDocs;
  window.addKbDoc = addKbDoc;
  window.importKbDocs = importKbDocs;
  window.searchKb = searchKb;
  window.loadMem = loadMem;
  window.loadMemList = loadMemList;
  window.addMem = addMem;
  window.loadStickers = loadStickers;
  window.uploadStickers = uploadStickers;
  window.loadAuto = loadAuto;
  window.saveAuto = saveAuto;
  window.loadOmni = loadOmni;
  window.saveOmni = saveOmni;
  window.createOmniFromIdea = createOmniFromIdea;
  window.onOmniTriggerChange = onOmniTriggerChange;
  window.resetOmniForm = resetOmniForm;
  window.editOmni = editOmni;
  window.toggleOmni = toggleOmni;
  window.deleteOmni = deleteOmni;
  window.loadAdm = loadAdm;
  window.loadConsole = loadConsole;
  window.saveConsole = saveConsole;
  window.testNotify = testNotify;
  window.addConsoleGroup = addConsoleGroup;
  window.toggleConsoleGroup = toggleConsoleGroup;
  window.loadNavSettings = loadNavSettings;
  window.toggleNavItem = toggleNavItem;
  window.moveNavItem = moveNavItem;
  window.saveNavConfig = saveNavConfig;
  window.loadAdmPerms = loadAdmPerms;
  window.saveAdm = saveAdm;
  window.loadDiagnostics = loadDiagnostics;
  window.closeUpdate = closeUpdate;
  window.skipUpdate = skipUpdate;
  window.closeNotice = closeNotice;

  refreshStatus().then(async () => {
    loadAndroidStatus();
    // 启动时自动检查更新；有新版本就弹窗，没有则静默
    const updateShown = await bootUpdate();
    if (!updateShown) await bootNotice();
  });
  setInterval(() => {
    if (!document.hidden) refreshStatus();
  }, 6000);
})();
