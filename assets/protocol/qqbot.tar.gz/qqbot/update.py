#!/usr/bin/env python3
"""QQBot Linux 增量更新脚本。

用法（把更新包或更新后的文件放到 /root/gengxin，然后在服务器上执行）：

    python3 /root/gengxin/update.py                 # 自动找 /root/gengxin 里的更新包
    python3 /root/gengxin/update.py --dir /opt/qqbot
    python3 /root/gengxin/update.py --package /root/gengxin/xxx.zip

支持三种上传形式：
  1. 直接上传 qqbot/ 与 app/mobile/（脚本会就地复制）
  2. 上传一个 zip / tar.gz（脚本会自己解压）
  3. 上传发布脚本生成的 Linux 更新包（带 manifest.json，会校验文件哈希）

脚本只替换程序文件，永远不会碰 config/、data/、plugins_ext/。
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tarfile
import tempfile
import time
import zipfile
from pathlib import Path

DEFAULT_APP_DIR = Path("/opt/qqbot")
DEFAULT_SRC_DIR = Path("/root/gengxin")
DEFAULT_SERVICE = "qqbot"
FORMAT = "qqbot-update"
KEEP_BACKUPS = 3


def say(message: str) -> None:
    print(f"[gengxin] {message}", flush=True)


def fail(message: str) -> "NoReturn":  # type: ignore[name-defined]
    print(f"[gengxin] 失败：{message}", file=sys.stderr, flush=True)
    sys.exit(1)


def _safe_extract(package: Path, target: Path) -> None:
    """解压更新包，挡住 ../ 越界与符号链接。"""
    target.mkdir(parents=True, exist_ok=True)
    if package.suffix.lower() == ".zip":
        with zipfile.ZipFile(package) as bundle:
            if bundle.testzip() is not None:
                fail("更新包已损坏")
            for member in bundle.infolist():
                name = member.filename.replace("\\", "/")
                if name.startswith("/") or ".." in name.split("/"):
                    fail(f"更新包里有越界路径：{member.filename}")
            bundle.extractall(target)
        return
    with tarfile.open(package, "r:*") as bundle:
        for member in bundle.getmembers():
            if member.issym() or member.islnk():
                fail(f"更新包里有链接文件：{member.name}")
            if member.name.startswith("/") or ".." in member.name.split("/"):
                fail(f"更新包里有越界路径：{member.name}")
        try:
            bundle.extractall(target, filter="data")
        except TypeError:  # Python < 3.12
            bundle.extractall(target)


def find_package(src: Path) -> tuple[Path, tempfile.TemporaryDirectory | None]:
    """找到要安装的内容：目录（qqbot/ 已就绪）或压缩包。"""
    if (src / "qqbot").is_dir():
        return src, None

    archives = [
        item
        for item in src.iterdir()
        if item.is_file() and item.suffix.lower() in (".zip", ".gz", ".tgz")
    ]
    if not archives:
        fail(f"{src} 里没有 qqbot/ 目录，也没有 zip/tar.gz 更新包")
    package = max(archives, key=lambda item: item.stat().st_mtime)
    temp = tempfile.TemporaryDirectory(prefix="qqbot-gengxin-")
    target = Path(temp.name)
    _safe_extract(package, target)
    say(f"已解压 {package.name}")
    root = _locate_qqbot(target)
    if root is None:
        fail("更新包里找不到 qqbot/ 目录")
    return root, temp


def _locate_qqbot(base: Path) -> Path | None:
    if (base / "qqbot").is_dir():
        return base
    for child in base.iterdir():
        if child.is_dir() and (child / "qqbot").is_dir():
            return child
    return None


def verify_manifest(source: Path) -> dict:
    manifest_path = source / "manifest.json"
    if not manifest_path.is_file():
        return {}
    try:
        manifest = json.loads(manifest_path.read_text("utf-8"))
    except (OSError, ValueError):
        fail("manifest.json 无法解析")
    if manifest.get("format") != FORMAT:
        return {}
    if manifest.get("platform") != "linux":
        fail("这不是 Linux 更新包")
    for item in manifest.get("files") or []:
        rel = str(item.get("path") or "")
        expected = str(item.get("sha256") or "")
        if not rel or not expected:
            continue
        path = source / rel
        if not path.is_file():
            fail(f"更新包缺少文件：{rel}")
        if hashlib.sha256(path.read_bytes()).hexdigest() != expected:
            fail(f"文件校验失败：{rel}")
    say(
        f"更新包版本 {manifest.get('version') or '未知'}，"
        f"{'全量' if manifest.get('full') else '增量'}包，文件校验通过"
    )
    return manifest


def service_active(service: str) -> bool:
    try:
        result = subprocess.run(
            ["systemctl", "is-active", "--quiet", service], timeout=10
        )
        return result.returncode == 0
    except (OSError, subprocess.SubprocessError):
        return False


def service_action(action: str, service: str) -> None:
    try:
        subprocess.run(["systemctl", action, service], timeout=60)
    except (OSError, subprocess.SubprocessError) as exc:
        say(f"systemctl {action} {service} 失败：{exc}")


def backup(app_dir: Path, source: Path) -> Path:
    stamp = time.strftime("%Y%m%d-%H%M%S")
    target = source / "backup" / stamp
    target.mkdir(parents=True, exist_ok=True)
    for name in ("qqbot", "run.py", "app/mobile", "config/config.json"):
        src = app_dir / name
        if not src.exists():
            continue
        dst = target / name
        dst.parent.mkdir(parents=True, exist_ok=True)
        if src.is_dir():
            shutil.copytree(src, dst, ignore=shutil.ignore_patterns("__pycache__", "*.pyc"))
        else:
            shutil.copy2(src, dst)
    say(f"已备份到 {target}")
    _prune_backups(source / "backup")
    return target


def _prune_backups(base: Path) -> None:
    if not base.is_dir():
        return
    items = sorted([p for p in base.iterdir() if p.is_dir()], key=lambda p: p.name)
    for old in items[:-KEEP_BACKUPS]:
        shutil.rmtree(old, ignore_errors=True)


def _replace_tree(app_dir: Path, source: Path, name: str) -> None:
    incoming = source / name
    if not incoming.is_dir():
        return
    staging = app_dir / f".{name.replace('/', '-')}.new"
    shutil.rmtree(staging, ignore_errors=True)
    shutil.copytree(incoming, staging, ignore=shutil.ignore_patterns("__pycache__", "*.pyc"))
    target = app_dir / name
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.rmtree(target, ignore_errors=True)
    os.replace(staging, target)
    say(f"已更新 {name}")


def _merge_tree(app_dir: Path, source: Path, name: str, deleted: list[str]) -> None:
    """增量包只覆盖改动文件，不能删掉旧目录里的其他模块。"""
    incoming = source / name
    if not incoming.is_dir():
        return
    target = app_dir / name
    target.mkdir(parents=True, exist_ok=True)
    count = 0
    for path in incoming.rglob("*"):
        if not path.is_file() or "__pycache__" in path.parts or path.suffix == ".pyc":
            continue
        dest = target / path.relative_to(incoming)
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(path, dest)
        count += 1
    prefix = name.rstrip("/") + "/"
    for rel in deleted:
        rel = str(rel).replace("\\", "/")
        if not rel.startswith(prefix):
            continue
        victim = target / rel[len(prefix):]
        try:
            if victim.is_file():
                victim.unlink()
        except OSError:
            pass
    say(f"已合并 {name}（{count} 个文件）")


def _copy_file(app_dir: Path, source: Path, name: str) -> None:
    incoming = source / name
    if incoming.is_file():
        shutil.copy2(incoming, app_dir / name)
        say(f"已更新 {name}")


def _remove_pycache(root: Path) -> None:
    for cache in root.rglob("__pycache__"):
        shutil.rmtree(cache, ignore_errors=True)


def _verify(app_dir: Path) -> str:
    python = app_dir / ".venv" / "bin" / "python"
    if not python.is_file():
        python = Path(sys.executable)
    env = dict(os.environ)
    env["PYTHONPATH"] = str(app_dir)
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    result = subprocess.run(
        [str(python), "-c", "import qqbot, qqbot.main; print(qqbot.__version__)"],
        cwd=str(app_dir), env=env, capture_output=True, text=True, timeout=60,
    )
    if result.returncode != 0:
        fail("新版本导入自检失败：\n" + (result.stderr or result.stdout).strip())
    return (result.stdout or "").strip()


def fix_panel(app_dir: Path, host: str, port: int, service: str) -> None:
    """修复导入配置后面板打不开：强制恢复监听地址与端口。"""
    path = app_dir / "config" / "config.json"
    if not path.is_file():
        fail(f"找不到配置文件：{path}")
    try:
        data = json.loads(path.read_text("utf-8"))
    except (OSError, ValueError) as exc:
        fail(f"配置文件无法解析：{exc}")
    webui = data.setdefault("webui", {})
    webui["enabled"] = True
    webui["host"] = host
    webui["port"] = int(port)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    say(f"面板已设为 {host}:{port}，访问密码保留原值")
    # 服务可能是 failed/inactive 状态，restart 会顺手把它拉起来；
    # 不能只在 active 时才重启，否则修完配置页面还是打不开。
    say(f"重启服务 {service}")
    service_action("restart", service)
    if service_active(service):
        say("服务已启动，访问面板试试")
    else:
        say("服务没有起来，请执行：sudo journalctl -u %s -n 100 --no-pager" % service)


def main() -> int:
    parser = argparse.ArgumentParser(description="QQBot Linux 增量更新")
    parser.add_argument("--dir", default=str(DEFAULT_APP_DIR), help="安装目录")
    parser.add_argument("--src", default=str(DEFAULT_SRC_DIR), help="更新文件所在目录")
    parser.add_argument("--package", default="", help="指定更新包（zip/tar.gz）")
    parser.add_argument("--service", default=DEFAULT_SERVICE, help="systemd 服务名")
    parser.add_argument("--no-restart", action="store_true", help="只替换文件，不重启服务")
    parser.add_argument("--fix-panel", action="store_true", help="只修复面板监听地址与端口")
    parser.add_argument("--panel-host", default="0.0.0.0", help="修复面板时使用的监听地址")
    parser.add_argument("--panel-port", type=int, default=6199, help="修复面板时使用的端口")
    args = parser.parse_args()

    app_dir = Path(args.dir).resolve()
    src = Path(args.src).resolve()
    if not (app_dir / "run.py").is_file() or not (app_dir / "qqbot").is_dir():
        fail(f"{app_dir} 不像 QQBot 安装目录（缺少 run.py 或 qqbot/）")
    if not src.is_dir():
        fail(f"更新目录不存在：{src}")

    if args.fix_panel:
        fix_panel(app_dir, args.panel_host, args.panel_port, args.service)
        return 0

    temp = None
    if args.package:
        package = Path(args.package).resolve()
        if not package.is_file():
            fail(f"更新包不存在：{package}")
        # 统一走 find_package：复制到临时目录后按压缩包处理
        temp = tempfile.TemporaryDirectory(prefix="qqbot-gengxin-")
        target = Path(temp.name)
        _safe_extract(package, target)
        source = _locate_qqbot(target)
        if source is None:
            fail("更新包里找不到 qqbot/ 目录")
    else:
        source, temp = find_package(src)

    try:
        manifest = verify_manifest(source)
        full = bool(manifest.get("full")) if manifest else True
        deleted = list(manifest.get("deleted") or []) if manifest else []
        was_active = service_active(args.service)
        if was_active:
            say(f"停止服务 {args.service}")
            service_action("stop", args.service)
            time.sleep(1.0)

        backup_dir = backup(app_dir, src)
        try:
            if full:
                _replace_tree(app_dir, source, "qqbot")
                _replace_tree(app_dir, source, "app/mobile")
            else:
                _merge_tree(app_dir, source, "qqbot", deleted)
                _merge_tree(app_dir, source, "app/mobile", deleted)
            _copy_file(app_dir, source, "run.py")
            # 更新包自带新版权更新脚本时，顺手覆盖 /root/gengxin/update.py
            next_script = source / "update.py"
            current_script = src / "update.py"
            if next_script.is_file() and next_script.resolve() != current_script.resolve():
                shutil.copy2(next_script, current_script)
                say("已更新 update.py")
            _remove_pycache(app_dir / "qqbot")
            version = _verify(app_dir)
            say(f"新版本自检通过：{version}")
        except SystemExit:
            say("更新失败，正在回滚")
            rollback = backup_dir
            _replace_tree(app_dir, rollback, "qqbot")
            _replace_tree(app_dir, rollback, "app/mobile")
            if (rollback / "run.py").is_file():
                shutil.copy2(rollback / "run.py", app_dir / "run.py")
            if was_active:
                service_action("start", args.service)
            raise

        if was_active and not args.no_restart:
            say(f"重启服务 {args.service}")
            service_action("start", args.service)
        say("更新完成")
        return 0
    finally:
        if temp is not None:
            temp.cleanup()


if __name__ == "__main__":
    sys.exit(main())
