"""QQBot BotTeacher 知识导师插件 v1.0.0

菲比给群里的其他机器人当老师：
  - 自动识别群里的机器人（QQ 名单 / 昵称特征）
  - 别的机器人说的话命中教学词条 → 回复知识内容（教学）
  - 别的机器人提问且没有词条 → 可选用大模型答疑（严格限频）
  - 主人随时「教机器人：<触发词>：<内容>」当场教新知识
  - 反刷屏/防死循环：同群冷却 + 同机器人冷却 + 每日上限

与现有体系的关系（增量，不破坏原有功能）：
  - 不依赖 humanlike/lang_memory；独立词条库存放在本插件数据目录
  - 优先级 19：抢在 humanlike(20)/auto(40) 之前处理机器人消息，
    命中教学后 STOP，避免 AI 再重复回复
  - 大模型答疑复用共享 chat_client（与内置插件同一实例）

管理员指令：
  /teacher 添加 <触发词> <内容> | 列表 | 删除 <id> | 开 <id> | 关 <id>
  /teacher 状态 | 开关 on|off | 测试 <模拟机器人消息>
自然语言教学（仅主人）：
  教机器人：<触发词>：<内容>
"""

from __future__ import annotations

import asyncio
import re
import time
from pathlib import Path
from typing import Any

from qqbot.core.bus import STOP
from qqbot.plugins.base import Plugin

from . import store

_QUESTION_RE = re.compile(r"什么|怎么|为什么|如何|多少|几[点个岁]|吗[??]?|？|\?")
_TEACH_NATURAL_RE = re.compile(r"^教机器人[:：\s]+")


class BotTeacherPlugin(Plugin):
    name = "bot_teacher"
    display_name = "知识导师"
    version = "1.0.0"
    description = "识别群里的其他机器人并教它们知识：词条教学 + 大模型答疑，防死循环限频"
    priority = 19  # 早于 humanlike(20)：机器人消息先看要不要教学

    default_config = {
        "enabled": True,
        "bot_qq_list": [],            # 已确知的机器人 QQ（数字）
        "detect_by_name": True,       # 按昵称特征自动识别机器人
        "name_keywords": ["bot", "机器人", "ai", "assistant", "助手"],
        "group_cooldown": 60,         # 同群两次教学最小间隔（秒）
        "per_bot_cooldown": 300,      # 同一机器人在同群两次教学间隔（秒）
        "daily_limit_per_group": 20,  # 每群每日教学上限
        "answer_questions": True,     # 未命中词条时用大模型答疑
        "question_daily_limit": 6,    # 每群每日 LLM 答疑上限（防烧 token）
        "max_teach_chars": 400,       # 答疑最大长度（词条内容不裁剪）
    }

    config_labels = {
        "enabled": "启用知识导师",
        "bot_qq_list": "机器人 QQ 名单（逗号分隔）",
        "detect_by_name": "按昵称自动识别机器人",
        "name_keywords": "昵称特征关键词（逗号分隔）",
        "group_cooldown": "同群教学间隔（秒）",
        "per_bot_cooldown": "同一机器人教学间隔（秒）",
        "daily_limit_per_group": "每群每日教学上限",
        "answer_questions": "未命中时用大模型答疑",
        "question_daily_limit": "每群每日答疑上限",
    }

    def __init__(self, bot) -> None:
        super().__init__(bot)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self._conn = store.connect(self.data_dir / "teacher.sqlite3")
        store.ensure_schema(self._conn)
        self._last_group_teach: dict[str, float] = {}   # group -> ts
        self._last_bot_teach: dict[tuple[str, str], float] = {}

    # ---------- 生命周期 ----------

    async def on_load(self) -> None:
        if not self.cfg_get("enabled", True):
            return
        self.add_command(
            "teacher", self._cmd, aliases=("导师",),
            admin=True, description="知识导师：添加/列表/删除/状态/测试")
        self.log.info("知识导师已启用（词条 %d 条，答疑=%s）",
                      len(store.list_entries(self._conn, True)),
                      self.cfg_get("answer_questions", True))

    # ---------- 机器人识别 ----------

    def _is_bot(self, m: dict[str, Any]) -> bool:
        try:
            known = {int(q) for q in (self.cfg_get("bot_qq_list", []) or [])}
        except (TypeError, ValueError):
            known = set()
        if m["user_id"] in known:
            return True
        if not self.cfg_get("detect_by_name", True):
            return False
        nick = (m["nickname"] or "").lower()
        kws = self.cfg_get("name_keywords", None) or \
            ("bot", "机器人", "ai", "assistant", "助手")
        return any(str(k).lower() in nick for k in kws)

    # ---------- 频控 ----------

    def _rate_ok(self, group_id: str, bot_id: str) -> tuple[bool, str]:
        now = time.time()
        g_cd = max(0, int(self.cfg_get("group_cooldown", 60)))
        if now - self._last_group_teach.get(group_id, 0) < g_cd:
            return False, "同群冷却中"
        b_cd = max(0, int(self.cfg_get("per_bot_cooldown", 300)))
        key = (group_id, bot_id)
        if now - self._last_bot_teach.get(key, 0) < b_cd:
            return False, "同一机器人冷却中"
        total_today = store.today_events(self._conn, group_id, "entry") + \
            store.today_events(self._conn, group_id, "llm")
        if total_today >= max(1, int(self.cfg_get("daily_limit_per_group", 20))):
            return False, "该群今日教学已达上限"
        return True, ""

    def _mark_teach(self, group_id: str, bot_id: str) -> None:
        now = time.time()
        self._last_group_teach[group_id] = now
        self._last_bot_teach[(group_id, bot_id)] = now

    # ---------- 消息入口 ----------

    async def on_message(self, ctx) -> Any:
        if not self.cfg_get("enabled", True):
            return None
        m = self._norm(ctx)
        if not m["text"]:
            return None

        # 主人自然语言教学：「教机器人：<触发词>：<内容>」
        if m["is_admin"] and _TEACH_NATURAL_RE.match(m["text"]):
            await self._teach_natural(ctx, m["text"])
            return self.stop()

        # 只在群聊里教学；不教自己的消息
        if not m["is_group"] or m["user_id"] == getattr(self.bot, "self_id", 0):
            return None
        if not self._is_bot(m):
            return None

        group_id = str(m["group_id"])
        bot_id = str(m["user_id"])
        ok, why = self._rate_ok(group_id, bot_id)
        if not ok:
            store.record_event(self._conn, group_id, bot_id,
                               m["nickname"], None, "skipped")
            self.log.debug("教学限频（%s）：群%s bot%s", why, group_id, bot_id)
            return None

        # 词条命中 → 教学
        entry = store.match_entry(self._conn, m["text"], group_id)
        if entry is not None:
            await self._safe_reply(ctx, entry["content"])
            store.bump_hits(self._conn, int(entry["id"]))
            store.record_event(self._conn, group_id, bot_id, m["nickname"],
                               int(entry["id"]), "entry")
            self._mark_teach(group_id, bot_id)
            self.log.info("教学：群%s → %s（词条#%s「%s」）",
                          group_id, m["nickname"], entry["id"], entry["trigger"])
            return self.stop()

        # 未命中 → 大模型答疑（可关）
        if not self.cfg_get("answer_questions", True):
            return None
        if not _QUESTION_RE.search(m["text"]):
            return None  # 不是提问，不理
        if store.today_events(self._conn, group_id, "llm") >= \
                max(0, int(self.cfg_get("question_daily_limit", 6))):
            return None
        answer = await self._llm_teach(m)
        if answer:
            await self._safe_reply(
                ctx, answer[:int(self.cfg_get("max_teach_chars", 400))])
            store.record_event(self._conn, group_id, bot_id, m["nickname"],
                               None, "llm")
            self._mark_teach(group_id, bot_id)
            self.log.info("答疑：群%s → %s：%s", group_id, m["nickname"],
                          m["text"][:30])
            return self.stop()  # 教学接管，避免 AI 再重复回复
        return None

    # ---------- 教学 ----------

    async def _teach_natural(self, ctx, text: str) -> None:
        body = _TEACH_NATURAL_RE.sub("", text, count=1).strip()
        parts = [p.strip() for p in re.split(r"[:：=]", body, maxsplit=1)
                 if p.strip()]
        if len(parts) < 2:
            await self._safe_reply(
                ctx, "这样教我：教机器人：触发词：要教的内容\n"
                     "例如：教机器人：怎么开摆：开摆三步：躺下、关机、睡着")
            return
        trigger, content = parts[0], parts[1]
        if len(trigger) > 40 or len(content) > 800:
            await self._safe_reply(ctx, "太长了教不进来（触发词≤40字，内容≤800字）")
            return
        eid = store.add_entry(self._conn, trigger, content)
        await self._safe_reply(
            ctx, f"学会啦（词条#{eid}）。别的机器人说到「{trigger}」我就教它这段。")
        self.log.info("主人教学成功 #%s：%s", eid, trigger)

    async def _llm_teach(self, m: dict[str, Any]) -> str:
        """用大模型以「老师」口吻回答机器人的问题。"""
        try:
            client = self.bot.chat_client()
            prompt = (f"群里的另一个机器人（{m['nickname']}）问：{m['text']}\n"
                      "你是群里的知识导师菲比。用最多两句话、口语一点把知识点讲清楚，"
                      "像给同行科普，不要客套不要反问。"
                      "如果确实不知道就说「这个我也不太确定」。")
            return (await asyncio.wait_for(
                client.chat(f"teach_{m['group_id']}", prompt, ""),
                timeout=45)) or ""
        except Exception as exc:  # noqa: BLE001
            self.log.debug("答疑失败: %s", exc)
            return ""

    async def _safe_reply(self, ctx, message: str) -> None:
        try:
            await ctx.reply(message)
        except Exception as exc:  # noqa: BLE001
            self.log.warning("教学回复失败: %s", exc)

    # ---------- 轻量 normalize（独立插件不依赖 humanlike） ----------

    def _norm(self, ctx) -> dict[str, Any]:
        event = getattr(ctx, "event", ctx)
        sender = getattr(event, "sender", None) or {}
        try:
            uid = int(getattr(event, "user_id", 0) or 0)
        except (TypeError, ValueError):
            uid = 0
        gid = getattr(event, "group_id", None)
        try:
            gid = int(gid) if gid else None
        except (TypeError, ValueError):
            gid = None
        return {
            "user_id": uid,
            "group_id": gid,
            "is_group": gid is not None,
            "nickname": str(sender.get("card") or sender.get("nickname")
                            or uid or ""),
            "text": str(getattr(event, "text", "") or "").strip(),
            "is_admin": bool(getattr(ctx, "is_admin", False)),
        }

    # ---------- 管理指令 ----------

    async def _cmd(self, ctx, args: str) -> Any:
        a = (args or "").strip()
        head, _, rest = a.partition(" ")
        rest = rest.strip()

        if head in ("", "状态", "status"):
            st = store.stats(self._conn)
            lines = ["【知识导师】",
                     f"开关：{'开' if self.cfg_get('enabled', True) else '关'} · "
                     f"答疑：{'开' if self.cfg_get('answer_questions', True) else '关'}",
                     f"词条：{st['entries']} 条（启用 {st['enabled']}）· "
                     f"已教学 {st['taught_total']} 次 · 答疑 {st['llm_total']} 次"]
            if st["top"]:
                lines.append("最常教：" + "；".join(
                    f"「{t}」×{h}" for t, h in st["top"] if h > 0))
            lines.append("教新知识：教机器人：触发词：内容")
            await ctx.reply("\n".join(lines))
            return self.stop()

        if head == "开关" and rest in ("on", "off", "开", "关"):
            self.cfg["enabled"] = rest in ("on", "开")
            self.save_config()
            await ctx.reply("知识导师已"
                            + ("开启。" if self.cfg["enabled"] else "关闭。"))
            return self.stop()

        if head in ("添加", "add"):
            kw, _, content = rest.partition(" ")
            kw = kw.strip()
            content = content.strip()
            if not kw or not content:
                await ctx.reply("用法：/teacher 添加 触发词 内容")
                return self.stop()
            eid = store.add_entry(self._conn, kw, content)
            await ctx.reply(f"词条 #{eid} 已添加：听到「{kw}」就教那段。")
            return self.stop()

        if head in ("列表", "list"):
            entries = store.list_entries(self._conn)
            if not entries:
                await ctx.reply("还没有教学词条。用「教机器人：触发词：内容」教我。")
                return self.stop()
            lines = [f"#{e['id']} {'✓' if e['enabled'] else '✗'} "
                     f"「{e['trigger']}」×{e['hits']}：{e['content'][:30]}"
                     for e in entries[:15]]
            if len(entries) > 15:
                lines.append(f"…共 {len(entries)} 条")
            await ctx.reply("\n".join(lines))
            return self.stop()

        if head in ("删除", "del") and rest.isdigit():
            n = store.delete_entry(self._conn, int(rest))
            await ctx.reply(f"已删除词条 #{rest}（{n}）。"
                            if n else f"没有 #{rest} 这条。")
            return self.stop()

        if head in ("开", "关") and rest.isdigit():
            n = store.set_enabled(self._conn, int(rest), head == "开")
            await ctx.reply(f"词条 #{rest} 已{'启用' if head == '开' else '停用'}。"
                            if n else f"没有 #{rest} 这条。")
            return self.stop()

        if head in ("测试", "test"):
            if not rest:
                await ctx.reply("用法：/teacher 测试 <模拟机器人消息>")
                return self.stop()
            entry = store.match_entry(self._conn, rest, "")
            await ctx.reply(f"命中词条 #{entry['id']}「{entry['trigger']}」"
                            if entry else "没有词条命中这条消息。")
            return self.stop()

        await ctx.reply("用法：/teacher 状态｜开关 on|off｜添加 <触发词> <内容>｜"
                        "列表｜删除 <id>｜开/关 <id>｜测试 <消息>")
        return self.stop()
