"""bot_teacher store — 教学词条库（SQLite）。

表：
  entries  教学词条（触发词 → 知识内容，可按群限定范围）
  events   教学事件流水（谁在哪个群被教了什么，用于统计与审计）
"""

from __future__ import annotations

import sqlite3
import time
from pathlib import Path
from typing import Any

SCHEMA = """
CREATE TABLE IF NOT EXISTS entries(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  trigger TEXT NOT NULL,          -- 触发词（逗号/、分隔多关键词）
  content TEXT NOT NULL,          -- 要教的知识内容（原样回复）
  scope_group TEXT DEFAULT '',    -- 限定群号；'' = 所有群
  enabled INTEGER DEFAULT 1,
  hits INTEGER DEFAULT 0,
  created_at REAL,
  updated_at REAL
);
CREATE TABLE IF NOT EXISTS events(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ts REAL,
  group_id TEXT,
  bot_id TEXT,
  bot_name TEXT,
  entry_id INTEGER,               -- NULL = LLM 答疑
  kind TEXT                       -- entry / llm / skipped
);
CREATE INDEX IF NOT EXISTS idx_events_ts ON events(ts);
"""


def connect(path: Path) -> sqlite3.Connection:
    conn = sqlite3.connect(str(path), check_same_thread=False, timeout=10)
    conn.row_factory = sqlite3.Row
    return conn


def ensure_schema(conn: sqlite3.Connection) -> None:
    conn.executescript(SCHEMA)
    conn.commit()


def add_entry(conn: sqlite3.Connection, trigger: str, content: str,
              scope_group: str = "") -> int:
    now = time.time()
    cur = conn.execute(
        "INSERT INTO entries(trigger, content, scope_group, enabled, hits,"
        " created_at, updated_at) VALUES(?,?,?,1,0,?,?)",
        (trigger.strip(), content.strip(), scope_group, now, now))
    conn.commit()
    return int(cur.lastrowid)


def list_entries(conn: sqlite3.Connection,
                 only_enabled: bool = False) -> list[dict[str, Any]]:
    sql = "SELECT * FROM entries"
    if only_enabled:
        sql += " WHERE enabled=1"
    sql += " ORDER BY id DESC"
    return [dict(r) for r in conn.execute(sql).fetchall()]


def delete_entry(conn: sqlite3.Connection, entry_id: int) -> int:
    cur = conn.execute("DELETE FROM entries WHERE id=?", (entry_id,))
    conn.commit()
    return cur.rowcount


def set_enabled(conn: sqlite3.Connection, entry_id: int, enabled: bool) -> int:
    cur = conn.execute("UPDATE entries SET enabled=?, updated_at=? WHERE id=?",
                       (1 if enabled else 0, time.time(), entry_id))
    conn.commit()
    return cur.rowcount


def _scope_ok(row: sqlite3.Row, group_id: str) -> bool:
    scope = str(row["scope_group"] or "")
    return scope == "" or scope == str(group_id)


def match_entry(conn: sqlite3.Connection, text: str, group_id: str):
    """按触发词匹配词条：返回命中的词条 dict 或 None。

    触发词用逗号/、/空格分隔多个关键词，命中任一即匹配；
    英文关键词不区分大小写。多词条命中时取 id 最小（最早教的优先）。
    """
    t = (text or "").strip()
    if not t:
        return None
    low = t.lower()
    for row in conn.execute("SELECT * FROM entries WHERE enabled=1 ORDER BY id"):
        if not _scope_ok(row, group_id):
            continue
        kws = [k for k in row["trigger"].replace("，", ",").replace("、", ",")
               .replace(" ", ",").split(",") if k.strip()]
        for k in kws:
            k = k.strip()
            if not k:
                continue
            if k.lower() in low:
                return dict(row)
    return None


def bump_hits(conn: sqlite3.Connection, entry_id: int) -> None:
    conn.execute("UPDATE entries SET hits=hits+1, updated_at=? WHERE id=?",
                 (time.time(), entry_id))
    conn.commit()


def record_event(conn: sqlite3.Connection, group_id: str, bot_id: str,
                 bot_name: str, entry_id: int | None, kind: str) -> None:
    conn.execute(
        "INSERT INTO events(ts, group_id, bot_id, bot_name, entry_id, kind)"
        " VALUES(?,?,?,?,?,?)",
        (time.time(), str(group_id), str(bot_id), bot_name, entry_id, kind))
    conn.commit()


def today_events(conn: sqlite3.Connection, group_id: str, kind: str) -> int:
    day_start = time.time() - (time.time() % 86400)  # UTC 日界，够用
    row = conn.execute(
        "SELECT COUNT(*) c FROM events WHERE group_id=? AND kind=? AND ts>=?",
        (str(group_id), kind, day_start)).fetchone()
    return int(row["c"] or 0)


def stats(conn: sqlite3.Connection) -> dict[str, Any]:
    entries = conn.execute("SELECT COUNT(*) c FROM entries").fetchone()["c"]
    enabled = conn.execute(
        "SELECT COUNT(*) c FROM entries WHERE enabled=1").fetchone()["c"]
    taught = conn.execute(
        "SELECT COUNT(*) c FROM events WHERE kind='entry'").fetchone()["c"]
    llm = conn.execute(
        "SELECT COUNT(*) c FROM events WHERE kind='llm'").fetchone()["c"]
    top = conn.execute(
        "SELECT trigger, hits FROM entries ORDER BY hits DESC, id LIMIT 3").fetchall()
    return {
        "entries": int(entries), "enabled": int(enabled),
        "taught_total": int(taught), "llm_total": int(llm),
        "top": [(r["trigger"], int(r["hits"])) for r in top],
    }
