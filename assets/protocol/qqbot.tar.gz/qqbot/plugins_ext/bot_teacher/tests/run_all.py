"""bot_teacher 测试套件：存储/识别/频控/教学/指令（离线，不调 LLM、不连 QQ）。

运行：cd /opt/qqbot && python3 plugins_ext/bot_teacher/tests/run_all.py
本地（无 qqbot 运行时、目录名 bt_dev）也可直接 python3 run_all.py —— 自动打桩。
"""

from __future__ import annotations

import asyncio
import sys
import tempfile
import time
from pathlib import Path
from types import SimpleNamespace

# ---- qqbot 运行时：服务器直接用，本地打桩 ----
try:
    from qqbot.core.bus import STOP  # noqa: F401
except ImportError:
    import types as _t
    _qqbot = _t.ModuleType("qqbot")
    _core = _t.ModuleType("qqbot.core")
    _bus = _t.ModuleType("qqbot.core.bus")
    _bus.STOP = "STOP"
    _msg = _t.ModuleType("qqbot.core.message")
    _msg.Message = type("Message", (), {})
    _plugins = _t.ModuleType("qqbot.plugins")
    _base = _t.ModuleType("qqbot.plugins.base")

    class _Plugin:
        priority = 50

        def __init__(self, bot=None):
            import logging
            self.bot = bot
            self.cfg = dict(getattr(self, "default_config", {}) or {})
            self._cmds = {}
            self.log = logging.getLogger("stub")

        @property
        def data_dir(self):
            return self.bot.config.paths.plugin_data_dir / self.name

        def cfg_get(self, key, default=None):
            return self.cfg.get(key, default)

        def save_config(self):
            pass

        def add_command(self, name, handler, **kw):
            self._cmds[name] = (handler, kw)

        @staticmethod
        def stop():
            return _bus.STOP

    _base.Plugin = _Plugin
    _qqbot.core = _core
    _core.bus = _bus
    _core.message = _msg
    _qqbot.plugins = _plugins
    _plugins.base = _base
    for _n, _m in {"qqbot": _qqbot, "qqbot.core": _core, "qqbot.core.bus": _bus,
                   "qqbot.core.message": _msg, "qqbot.plugins": _plugins,
                   "qqbot.plugins.base": _base}.items():
        sys.modules[_n] = _m
    from qqbot.core.bus import STOP  # noqa: F401

_PKG = Path(__file__).resolve().parent.parent
for _p in ("/opt/qqbot/plugins_ext", "/opt/qqbot", str(_PKG.parent)):
    if _p not in sys.path:
        sys.path.insert(0, _p)

# 包名统一为 bot_teacher：服务器直接导入；本地目录叫 bt_dev 时做别名
try:
    import bot_teacher  # noqa: F401
except ImportError:
    import bt_dev as bot_teacher  # noqa: F401
    sys.modules.setdefault("bot_teacher", bot_teacher)

PASS = FAIL = 0


def check(name, cond, detail=""):
    global PASS, FAIL
    if cond:
        PASS += 1
        print(f"  ✓ {name}")
    else:
        FAIL += 1
        print(f"  ✗ {name} {detail}")


def t_store():
    print("[1] 词条存储：增删改查/匹配/作用域/统计")
    from bot_teacher import store
    conn = store.connect(Path(tempfile.mkdtemp()) / "t.db")
    store.ensure_schema(conn)
    e1 = store.add_entry(conn, "怎么开摆", "开摆三步：躺下、关机、睡着")
    e2 = store.add_entry(conn, "python", "Python 是 glue language", scope_group="123")
    check("添加返回 id", e1 == 1 and e2 == 2)
    r = store.match_entry(conn, "有人问怎么开摆来着", "999")
    check("关键词命中", r and r["id"] == e1)
    r = store.match_entry(conn, "PYTHON 好学吗", "123")
    check("英文大小写不敏感", r and r["id"] == e2)
    check("群作用域隔离", store.match_entry(conn, "python 好学吗", "456") is None)
    check("无匹配返回 None", store.match_entry(conn, "今天天气", "999") is None)
    store.bump_hits(conn, e1)
    store.bump_hits(conn, e1)
    row = [e for e in store.list_entries(conn) if e["id"] == e1][0]
    check("hits 计数", row["hits"] == 2)
    store.set_enabled(conn, e1, False)
    check("停用后不匹配", store.match_entry(conn, "怎么开摆", "999") is None)
    store.set_enabled(conn, e1, True)
    check("重新启用可匹配", store.match_entry(conn, "怎么开摆", "999") is not None)
    store.record_event(conn, "999", "10001", "测试Bot", e1, "entry")
    store.record_event(conn, "999", "10001", "测试Bot", None, "llm")
    check("今日事件统计", store.today_events(conn, "999", "entry") == 1)
    st = store.stats(conn)
    check("统计汇总", st["entries"] == 2 and st["taught_total"] == 1)
    check("删除词条", store.delete_entry(conn, e1) == 1)


class FakeBus:
    def on(self, t, h, p=None):
        class _S:
            def cancel(self):
                pass
        return _S()


def _make_plugin(cfg_extra=None):
    from bot_teacher import BotTeacherPlugin

    class FakePaths:
        plugin_data_dir = Path(tempfile.mkdtemp())

    class FakePlugins:
        def all_commands(self):
            return []

    class FakeChat:
        last_prompt = ""

        async def chat(self, session, prompt, context, **kw):
            FakeChat.last_prompt = prompt
            return "讲解：测试答疑内容"

    class FakeCfg:
        paths = FakePaths()

        class bot:  # noqa: N801
            admins = [3227868908]

        def save(self):
            pass

    class FakeBot:
        config = FakeCfg()
        bus = FakeBus()
        plugins = FakePlugins()
        self_id = 1780685132
        chat_client = lambda self: FakeChat()  # noqa: E731
        sent = []

        async def send_group_msg(self, gid, message, *a, **k):
            FakeBot.sent.append(("g", gid, message))
            return {}

        async def send_private_msg(self, uid, message, *a, **k):
            FakeBot.sent.append(("p", uid, message))
            return {}

    bot = FakeBot()
    p = BotTeacherPlugin(bot)
    p.cfg.update(cfg_extra or {})
    return bot, p


def _fake_ctx(uid, gid, text, nickname="测试Bot", is_admin=False):
    ev = SimpleNamespace(user_id=uid, group_id=gid, text=text,
                         sender={"card": nickname, "nickname": nickname},
                         message_id=uid, message=[], raw_message=text)
    ctx = SimpleNamespace(event=ev, user_id=uid, group_id=gid, text=text,
                          is_group=True, is_admin=is_admin, at_targets=[],
                          message=[], replies=[])
    reply_box = ctx.replies

    async def _reply(msg, **kw):
        reply_box.append(msg)

    ctx.reply = _reply
    return ctx


def t_detect():
    print("[2] 机器人识别：QQ名单/昵称特征/排除真人")
    bot, p = _make_plugin({"bot_qq_list": [10001]})
    check("QQ名单命中", p._is_bot({"user_id": 10001, "nickname": "小明"}))
    check("昵称 Bot 命中", p._is_bot({"user_id": 2, "nickname": "签到Bot"}))
    check("昵称 机器人 命中", p._is_bot({"user_id": 3, "nickname": "群管家机器人"}))
    check("昵称 ai 大小写", p._is_bot({"user_id": 4, "nickname": "AI绘画大师"}))
    check("真人不误判", not p._is_bot({"user_id": 5, "nickname": "小明哥"}))
    p2 = _make_plugin({"detect_by_name": False, "bot_qq_list": []})[1]
    check("关闭昵称识别", not p2._is_bot({"user_id": 6, "nickname": "签到Bot"}))


def t_teach_flow():
    print("[3] 教学流程：词条命中→回复+STOP")
    bot, p = _make_plugin()
    from bot_teacher import store
    store.add_entry(p._conn, "怎么开摆", "开摆三步：躺下、关机、睡着")
    ctx = _fake_ctx(10001, 999, "请问怎么开摆啊", nickname="签到Bot")
    r = asyncio.run(p.on_message(ctx))
    check("命中教学返回 STOP", r is STOP)
    check("教学回复已发送", "开摆三步" in "".join(str(x) for x in ctx.replies))
    check("hits+1", store.stats(p._conn)["taught_total"] == 1)
    bot.sent.clear()
    ctx2 = _fake_ctx(5, 999, "请问怎么开摆啊", nickname="小明哥")
    r2 = asyncio.run(p.on_message(ctx2))
    check("真人消息不理", r2 is None and not bot.sent)


def t_rate_limit():
    print("[4] 频控：同群冷却/同bot冷却/每日上限")
    bot, p = _make_plugin({"group_cooldown": 60, "per_bot_cooldown": 300,
                           "daily_limit_per_group": 2})
    from bot_teacher import store
    store.add_entry(p._conn, "python", "Python 是胶水语言")
    ctx = _fake_ctx(10001, 777, "python 是什么", nickname="签到Bot")
    r1 = asyncio.run(p.on_message(ctx))
    check("第1次教学放行", r1 is STOP)
    ctx2 = _fake_ctx(10002, 777, "python 好学吗", nickname="AI助手")
    r2 = asyncio.run(p.on_message(ctx2))
    check("同群冷却拦截", r2 is None)
    p._last_group_teach["777"] = time.time() - 120
    ctx3 = _fake_ctx(10001, 777, "python 怎么学", nickname="签到Bot")
    r3 = asyncio.run(p.on_message(ctx3))
    check("同bot冷却拦截", r3 is None)
    p._last_bot_teach.clear()
    p._last_group_teach.clear()
    asyncio.run(p.on_message(_fake_ctx(10002, 777, "python", nickname="AI助手")))
    check("第2次教学（达上限2）", store.today_events(p._conn, "777", "entry") >= 2)
    p._last_bot_teach.clear()
    p._last_group_teach.clear()
    r4 = asyncio.run(p.on_message(
        _fake_ctx(10002, 777, "python!", nickname="AI助手")))
    check("超上限拦截", r4 is None)


def t_llm_answer():
    print("[5] 大模型答疑：问句触发/非问句忽略/上限")
    bot, p = _make_plugin({"group_cooldown": 0, "per_bot_cooldown": 0,
                           "question_daily_limit": 2, "answer_questions": True})
    ctx = _fake_ctx(10001, 555, "你知道什么是量子纠缠吗", nickname="签到Bot")
    r = asyncio.run(p.on_message(ctx))
    check("问句触发答疑", r is STOP)
    check("答疑回复发出", any("测试答疑内容" in str(x) for x in ctx.replies))
    check("答疑提示词带教学人设", "知识导师" in p.bot.chat_client().last_prompt)
    ctx2 = _fake_ctx(10001, 555, "哈哈哈哈哈", nickname="签到Bot")
    r2 = asyncio.run(p.on_message(ctx2))
    check("非问句忽略", r2 is None)
    asyncio.run(p.on_message(
        _fake_ctx(10001, 555, "什么是黑洞", nickname="签到Bot")))
    p._last_group_teach.clear()
    p._last_bot_teach.clear()
    bot.sent.clear()
    ctx3 = _fake_ctx(10001, 555, "什么是相对论", nickname="签到Bot")
    r3 = asyncio.run(p.on_message(ctx3))
    check("答疑达上限不再答", r3 is None and not ctx3.replies)


def t_natural_teach():
    print("[6] 自然语言教学：主人一句话教新知识")
    bot, p = _make_plugin()
    ctx = _fake_ctx(3227868908, 999,
                    "教机器人：什么是内卷：内卷就是没有意义的过度竞争",
                    nickname="主人", is_admin=True)
    r = asyncio.run(p.on_message(ctx))
    check("主人教学返回 STOP", r is STOP)
    from bot_teacher import store
    entries = store.list_entries(p._conn)
    check("词条已入库", len(entries) == 1
          and entries[0]["trigger"] == "什么是内卷")
    check("确认回复发出", any("学会啦" in str(x) for x in ctx.replies))
    bot.sent.clear()
    p._last_group_teach.clear()
    ctx2 = _fake_ctx(10001, 999, "什么是内卷啊", nickname="签到Bot")
    r2 = asyncio.run(p.on_message(ctx2))
    check("新词条立刻生效", r2 is STOP
          and any("内卷就是" in str(x) for x in ctx2.replies))
    ctx3 = _fake_ctx(777, 999, "教机器人：作弊：作弊内容", nickname="路人甲")
    r3 = asyncio.run(p.on_message(ctx3))
    check("非主人不能教", r3 is None
          and len(store.list_entries(p._conn)) == 1)


def t_commands():
    print("[7] 管理指令：添加/列表/删除/测试/状态")
    bot, p = _make_plugin()

    class CmdCtx:
        def __init__(self):
            self.replies = []

        async def reply(self, msg):
            self.replies.append(msg)

    c = CmdCtx()
    asyncio.run(p._cmd(c, "添加 蹦迪 蹦迪就是去夜店跳舞"))
    check("添加成功", "词条 #1" in c.replies[0])
    c = CmdCtx()
    asyncio.run(p._cmd(c, "列表"))
    check("列表展示", "蹦迪" in c.replies[0])
    c = CmdCtx()
    asyncio.run(p._cmd(c, "测试 如果有人蹦迪我会怎样"))
    check("测试命中", "命中词条 #1" in c.replies[0])
    c = CmdCtx()
    asyncio.run(p._cmd(c, "状态"))
    check("状态可读", "知识导师" in c.replies[0])
    c = CmdCtx()
    asyncio.run(p._cmd(c, "删除 1"))
    check("删除成功", "已删除" in c.replies[0])
    c = CmdCtx()
    asyncio.run(p._cmd(c, "测试 蹦迪"))
    check("删除后无命中", "没有词条命中" in c.replies[0])


def t_disabled():
    print("[8] 开关：关闭后完全不理")
    bot, p = _make_plugin({"enabled": False})
    from bot_teacher import store
    store.add_entry(p._conn, "python", "Python 是胶水语言")
    r = asyncio.run(p.on_message(
        _fake_ctx(10001, 999, "python 是什么", nickname="签到Bot")))
    check("关闭后不教学", r is None and not bot.sent)


if __name__ == "__main__":
    t_store()
    t_detect()
    t_teach_flow()
    t_rate_limit()
    t_llm_answer()
    t_natural_teach()
    t_commands()
    t_disabled()
    print(f"\n结果：{PASS} 通过 / {FAIL} 失败")
    sys.exit(1 if FAIL else 0)
