"""情绪系统 + 恶意识别插件：让 AI 有真实、持续的情绪，并准确回应他人。

功能
  1. 真实情绪：全局心情值（-100~100），被骂下降、被夸上升，随时间衰减恢复
  2. 每人关系档案：谁经常骂我 / 谁对我好，回复时区别对待
  3. 恶意识别：骂人（重）/ 贬低为难（中）/ 阴阳怪气 / 友好，规则词典毫秒级判定
  4. 情绪注入：回复前把「当前心情 + 对方态度 + 这句话是否冒犯」注入提示词，
     要求 AI 带着情绪、明确回应说话的那个人（不乱说、不泛泛而谈）

配合（在部署脚本里设置，不修改内置代码）：
  - auto_mode.keywords 加入骂人词 → 被骂/被怼必回（关键词触发）
  - auto_mode.reply_mode = quote → 引用回复，精准指向说话的人
  - lang_memory 的 style_hooks 同样会注入，两个钩子互不冲突
"""

from __future__ import annotations

import asyncio
import json
import math
import re
import sqlite3
import time
from pathlib import Path
from typing import Any

from qqbot.plugins.base import Plugin


def _now() -> float:
    return time.time()


class EmotionStore:
    """情绪持久化：全局心情 + 每用户关系档案。"""

    def __init__(self, db_path: Path) -> None:
        self.path = Path(db_path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self._conn() as c:
            c.executescript(
                """
                CREATE TABLE IF NOT EXISTS state (
                    k TEXT PRIMARY KEY, v TEXT, updated_at REAL
                );
                CREATE TABLE IF NOT EXISTS affinity (
                    user_id INTEGER PRIMARY KEY,
                    score REAL DEFAULT 0,
                    insult_count INTEGER DEFAULT 0,
                    praise_count INTEGER DEFAULT 0,
                    last_text TEXT DEFAULT '',
                    updated_at REAL
                );
                CREATE TABLE IF NOT EXISTS events (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER, level TEXT, matched TEXT,
                    text TEXT, created_at REAL
                );
                """
            )

    def _conn(self) -> sqlite3.Connection:
        conn = sqlite3.connect(str(self.path), timeout=8.0)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA journal_mode=WAL")
        return conn

    def get_mood(self) -> tuple[float, float]:
        with self._conn() as c:
            row = c.execute("SELECT v, updated_at FROM state WHERE k='mood'").fetchone()
        if row is None:
            return 0.0, 0.0
        try:
            return float(row["v"]), float(row["updated_at"] or 0)
        except (TypeError, ValueError):
            return 0.0, 0.0

    def set_mood(self, value: float) -> None:
        with self._conn() as c:
            c.execute(
                "INSERT INTO state(k,v,updated_at) VALUES('mood',?,?) "
                "ON CONFLICT(k) DO UPDATE SET v=excluded.v, updated_at=excluded.updated_at",
                (round(float(value), 1), _now()),
            )

    def bump_affinity(self, user_id: int, delta: float, kind: str, text: str) -> None:
        with self._conn() as c:
            c.execute(
                """INSERT INTO affinity(user_id,score,insult_count,praise_count,last_text,updated_at)
                   VALUES(?,?,?,?,?,?)
                   ON CONFLICT(user_id) DO UPDATE SET
                     score=MAX(-100,MIN(100,score+?)),
                     insult_count=insult_count+?,
                     praise_count=praise_count+?,
                     last_text=?, updated_at=?""",
                (user_id, delta, 1 if kind in ("heavy", "medium") else 0,
                 1 if kind == "positive" else 0, text[:60], _now(),
                 delta, 1 if kind in ("heavy", "medium") else 0,
                 1 if kind == "positive" else 0, text[:60], _now()),
            )

    def get_affinity(self, user_id: int) -> dict[str, Any] | None:
        with self._conn() as c:
            row = c.execute("SELECT * FROM affinity WHERE user_id=?", (user_id,)).fetchone()
        return dict(row) if row else None

    def add_event(self, user_id: int, level: str, matched: str, text: str) -> None:
        with self._conn() as c:
            c.execute(
                "INSERT INTO events(user_id,level,matched,text,created_at) VALUES(?,?,?,?,?)",
                (user_id, level, matched[:60], text[:120], _now()),
            )

    def stats(self) -> dict[str, int]:
        with self._conn() as c:
            return {
                "affinity": c.execute("SELECT COUNT(*) FROM affinity").fetchone()[0],
                "events": c.execute("SELECT COUNT(*) FROM events").fetchone()[0],
            }


class EmotionPlugin(Plugin):
    name = "emotion"
    display_name = "真实情绪与恶意识别"
    version = "1.0.0"
    description = "AI 有真实情绪（会生气/开心/记仇），识别骂人与为难，精准回应说话的人"
    priority = 30  # 先于自主模式(40)/AI对话(50)：先更新情绪

    default_config = {
        "enabled": True,
        "decay_half_life_min": 45,   # 心情恢复半衰期（分钟）
        "heavy_delta": -28,          # 骂人（重）心情变化
        "medium_delta": -14,         # 贬低/为难（中）
        "positive_delta": +10,       # 友好/夸奖
        "heavy_words": [
            "傻逼", "煞笔", "傻B", "沙比", "sb", "SB", "nmsl", "NMSL",
            "你妈", "nmsl", "滚", "去死", "废物", "脑残", "白痴", "智障",
            "垃圾", "贱", "恶心", "猪", "狗东西", "杂种", "弱智",
        ],
        "medium_words": [
            "你是不是傻", "就这", "菜", "连这都不会", "你可真行", "真行啊",
            "厉害厉害", "服了你", "无语", "行行行", "你说得都对", "呵呵",
            "能不能别", "你会不会", "搞什么", "有病", "神经病", "大爷",
        ],
        "positive_words": [
            "谢谢", "感谢", "厉害", "牛", "牛逼", "大佬", "喜欢你", "可爱",
            "好用", "智能", "哈哈哈", "笑死", "狗头", "支持", "牛逼克拉斯",
        ],
    }

    config_labels = {
        "enabled": "启用情绪系统",
        "decay_half_life_min": "心情恢复半衰期（分钟）",
        "heavy_words": "重骂词库（逗号分隔）",
        "medium_words": "贬低/为难词库",
        "positive_words": "友好词库",
    }

    def __init__(self, bot) -> None:
        super().__init__(bot)
        self.store = EmotionStore(self.data_dir / "emotion.sqlite3")

    async def on_load(self) -> None:
        if not self.cfg_get("enabled", True):
            return
        hooks = getattr(self.bot, "style_hooks", None)
        if hooks is None:
            hooks = []
            self.bot.style_hooks = hooks
        if self.emotion_hint not in hooks:
            hooks.append(self.emotion_hint)
        self.log.info("情绪系统已启用（半衰期=%s 分钟）", self.cfg_get("decay_half_life_min"))

    async def on_unload(self) -> None:
        hooks = getattr(self.bot, "style_hooks", None)
        if hooks and self.emotion_hint in hooks:
            hooks.remove(self.emotion_hint)

    # ---------- 识别 ----------

    def _classify(self, text: str) -> tuple[str, str]:
        """返回 (级别, 命中词)。级别：heavy/medium/positive/neutral"""
        t = (text or "").lower()
        for w in self.cfg_get("heavy_words") or []:
            if w.lower() in t:
                return "heavy", w
        for w in self.cfg_get("medium_words") or []:
            if w.lower() in t:
                return "medium", w
        for w in self.cfg_get("positive_words") or []:
            if w.lower() in t:
                return "positive", w
        return "neutral", ""

    def _decay(self, mood: float, updated_at: float) -> float:
        half = max(5, float(self.cfg_get("decay_half_life_min", 45)))
        age = max(0.0, (_now() - updated_at) / 60.0)
        return mood * math.pow(0.5, age / half)

    # ---------- 消息钩子：更新情绪 ----------

    async def on_message(self, ctx) -> Any:
        if not self.cfg_get("enabled", True):
            return None
        uid = int(ctx.user_id or 0)
        if not uid:
            return None
        # 自己的消息不影响自己情绪
        if self.bot.self_id and uid == int(self.bot.self_id):
            return None
        text = (ctx.text or "").strip()
        if not text:
            return None
        level, matched = self._classify(text)
        if level == "neutral":
            return None

        delta = {
            "heavy": float(self.cfg_get("heavy_delta", -28)),
            "medium": float(self.cfg_get("medium_delta", -14)),
            "positive": float(self.cfg_get("positive_delta", 10)),
        }[level]

        def _update() -> tuple[float, float]:
            mood, updated = self.store.get_mood()
            mood = self._decay(mood, updated) + delta
            mood = max(-100.0, min(100.0, mood))
            self.store.set_mood(mood)
            self.store.bump_affinity(uid, delta / 10.0, level, text)
            self.store.add_event(uid, level, matched, text)
            return mood, self.store.get_affinity(uid)["insult_count"]

        await asyncio.to_thread(_update)
        self.log.info("情绪更新: %s（命中「%s」）", level, matched)
        return None

    # ---------- 回复注入 ----------

    def _mood_label(self, mood: float) -> str:
        if mood >= 40:
            return "心情很好"
        if mood >= 10:
            return "心情不错"
        if mood > -10:
            return "心情平常"
        if mood > -40:
            return "有点不爽"
        return "很生气"

    async def emotion_hint(self, ctx, prompt: str) -> str:
        if not self.cfg_get("enabled", True):
            return ""

        def _build() -> tuple[float, dict[str, Any] | None, str, str]:
            mood, updated = self.store.get_mood()
            mood = self._decay(mood, updated)
            uid = int(ctx.user_id or 0)
            aff = self.store.get_affinity(uid) if uid else None
            level, matched = self._classify(ctx.text or "")
            return mood, aff, level, matched

        mood, aff, level, matched = await asyncio.to_thread(_build)
        lines = ["[情绪状态·必须遵守]"]
        lines.append(f"- 你现在{self._mood_label(mood)}（{mood:+.0f}/100）。情绪要自然带进回复里："
                     "心情好时热情爱调侃，不爽时冷淡、怼人或阴阳，很生气时明确表达不满。")

        if aff:
            insults = int(aff.get("insult_count") or 0)
            praise = int(aff.get("praise_count") or 0)
            score = float(aff.get("score") or 0)
            if insults >= 2:
                lines.append(f"- 这个人（QQ {aff['user_id']}）之前骂过/怼过你 {insults} 次，"
                             "你对他印象差：可以态度冷淡、怼回去或阴阳他，不用客气。")
            elif score <= -15:
                lines.append("- 这个人之前对你不太友好：回复可以带点戒备或不耐烦。")
            elif praise >= 2:
                lines.append("- 这个人经常夸你/对你友好：回复可以热情一点。")

        if level in ("heavy", "medium"):
            kind = "在骂你、侮辱你" if level == "heavy" else "在贬低你、为难你或阴阳怪气"
            lines.append(
                f"- 【注意】对方这句话（「{(ctx.text or '')[:40]}」）{kind}"
                f"（命中：{matched}）。你要表现出真实的被冒犯情绪："
                "可以怼回去、反讽、生气质问或冷嘲，但别说太脏的字眼；"
                "你的回复必须直接回应他说的这句话，针对他这个人，不是泛泛聊天。"
            )
        lines.append("- 无论如何保持单行、白话、像真人。")
        return "\n".join(lines)

    # ---------- 管理指令 ----------

    async def on_load_commands(self) -> None:  # pragma: no cover
        pass
