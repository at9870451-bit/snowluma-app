"""语言风格与圈层文化分析（纯规则，无网络、无模型依赖，毫秒级）。

设计原则：
  - 只做「可观察的语言特征」统计，不做任何人格/身份推断
  - 输出结构化、可累加的计数，便于增量学习与时间衰减
  - 敏感内容（手机号、证件号、地址、密码等）在入口就被过滤，不进入画像
"""

from __future__ import annotations

import re
from typing import Any

# ---------------- 敏感信息过滤 ----------------

_SENSITIVE_PATTERNS = [
    re.compile(r"1[3-9]\d{9}"),                       # 手机号
    re.compile(r"\d{17}[\dXx]"),                      # 身份证
    re.compile(r"\b\d{16,19}\b"),                     # 银行卡
    re.compile(r"(密码|口令|验证码|身份证|住址|家庭住址|银行卡)\s*[:：]?\s*\S+"),
    re.compile(r"[\w.+-]+@[\w-]+\.[\w.]+"),           # 邮箱
]

# ---------------- 语料库 ----------------

NET_SLANG = {
    "yyds", "绝绝子", "栓q", "栓Q", "破防", "上头", "绷不住", "尊嘟", "假嘟",
    "emo", "awsl", "蚌埠住了", "笑死", "离谱", "整活", "摆烂", "躺平", "内卷",
    "社死", "emo了", "麻了", "无语子", "好家伙", "真的会谢", "寄", "拿捏",
    "泰裤辣", "city不city", "松弛感", "班味", "显眼包", "搭子", "确诊",
    "xswl", "u1s1", "nsdd", "dddd", "yygq", "蚌埠", "柠檬精", "凡尔赛",
}

ANIME_WORDS = {
    "233", "2333", "awsl", "赛高", "米娜桑", "贴贴", "欧尼酱", "欧内桑",
    "草", "kuso", "八嘎", "斯国一", "纳尼", "亚撒西", "中二", "本命",
    "老婆", "老公", "女儿", "推", "厨", "同人", "ooc", "磕", "磕到了",
}

CLASSICAL_WORDS = {
    "吾", "汝", "卿", "阁下", "兄台", "尔等", "在下", "足下", "先生",
    "姑娘", "公子", "小生", "晚生", "鄙人", "何故", "何以", "岂敢",
    "甚好", "妙哉", "善哉", "是也", "然也", "呜呼", "嗟乎",
}

DIALECT_WORDS = {
    "咋", "俺", "咱", "啥子", "啥", "嘞", "咯", "嘛", "咧", "嘎哈", "整",
    "冇", "唔", "系", "嘅", "咩", "嘅", "俾", "睇", "佢", "乜", "啲",
    "侬", "阿拉", "伐", "额", "嘚", "嘞个", "中不中", "得劲儿", "巴适",
    "安逸", "耍", "搞么斯", "么斯", "老铁", "整挺好", "贼", "忒",
}

#: 语气词：真人感的强信号
PARTICLES = [
    "啊", "呀", "吧", "呢", "嘛", "哦", "噢", "喔", "诶", "欸", "嘿", "哈",
    "啦", "咯", "嘞", "嗷", "啧", "嗯", "唉", "哎", "哇", "呐", "咧",
]

EMOJI_RE = re.compile(
    "[" "\U0001F300-\U0001FAFF" "\U00002600-\U000027BF" "\U0001F1E6-\U0001F1FF" "]+"
)

EN_MIX_RE = re.compile(r"[A-Za-z]{2,}")
CJK_RE = re.compile(r"[\u4e00-\u9fff]")

#: 句子切分（中英文标点 + 换行）
SENT_SPLIT_RE = re.compile(r"[。！？!?…\n]+|\.{3,}")


def is_sensitive(text: str) -> bool:
    """命中任一敏感模式就不入库（只做过滤，不记录命中内容）。"""
    if not text:
        return True
    return any(p.search(text) for p in _SENSITIVE_PATTERNS)


def clean(text: str) -> str:
    """归一化：去控制字符、压缩空白、截断。"""
    t = re.sub(r"[\x00-\x08\x0b\x0c\x0e-\x1f]", "", text or "")
    t = re.sub(r"\s+", " ", t).strip()
    return t[:400]


# ---------------- 特征提取 ----------------


def tokens(text: str) -> list[str]:
    """粗分词：中文双字滑窗 + 英文/数字词，够用于相似度与关键词。"""
    out: list[str] = []
    for word in EN_MIX_RE.findall(text):
        out.append(word.lower())
    cjk = "".join(CJK_RE.findall(text))
    for i in range(len(cjk) - 1):
        out.append(cjk[i:i + 2])
    return out


def analyze(text: str) -> dict[str, Any]:
    """返回一条消息的语言特征（计数形式，便于跨消息累加）。"""
    t = clean(text)
    if not t:
        return {}
    sentences = [s for s in SENT_SPLIT_RE.split(t) if s.strip()]
    lens = [len(s) for s in sentences] or [len(t)]
    avg_len = sum(lens) / len(lens)

    hits: dict[str, int] = {}

    def bump(bucket: str, key: str, n: int = 1) -> None:
        hits[f"{bucket}:{key}"] = hits.get(f"{bucket}:{key}", 0) + n

    for w in NET_SLANG:
        if w in t:
            bump("slang", w, t.count(w))
    for w in ANIME_WORDS:
        if w in t:
            bump("anime", w, t.count(w))
    for w in CLASSICAL_WORDS:
        if w in t:
            bump("classical", w, t.count(w))
    for w in DIALECT_WORDS:
        if w in t:
            bump("dialect", w, t.count(w))
    for w in PARTICLES:
        c = t.count(w)
        if c:
            bump("particle", w, c)

    emojis = EMOJI_RE.findall(t)
    if emojis:
        bump("emoji", "".join(emojis)[:8], len(emojis))

    en_words = EN_MIX_RE.findall(t)
    if en_words and CJK_RE.search(t):
        bump("mix", "en_cn", len(en_words))

    # 标点习惯
    if "..." in t or "…" in t:
        bump("punct", "ellipsis")
    if "~" in t or "～" in t:
        bump("punct", "tilde")
    if "！" in t or "!" in t:
        bump("punct", "excl")
    if "？" in t or "?" in t:
        bump("punct", "question")
    if not re.search(r"[，,。.！!？?、；;：:]", t):
        bump("punct", "no_punct")
    if t.endswith(("吧", "吗", "么", "呢")):
        bump("punct", "soft_question")

    # 结构与节奏
    if len(sentences) >= 3:
        bump("rhythm", "multi_clause")
    if avg_len <= 6:
        bump("rhythm", "short")
    elif avg_len >= 22:
        bump("rhythm", "long")
    if re.search(r"(哈|嘿|嘻|呵){2,}", t):
        bump("rhythm", "laugh")
    if re.search(r"^(草|靠|卧槽|我靠|啊这)", t):
        bump("rhythm", "exclaim_start")
    if "?" in t or "？" in t:
        bump("rhythm", "asks_back")

    return {
        "hits": hits,
        "sentences": len(sentences),
        "avg_len": round(avg_len, 2),
        "chars": len(t),
        "tokens": tokens(t),
    }


# ---------------- 汇总成画像 ----------------


BUCKET_LABEL = {
    "slang": "网络流行语",
    "anime": "二次元用语",
    "classical": "古风表达",
    "dialect": "方言/地域",
    "particle": "语气词",
    "emoji": "表情符号",
    "mix": "中英混合",
    "punct": "标点习惯",
    "rhythm": "句式节奏",
}


def top_of(hits: dict[str, int], bucket: str, n: int = 5) -> list[str]:
    items = [(k.split(":", 1)[1], v) for k, v in hits.items() if k.startswith(bucket + ":")]
    items.sort(key=lambda kv: -kv[1])
    return [f"{k}×{v}" if v > 1 else k for k, v in items[:n]]


def summarize(hits: dict[str, int], stats: dict[str, Any]) -> dict[str, Any]:
    """把累计计数整理成人类可读、可直接注入提示词的画像摘要。"""
    out: dict[str, Any] = {}
    for bucket in BUCKET_LABEL:
        top = top_of(hits, bucket, 6)
        if top:
            out[BUCKET_LABEL[bucket]] = top
    if stats.get("avg_len"):
        out["平均句长"] = stats["avg_len"]
    if stats.get("msg_count"):
        out["样本条数"] = stats["msg_count"]
    return out


def style_brief(hits: dict[str, int], stats: dict[str, Any], limit: int = 6) -> str:
    """生成一句话风格概述，供注入时压缩 token。"""
    parts: list[str] = []
    for bucket, label in (
        ("particle", "常用语气词"),
        ("dialect", "方言习惯"),
        ("slang", "网络用语"),
        ("anime", "二次元梗"),
        ("classical", "古风用词"),
        ("punct", "标点"),
        ("rhythm", "句式"),
    ):
        top = top_of(hits, bucket, 3)
        if top:
            parts.append(f"{label}：{'、'.join(x.split('×')[0] for x in top)}")
        if len(parts) >= limit:
            break
    return "；".join(parts)
