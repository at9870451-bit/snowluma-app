"""语言风格学习与长期记忆系统（QQBot 外部插件）。

功能
  1. 自动学习：授权群内成员的公开发言 → 词汇/语气/句式/口头禅/幽默/表达习惯
  2. 文化特征：网络流行语 / 方言 / 梗 / 二次元 / 古风 / 中英混合
  3. 个性化记忆：按 QQ 号独立建档，区分长期习惯与临时情绪（临时情绪不沉淀）
  4. 动态模仿：回复时按场景注入目标成员的语言风格片段（可关闭、可调强度）
  5. 记忆优化：结构化标签 + 重要度评分 + 时间衰减 + 相似合并 + 检索/更新/纠错/删除
  6. 隐私保护：敏感内容过滤、白名单群、opt-out、一键删除
  7. 技术：异步队列 + 线程内 SQLite + 异常隔离 + 自愈工作协程，不阻塞消息分发

不修改任何内置插件的行为；唯一的核心补丁是 _ai_reply.answer 里一段
「调用 bot.style_hooks」的挂载点（见 README 部署说明）。
"""

from __future__ import annotations

import asyncio
import json
import random
import re
import time
from typing import Any

from qqbot.plugins.base import Plugin

from . import analyzer
from .store import LangStore

# 订阅的事件总线类型（与内置插件保持一致）
MESSAGE_KIND = "message"


def _tense_marker(user_id: int, text: str) -> str:
    """临时情绪识别：情绪词 + 时间词 的短消息只做语气参考，不沉淀为长期特征。"""
    emotion = ("生气", "气死", "烦死", "崩溃", "无语", "好气", "怒了", "哭了", "难受",
               "开心", "笑死", "哈哈", "好耶", "激动", "兴奋", "呜呜", "emo")
    tense = ("今天", "现在", "刚才", "昨晚", "今早", "刚")
    if any(w in text for w in emotion) and any(w in text for w in tense):
        return "temporary"
    return "stable"


class LangMemoryPlugin(Plugin):
    name = "lang_memory"
    display_name = "语言风格学习与长期记忆"
    version = "1.0.0"
    description = "学习群成员语言风格并长期记忆，回复时动态模仿（可关闭/可删除）"
    priority = 35  # 高于 AI 对话(50)/自主模式(40)：学习必须在回复前拿到消息

    default_config = {
        "enabled": True,          # 总开关
        "learn_enabled": True,    # 学习开关（管理员可随时改）
        "whitelist_mode": False,  # True=只学习 learn_groups 里的群
        "learn_groups": [],       # 授权学习的群号（whitelist_mode=True 时生效）
        "min_len": 3,             # 低于此长度不学习（水群/单字）
        "max_len": 300,           # 超长不学（粘贴长文）
        "sample_keep": 200,       # 每用户保留样本上限
        "decay_days": 30,         # 记忆半衰期（天）
        "merge_threshold": 0.82,  # 相似记忆合并阈值
        "inject_enabled": True,   # 回复时注入风格
        "inject_max_chars": 700,  # 注入片段字符预算
        "mimic_strength": "medium",  # off|light|medium|strong
        "llm_enrich": False,      # 用大模型做深度风格提炼（异步、低频、可关）
        "llm_enrich_every": 25,   # 每 N 条样本触发一次深度提炼
        "queue_size": 2000,       # 学习队列上限（满则丢最旧的，保响应）
        "blocked_words": [],      # 包含这些词的发言不学习
    }

    config_labels = {
        "enabled": "启用语言学习",
        "learn_enabled": "允许学习",
        "whitelist_mode": "仅学习白名单群",
        "learn_groups": "授权学习群号（逗号分隔）",
        "inject_enabled": "回复时模仿语言风格",
        "mimic_strength": "模仿强度（off/light/medium/strong）",
        "decay_days": "记忆半衰期（天）",
        "llm_enrich": "大模型深度提炼",
    }

    def __init__(self, bot) -> None:
        super().__init__(bot)
        self.store = LangStore(self.data_dir / "lang_memory.sqlite3")
        self._queue: asyncio.Queue[dict[str, Any]] | None = None
        self._worker: asyncio.Task | None = None
        self._enrich_counter = 0

    # ---------- 生命周期 ----------

    async def on_load(self) -> None:
        if not self.cfg_get("enabled", True):
            return
        self._queue = asyncio.Queue(maxsize=int(self.cfg_get("queue_size", 2000)))
        self._spawn_worker()
        # 注册风格注入钩子（_ai_reply.answer 会调用 bot.style_hooks）
        hooks = getattr(self.bot, "style_hooks", None)
        if hooks is None:
            hooks = []
            self.bot.style_hooks = hooks
        if self.style_hint not in hooks:
            hooks.append(self.style_hint)
        # 管理指令
        self.add_command("语言记忆", self._cmd_mem, aliases=("langmem",),
                         admin=True, description="语言记忆系统状态/查看/删除/开关")
        self.log.info("语言风格学习已启用（群白名单=%s，模仿=%s）",
                      "开" if self.cfg_get("whitelist_mode") else "关",
                      self.cfg_get("mimic_strength"))

    async def on_unload(self) -> None:
        if self._worker:
            self._worker.cancel()
        hooks = getattr(self.bot, "style_hooks", None)
        if hooks and self.style_hint in hooks:
            hooks.remove(self.style_hint)

    def _spawn_worker(self) -> None:
        """启动工作协程；异常退出后 2 秒自愈重建（不依赖外部监督）。"""
        async def _run() -> None:
            while True:
                try:
                    await self._process_loop()
                except asyncio.CancelledError:
                    raise
                except Exception as exc:  # noqa: BLE001
                    self.log.error("学习工作协程崩溃，2 秒后重启: %s", exc)
                    await asyncio.sleep(2)

        self._worker = asyncio.get_running_loop().create_task(_run())

    async def _process_loop(self) -> None:
        while True:
            job = await self._queue.get()  # type: ignore[union-attr]
            try:
                await self._learn_one(job)
            except Exception as exc:  # noqa: BLE001
                self.log.warning("单条学习失败（已跳过，不影响后续）: %s", exc)
            finally:
                self._queue.task_done()  # type: ignore[union-attr]

    # ---------- 消息钩子 ----------

    async def on_message(self, ctx) -> Any:
        cfg = self.cfg
        if not cfg.get("learn_enabled", True) or not ctx.is_group:
            return None
        # 隐私：用户曾主动关闭学习
        if self.store.is_optout(int(ctx.user_id or 0)):
            return None

        text = analyzer.clean(ctx.text or "")
        # 自服务指令（非管理员也能用，属于隐私权利）
        if text in ("关闭语言学习", "关闭学习", "别学我", "忘了我"):
            self.store.set_optout(int(ctx.user_id or 0), True)
            await ctx.reply("好，我不再学习你的说话方式，也不会拿你的记录去模仿。")
            return self.stop()
        if text in ("开启语言学习", "开始学习我"):
            self.store.set_optout(int(ctx.user_id or 0), False)
            await ctx.reply("行，重新开始学习你的语言风格。")
            return self.stop()

        if self._can_learn(ctx, text):
            self._enqueue({
                "user_id": int(ctx.user_id or 0),
                "group_id": int(ctx.group_id or 0),
                "nickname": (ctx.nickname or "")[:32],
                "text": text,
                "at": time.time(),
            })
        return None

    def _can_learn(self, ctx, text: str) -> bool:
        if not text:
            return False
        if len(text) < int(self.cfg_get("min_len", 3)):
            return False
        if len(text) > int(self.cfg_get("max_len", 300)):
            return False
        if analyzer.is_sensitive(text):
            return False
        blocked = [w for w in (self.cfg_get("blocked_words") or []) if w]
        if blocked and any(w in text for w in blocked):
            return False
        if self.cfg_get("whitelist_mode"):
            groups = [int(g) for g in (self.cfg_get("learn_groups") or []) if str(g).isdigit()]
            if groups and int(ctx.group_id or 0) not in groups:
                return False
        return True

    def _enqueue(self, job: dict[str, Any]) -> None:
        if self._queue is None:
            return
        try:
            self._queue.put_nowait(job)
        except asyncio.QueueFull:
            try:
                self._queue.get_nowait()
                self._queue.put_nowait(job)
            except Exception:  # noqa: BLE001
                pass

    # ---------- 学习流水线 ----------

    async def _learn_one(self, job: dict[str, Any]) -> None:
        uid, text = job["user_id"], job["text"]
        feat = await asyncio.to_thread(analyzer.analyze, text)
        if not feat:
            return
        hits = feat.get("hits") or {}
        await asyncio.to_thread(
            self.store.touch_profile, uid, job["nickname"], hits,
            feat.get("avg_len", 8), 0.5,
        )
        await asyncio.to_thread(
            self.store.add_sample, uid, job["group_id"], text,
            int(self.cfg_get("sample_keep", 200)),
        )
        # 风格/文化记忆沉淀（稳定特征才沉淀，临时情绪只进画像语气）
        stable = _tense_marker(uid, text) == "stable"
        if stable:
            await self._remember_culture(uid, text, hits)
            await self._remember_anchor(uid, text)

        # 大模型深度提炼（可选、异步、低频）
        if self.cfg_get("llm_enrich") and self._should_enrich(uid):
            try:
                await asyncio.wait_for(self._llm_enrich(uid, text), timeout=20)
            except Exception as exc:  # noqa: BLE001
                self.log.debug("LLM 提炼失败（不影响学习）: %s", exc)

    def _should_enrich(self, uid: int) -> bool:
        self._enrich_counter += 1
        every = max(5, int(self.cfg_get("llm_enrich_every", 25)))
        return self._enrich_counter % every == 0 or random.random() < 0.02

    async def _remember_culture(self, uid: int, text: str, hits: dict[str, int]) -> None:
        """把本轮识别到的圈层/风格信号沉淀为记忆条目。"""
        def _do() -> None:
            if analyzer.top_of(hits, "slang", 2):
                self.store.add_memory(uid, "style", "爱用网络流行语：" + "、".join(
                    analyzer.top_of(hits, "slang", 5)), tags="流行语",
                    importance=0.6, merge_threshold=float(self.cfg_get("merge_threshold", 0.82)))
            if analyzer.top_of(hits, "anime", 1):
                self.store.add_memory(uid, "culture", "二次元圈层用语：" + "、".join(
                    analyzer.top_of(hits, "anime", 5)), tags="二次元",
                    importance=0.6, merge_threshold=float(self.cfg_get("merge_threshold", 0.82)))
            if analyzer.top_of(hits, "dialect", 1):
                self.store.add_memory(uid, "culture", "方言/地域表达：" + "、".join(
                    analyzer.top_of(hits, "dialect", 5)), tags="方言",
                    importance=0.65, merge_threshold=float(self.cfg_get("merge_threshold", 0.82)))
            if analyzer.top_of(hits, "classical", 1):
                self.store.add_memory(uid, "style", "偏好古风表达：" + "、".join(
                    analyzer.top_of(hits, "classical", 5)), tags="古风",
                    importance=0.6, merge_threshold=float(self.cfg_get("merge_threshold", 0.82)))
            if analyzer.top_of(hits, "mix", 1):
                self.store.add_memory(uid, "style", "说话中英混搭", tags="中英混合",
                                      importance=0.5, merge_threshold=float(self.cfg_get("merge_threshold", 0.82)))
            if analyzer.top_of(hits, "emoji", 1):
                self.store.add_memory(uid, "style", "爱发表情符号（" + "、".join(
                    analyzer.top_of(hits, "emoji", 3)) + "）", tags="表情",
                    importance=0.5, merge_threshold=float(self.cfg_get("merge_threshold", 0.82)))
            if analyzer.top_of(hits, "rhythm", 1) and analyzer.top_of(hits, "rhythm", 3):
                self.store.add_memory(uid, "style", "句式：" + "、".join(
                    analyzer.top_of(hits, "rhythm", 5)), tags="句式",
                    importance=0.55, merge_threshold=float(self.cfg_get("merge_threshold", 0.82)))
        await asyncio.to_thread(_do)

    # ---------- 记忆锚点（可翻的旧账） ----------

    _ANCHOR_RE = re.compile(
        r"[^。！？!?\n]{0,30}(改天|下次|回头|改日|过两天|答应|说好|约好|保证|请客|"
        r"请你|带我|帮你|给你带|欠|借你|借我|还你|该我)[^。！？!?\n]{0,40}"
    )

    async def _remember_anchor(self, uid: int, text: str) -> None:
        """沉淀「记忆锚点」：承诺/约定/欠账/帮忙——都是日后可翻的旧账。

        人味儿协议 10.4：未兑现的承诺、欠的人情、说过的狠话，是活人感最强的记忆。
        规则句式抓取（零成本），LLM 提炼可选增强。
        """
        text = (text or "").strip()
        if len(text) > 80 or len(text) < 4:
            return
        m = self._ANCHOR_RE.search(text)
        if not m:
            return
        fragment = m.group(0).strip()

        def _store() -> None:
            self.store.add_memory(
                uid, "anchor", f"他说过：「{fragment}」",
                tags="旧账", importance=0.75,
                merge_threshold=0.7,
            )
        await asyncio.to_thread(_store)

    async def _llm_enrich(self, uid: int, text: str) -> None:
        """（可选）用模型提炼一段精炼风格描述，写进 culture 字段。"""
        client = getattr(self.bot, "_llm_client", None)
        if client is None:
            return
        prompt = (
            "请用 40 字以内总结这条群聊发言体现的语言风格（词汇、语气、句式、圈层）：\n"
            f"「{text[:150]}」\n只输出总结本身，不要前缀。"
        )
        reply = await client.chat(
            f"langmem-{uid}", prompt, "", identity="", capability="",
        )
        reply = (reply or "").strip().strip('"“”')
        if reply:
            def _store() -> None:
                cur = self.store.get_profile(uid) or {}
                culture = dict(cur.get("culture") or {})
                culture["llm_brief"] = reply[:80]
                self.store.set_culture(uid, culture)
                self.store.add_memory(uid, "style", reply, tags="llm",
                                      importance=0.7,
                                      merge_threshold=float(self.cfg_get("merge_threshold", 0.82)))
            await asyncio.to_thread(_store)

    # ---------- 风格注入（供 _ai_reply.answer 调用） ----------

    async def style_hint(self, ctx, prompt: str) -> str:
        """生成「模仿对象语言风格」提示片段；无档案/关闭时返回空串。"""
        if not self.cfg_get("inject_enabled", True):
            return ""
        strength = str(self.cfg_get("mimic_strength", "medium"))
        if strength == "off":
            return ""
        uid = int(ctx.user_id or 0)
        profile = await asyncio.to_thread(self.store.get_profile, uid)
        if profile is None or not profile.get("traits"):
            return ""

        def _build() -> tuple[str, list[dict[str, Any]]]:
            traits = profile["traits"]
            stats = profile["stats"] or {}
            brief = analyzer.style_brief(traits, stats, limit=5)
            mems = self.store.recall(
                uid, ("style", "culture", "anchor"), top_k=6,
                half_life_days=float(self.cfg_get("decay_days", 30)),
                max_chars=int(self.cfg_get("inject_max_chars", 700)),
            )
            return brief, mems

        brief, mems = await asyncio.to_thread(_build)
        if not brief and not mems:
            return ""

        level = {"light": "轻微参考", "medium": "自然带一点", "strong": "尽量贴近"}.get(
            strength, "自然带一点")
        # 锚点（翻旧账）优先；无锚点才发风格简报（humanlike 已注入互动风格，避免重复）
        anchors = [m for m in mems if m.get("kind") == "anchor"]
        if anchors and random.random() < 0.45:
            a = anchors[0]["content"]
            return (
                f"[语言风格·{level}对方风格，别生硬] "
                "如果自然合适，带细节提一嘴他的旧账：" + a
                + "（直接引用，禁止说「上次那事」；不合适就别提）"
            )
        if not anchors and brief:
            return f"[语言风格·{level}对方风格] 他/她的习惯：" + brief
        return ""

    # ---------- 管理指令 ----------

    async def _cmd_mem(self, ctx, args: str) -> Any:
        args = (args or "").strip()
        lower = args.lower()

        if lower in ("", "状态", "status"):
            st = await asyncio.to_thread(self.store.stats)
            mode = "白名单" if self.cfg_get("whitelist_mode") else "全部群"
            lines = [
                "【语言记忆系统】",
                f"学习：{'开' if self.cfg_get('learn_enabled') else '关'}（范围：{mode}）",
                f"模仿：{self.cfg_get('mimic_strength')}（注入{'开' if self.cfg_get('inject_enabled') else '关'}）",
                f"画像档案：{st['profiles']} 人 · 记忆条目：{st['memories']} 条",
                f"样本：{st['samples']} 条 · 主动退出学习：{st['optout']} 人",
                f"记忆半衰期：{self.cfg_get('decay_days')} 天 · 队列：{self._queue.qsize() if self._queue else 0}",
            ]
            await ctx.reply("\n".join(lines))
            return self.stop()

        if lower.startswith("查看"):
            qq = args[2:].strip()
            if not qq.isdigit():
                await ctx.reply("用法：/语言记忆 查看 <QQ号>")
                return self.stop()
            return await self._show_profile(ctx, int(qq))

        if lower.startswith("删除"):
            qq = args[2:].strip()
            if qq == "全部":
                await asyncio.to_thread(self.store.delete_user, 0)
                await ctx.reply("已清空全部语言记忆档案。")
                return self.stop()
            if not qq.isdigit():
                await ctx.reply("用法：/语言记忆 删除 <QQ号> 或 删除 全部")
                return self.stop()
            r = await asyncio.to_thread(self.store.delete_user, int(qq))
            await ctx.reply(f"已删除该用户全部语言数据（画像 {r['profiles']}、记忆 {r['memories']}、样本 {r['samples']}）。")
            return self.stop()

        if lower in ("关闭", "off", "停"):
            self.cfg["learn_enabled"] = False
            self.save_config()
            await ctx.reply("已关闭语言学习（保留已有档案，回复不再更新）。")
            return self.stop()

        if lower in ("开启", "on"):
            self.cfg["learn_enabled"] = True
            self.save_config()
            await ctx.reply("已开启语言学习。")
            return self.stop()

        if lower.startswith("强度"):
            v = args[2:].strip()
            if v not in ("off", "light", "medium", "strong"):
                await ctx.reply("用法：/语言记忆 强度 off|light|medium|strong")
                return self.stop()
            self.cfg["mimic_strength"] = v
            self.save_config()
            await ctx.reply(f"模仿强度已设为 {v}。")
            return self.stop()

        if lower.startswith("模仿"):
            v = args[2:].strip()
            if v in ("开", "on", "关", "off"):
                self.cfg["inject_enabled"] = v in ("开", "on")
                self.save_config()
                await ctx.reply("回复风格注入已" + ("开启。" if v in ("开", "on") else "关闭。"))
                return self.stop()

        await ctx.reply(
            "用法：/语言记忆 状态｜查看 <QQ>｜删除 <QQ|全部>｜关闭/开启｜强度 off|light|medium|strong｜模仿 开/关"
        )
        return self.stop()

    async def _show_profile(self, ctx, qq: int) -> None:
        profile = await asyncio.to_thread(self.store.get_profile, qq)
        if profile is None:
            await ctx.reply(f"还没有 {qq} 的语言档案（ta 还没说过话或已退出学习）。")
            return self.stop()
        traits = profile["traits"]
        stats = profile["stats"] or {}
        brief = analyzer.style_brief(traits, stats, limit=8)
        mems = await asyncio.to_thread(
            self.store.recall, qq, ("style", "culture"), top_k=6,
            half_life_days=float(self.cfg_get("decay_days", 30)),
            max_chars=500,
        )
        culture = profile.get("culture") or {}
        llm = culture.get("llm_brief")
        lines = [
            f"【语言档案 {profile.get('nickname') or qq}】",
            f"样本 {stats.get('msg_count', 0)} 条 · 重要度 {round(profile.get('importance', 0.5), 2)}",
        ]
        if brief:
            lines.append("特征：" + brief)
        if llm:
            lines.append("模型提炼：" + llm)
        if mems:
            lines.append("记忆：")
            for m in mems:
                lines.append(f"  · {m['content']}")
        else:
            lines.append("记忆：暂无明显长期习惯")
        await ctx.reply("\n".join(lines))
        return self.stop()
