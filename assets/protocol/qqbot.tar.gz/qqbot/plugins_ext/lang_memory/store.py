"""长期记忆存储：SQLite（WAL），全部同步接口，由调用方放进线程执行。

表结构
    profiles   每个 QQ 用户一行：累计语言特征（JSON）、节奏、重要度
    memories   结构化记忆条目：kind/content/tags/importance/时间衰减字段
    samples    原始语言样本（有上限、可整体删除，仅用于复盘与再学习）
    optout     用户主动关闭学习的名单（隐私开关）
    meta       版本号等元数据
"""

from __future__ import annotations

import hashlib
import json
import math
import sqlite3
import time
from pathlib import Path
from typing import Any, Iterable

SCHEMA = """
CREATE TABLE IF NOT EXISTS profiles (
    user_id     INTEGER PRIMARY KEY,
    nickname    TEXT DEFAULT '',
    msg_count   INTEGER DEFAULT 0,
    importance  REAL DEFAULT 0.5,
    traits      TEXT DEFAULT '{}',
    culture     TEXT DEFAULT '{}',
    stats       TEXT DEFAULT '{}',
    tempo       REAL DEFAULT 0.5,
    created_at  REAL,
    updated_at  REAL
);

CREATE TABLE IF NOT EXISTS memories (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id     INTEGER NOT NULL,
    kind        TEXT NOT NULL,
    content     TEXT NOT NULL,
    tags        TEXT DEFAULT '',
    importance  REAL DEFAULT 0.5,
    hits        INTEGER DEFAULT 0,
    fingerprint TEXT UNIQUE,
    created_at  REAL,
    updated_at  REAL,
    last_hit    REAL
);
CREATE INDEX IF NOT EXISTS idx_mem_user ON memories(user_id, importance DESC);
CREATE INDEX IF NOT EXISTS idx_mem_kind ON memories(user_id, kind);

CREATE TABLE IF NOT EXISTS samples (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id    INTEGER NOT NULL,
    group_id   INTEGER,
    text       TEXT NOT NULL,
    created_at REAL
);
CREATE INDEX IF NOT EXISTS idx_sample_user ON samples(user_id, id DESC);

CREATE TABLE IF NOT EXISTS optout (
    user_id    INTEGER PRIMARY KEY,
    created_at REAL
);

CREATE TABLE IF NOT EXISTS meta (
    k TEXT PRIMARY KEY,
    v TEXT
);
"""

SCHEMA_VERSION = "1"


def _now() -> float:
    return time.time()


def fingerprint(kind: str, content: str, tokens: Iterable[str] | None = None) -> str:
    """去重指纹：kind + 内容归一化（有分词时用前 8 个词，抗轻微改写）。"""
    if tokens:
        base = kind + "|" + "|".join(sorted(set(list(tokens)))[:12])
    else:
        base = kind + "|" + content.strip().lower()
    return hashlib.sha1(base.encode("utf-8")).hexdigest()[:20]


def decay_factor(updated_at: float, half_life_days: float) -> float:
    """指数时间衰减：半衰期到期后权重减半。"""
    if not updated_at or half_life_days <= 0:
        return 1.0
    age_days = max(0.0, (_now() - updated_at) / 86400.0)
    return math.pow(0.5, age_days / half_life_days)


def _char_bigrams(text: str) -> list[str]:
    """字符二元组（去空白），作为轻量相似度特征。"""
    t = "".join(text.split())
    return [t[i:i + 2] for i in range(len(t) - 1)]


def jaccard(a: Iterable[str], b: Iterable[str]) -> float:
    sa, sb = set(a), set(b)
    if not sa or not sb:
        return 0.0
    return len(sa & sb) / len(sa | sb)


class LangStore:
    def __init__(self, db_path: Path) -> None:
        self.path = Path(db_path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._init()

    # ---------- 连接 ----------

    def _conn(self) -> sqlite3.Connection:
        conn = sqlite3.connect(str(self.path), timeout=8.0)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA synchronous=NORMAL")
        return conn

    def _init(self) -> None:
        with self._conn() as conn:
            conn.executescript(SCHEMA)
            row = conn.execute("SELECT v FROM meta WHERE k='schema'").fetchone()
            if row is None:
                conn.execute("INSERT INTO meta(k,v) VALUES('schema',?)", (SCHEMA_VERSION,))

    # ---------- 画像 ----------

    def touch_profile(self, user_id: int, nickname: str, hits: dict[str, int],
                      avg_len: float, tempo: float, msg_count: int = 1) -> None:
        """累加一条消息的特征到用户画像（增量学习）。"""
        now = _now()
        with self._conn() as conn:
            row = conn.execute(
                "SELECT traits, stats, msg_count FROM profiles WHERE user_id=?",
                (user_id,),
            ).fetchone()
            if row is None:
                traits: dict[str, int] = {}
                stats: dict[str, Any] = {}
                count = 0
                created = now
            else:
                traits = json.loads(row["traits"] or "{}")
                stats = json.loads(row["stats"] or "{}")
                count = int(row["msg_count"] or 0)
                created = now
            for k, v in hits.items():
                traits[k] = int(traits.get(k, 0)) + int(v)
            n = count + msg_count
            prev_len = float(stats.get("avg_len") or 0)
            stats["avg_len"] = round((prev_len * count + avg_len * msg_count) / max(1, n), 2)
            stats["msg_count"] = n
            stats["chars"] = int(stats.get("chars", 0)) + int(avg_len * msg_count)
            # 重要度：样本越多、特征越丰富越高，上限 0.95
            importance = min(0.95, 0.35 + min(n, 120) / 200 + min(len(traits), 60) / 400)
            conn.execute(
                """INSERT INTO profiles(user_id,nickname,msg_count,importance,traits,stats,tempo,created_at,updated_at)
                   VALUES(?,?,?,?,?,?,?,?,?)
                   ON CONFLICT(user_id) DO UPDATE SET
                     nickname=excluded.nickname, msg_count=excluded.msg_count,
                     importance=excluded.importance, traits=excluded.traits,
                     stats=excluded.stats, tempo=excluded.tempo, updated_at=excluded.updated_at""",
                (user_id, nickname[:32], n, importance, json.dumps(traits, ensure_ascii=False),
                 json.dumps(stats, ensure_ascii=False), tempo, created, now),
            )

    def get_profile(self, user_id: int) -> dict[str, Any] | None:
        with self._conn() as conn:
            row = conn.execute("SELECT * FROM profiles WHERE user_id=?", (user_id,)).fetchone()
        if row is None:
            return None
        data = dict(row)
        data["traits"] = json.loads(data.get("traits") or "{}")
        data["stats"] = json.loads(data.get("stats") or "{}")
        data["culture"] = json.loads(data.get("culture") or "{}")
        return data

    def set_culture(self, user_id: int, culture: dict[str, Any]) -> None:
        with self._conn() as conn:
            conn.execute("UPDATE profiles SET culture=? WHERE user_id=?",
                         (json.dumps(culture, ensure_ascii=False), user_id))

    def list_profiles(self, limit: int = 30) -> list[dict[str, Any]]:
        with self._conn() as conn:
            rows = conn.execute(
                "SELECT user_id,nickname,msg_count,importance,updated_at FROM profiles "
                "ORDER BY importance DESC, msg_count DESC LIMIT ?", (limit,)
            ).fetchall()
        return [dict(r) for r in rows]

    # ---------- 记忆条目 ----------

    def add_memory(self, user_id: int, kind: str, content: str, tags: str = "",
                   importance: float = 0.5, tokens: list[str] | None = None,
                   merge_threshold: float = 0.82) -> str:
        """写入记忆；与已有条目高度相似时合并，而不是无限膨胀。

        相似度用「字符二元组 Jaccard」（不依赖分词器，抗轻微改写）。
        返回 'added' | 'merged' | 'skipped'
        """
        content = (content or "").strip()
        if not content:
            return "skipped"
        fp = fingerprint(kind, content, tokens)
        now = _now()
        bigrams = _char_bigrams(content)

        def _bump(conn: sqlite3.Connection, mid: int) -> None:
            conn.execute(
                "UPDATE memories SET hits=hits+1, updated_at=?, importance=MIN(0.95, importance+0.02) WHERE id=?",
                (now, mid),
            )

        with self._conn() as conn:
            dup = conn.execute("SELECT id FROM memories WHERE fingerprint=?", (fp,)).fetchone()
            if dup:
                _bump(conn, dup["id"])
                return "merged"
            if bigrams:
                rows = conn.execute(
                    "SELECT id,content FROM memories WHERE user_id=? AND kind=?",
                    (user_id, kind),
                ).fetchall()
                for row in rows:
                    if jaccard(bigrams, _char_bigrams(row["content"])) >= merge_threshold:
                        _bump(conn, row["id"])
                        return "merged"
            conn.execute(
                """INSERT INTO memories(user_id,kind,content,tags,importance,hits,fingerprint,created_at,updated_at,last_hit)
                   VALUES(?,?,?,?,?,0,?,?,?,?)""",
                (user_id, kind, content[:300], tags[:120], float(importance), fp, now, now, now),
            )
        return "added"

    def recall(self, user_id: int, kinds: tuple[str, ...] | None = None,
               top_k: int = 8, half_life_days: float = 30.0,
               max_chars: int = 700) -> list[dict[str, Any]]:
        """按「重要度 × 时间衰减 × 命中次数」排序取回记忆。"""
        sql = "SELECT * FROM memories WHERE user_id=?"
        args: list[Any] = [user_id]
        if kinds:
            sql += " AND kind IN (%s)" % ",".join("?" * len(kinds))
            args.extend(kinds)
        with self._conn() as conn:
            rows = conn.execute(sql, args).fetchall()
        scored: list[tuple[float, dict[str, Any]]] = []
        for row in rows:
            d = dict(row)
            score = (float(d.get("importance") or 0.5)
                     * decay_factor(float(d.get("updated_at") or 0), half_life_days)
                     * (1.0 + math.log1p(int(d.get("hits") or 0))))
            scored.append((score, d))
        scored.sort(key=lambda kv: -kv[0])

        out: list[dict[str, Any]] = []
        used = 0
        for score, d in scored[:top_k]:
            if used + len(d["content"]) > max_chars:
                break
            used += len(d["content"])
            out.append({"content": d["content"], "kind": d["kind"],
                        "tags": d.get("tags", ""), "score": round(score, 3),
                        "id": d["id"]})
        if out:
            with self._conn() as conn:
                ids = [o["id"] for o in out]
                conn.execute(
                    "UPDATE memories SET hits=hits+1, last_hit=? WHERE id IN (%s)"
                    % ",".join("?" * len(ids)),
                    [_now(), *ids],
                )
        return out

    def delete_memory(self, memory_id: int) -> bool:
        with self._conn() as conn:
            cur = conn.execute("DELETE FROM memories WHERE id=?", (memory_id,))
            return cur.rowcount > 0

    def delete_user(self, user_id: int) -> dict[str, int]:
        """彻底删除某用户的画像、记忆与样本（隐私删除）。"""
        with self._conn() as conn:
            p = conn.execute("DELETE FROM profiles WHERE user_id=?", (user_id,)).rowcount
            m = conn.execute("DELETE FROM memories WHERE user_id=?", (user_id,)).rowcount
            s = conn.execute("DELETE FROM samples WHERE user_id=?", (user_id,)).rowcount
        return {"profiles": p, "memories": m, "samples": s}

    # ---------- 样本 ----------

    def add_sample(self, user_id: int, group_id: int | None, text: str, keep: int) -> None:
        with self._conn() as conn:
            conn.execute(
                "INSERT INTO samples(user_id,group_id,text,created_at) VALUES(?,?,?,?)",
                (user_id, group_id, text[:300], _now()),
            )
            # 只保留最近 keep 条，避免库无限增长
            conn.execute(
                "DELETE FROM samples WHERE user_id=? AND id NOT IN "
                "(SELECT id FROM samples WHERE user_id=? ORDER BY id DESC LIMIT ?)",
                (user_id, user_id, max(10, keep)),
            )

    def recent_samples(self, user_id: int, limit: int = 20) -> list[str]:
        with self._conn() as conn:
            rows = conn.execute(
                "SELECT text FROM samples WHERE user_id=? ORDER BY id DESC LIMIT ?",
                (user_id, limit),
            ).fetchall()
        return [r["text"] for r in rows]

    # ---------- 隐私开关 ----------

    def set_optout(self, user_id: int, off: bool) -> None:
        with self._conn() as conn:
            if off:
                conn.execute("INSERT OR REPLACE INTO optout(user_id,created_at) VALUES(?,?)",
                             (user_id, _now()))
            else:
                conn.execute("DELETE FROM optout WHERE user_id=?", (user_id,))

    def is_optout(self, user_id: int) -> bool:
        with self._conn() as conn:
            return conn.execute("SELECT 1 FROM optout WHERE user_id=?", (user_id,)).fetchone() is not None

    # ---------- 维护 ----------

    def stats(self) -> dict[str, int]:
        with self._conn() as conn:
            def one(sql: str) -> int:
                row = conn.execute(sql).fetchone()
                return int(row[0] or 0) if row else 0
            return {
                "profiles": one("SELECT COUNT(*) FROM profiles"),
                "memories": one("SELECT COUNT(*) FROM memories"),
                "samples": one("SELECT COUNT(*) FROM samples"),
                "optout": one("SELECT COUNT(*) FROM optout"),
            }

    def vacuum(self) -> None:
        with self._conn() as conn:
            conn.execute("VACUUM")
