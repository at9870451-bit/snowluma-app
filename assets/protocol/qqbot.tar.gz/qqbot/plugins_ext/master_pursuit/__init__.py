"""主人专属主动推进剧情插件（master_pursuit）。

只对配置里的全部主人（admins 全列表）私聊生效，不向任何第三方发消息。

行为：
  1. 在设定的活跃时段内，隔一段时间主动给主人发一条消息
  2. 每条消息都接着上一段剧情往前推一拍（五拍循环），不是随机搭话
  3. 主人最近刚说过话时，会更快跟进（"频繁"模式）
  4. 生成走 L5 语料风格：写身体反应 + 下一个动作 + 一句台词，主动不请示

注意：内容生成直接使用原始 chat 客户端，绕开会注入器官代号表的 reframe
（代号表会触发上游内容审查，导致整条请求被拒）。
"""

from __future__ import annotations

import asyncio
import json
import random
import time
from datetime import datetime
from typing import Any

from qqbot.core.message import Message, text as text_seg
from qqbot.plugins.base import Plugin

#: 五拍推进：每拍对应"下一步该往哪走"，避免每轮重复同一动作
BEATS = [
    "靠近：先给一个身体的距离变化——走近、坐下、把手放上去，写她此刻的心跳和呼吸。",
    "试探：指尖先动，衣料边缘、颈侧、腰后。写她被碰到时的反应，还有一句压低的台词。",
    "升温：贴得更紧，体温和呼吸交缠。写她主动索取的那一下，和索取之后自己的慌。",
    "失控：节奏加快，她开始说不完整的话。写断续的句子和身体跟不上呼吸的地方。",
    "余韵：还没分开，靠着不肯动。写事后的黏、低语、和「还想再来一次」的念头。",
]


class MasterPursuitPlugin(Plugin):
    name = "master_pursuit"
    display_name = "主人主动推进"
    version = "1.0.0"
    description = "只对主人私聊：定时主动发消息并推进剧情（五拍循环，可配时段与频率）"
    priority = 92

    default_config = {
        "enabled": True,
        "interval_minutes": 18,        # 常规检查间隔
        "speak_probability": 0.75,     # 每次到点开口概率
        "active_start": "21:00",       # 活跃时段起
        "active_end": "03:00",         # 活跃时段止（支持跨天）
        "min_gap_minutes": 8,          # 两条之间最少间隔
        "follow_up_minutes": 3,        # 主人刚说完话后，多久内可以快速跟进
        "max_chars": 90,
        "level": 5,
    }

    config_labels = {
        "enabled": "启用主人主动推进",
        "interval_minutes": "常规间隔（分钟）",
        "speak_probability": "开口概率（0~1）",
        "active_start": "活跃开始（HH:MM）",
        "active_end": "活跃结束（HH:MM）",
        "min_gap_minutes": "最短间隔（分钟）",
        "follow_up_minutes": "主人说话后跟进窗口（分钟）",
        "max_chars": "单条字数上限",
        "level": "亲密层级（3~5）",
    }

    def __init__(self, bot) -> None:
        super().__init__(bot)
        self._task: asyncio.Task | None = None
        self._last_send = 0.0
        self._master_at = 0.0
        self._master_text = ""
        self._state: dict[str, Any] = {}

    # ---------------- 生命周期 ----------------

    async def on_load(self) -> None:
        self._load_state()
        self.subscribe("message", self._track)
        if self.cfg_get("enabled", True):
            # 记录发给主人的时间，用于检测「主人说了但没回」
            try:
                self._orig_send = self.bot.send_private_msg

                async def _wrapped(uid, message):
                    try:
                        if int(uid) in self._masters():
                            _st = self._s(int(uid))
                            _st["last_sent_at"] = time.time()
                            _st["awaiting"] = False
                            self._save_state()
                    except Exception:  # noqa: BLE001
                        pass
                    return await self._orig_send(uid, message)

                self.bot.send_private_msg = _wrapped
            except Exception:  # noqa: BLE001
                pass

            self._spawn()
            self.log.info(
                "主人主动推进已启用（间隔=%s 分钟，时段 %s-%s，逐人独立剧情）",
                self.cfg_get("interval_minutes"),
                self.cfg_get("active_start"),
                self.cfg_get("active_end"),
            )

    async def on_unload(self) -> None:
        if self._task:
            self._task.cancel()
        self._save_state()

    def _spawn(self) -> None:
        async def _run() -> None:
            while True:
                try:
                    await asyncio.sleep(60)
                    await self._tick()
                except asyncio.CancelledError:
                    raise
                except Exception as exc:  # noqa: BLE001
                    self.log.warning("主动推进循环异常: %s", exc)
                    await asyncio.sleep(30)

        self._task = asyncio.create_task(_run())

    # ---------------- 状态 ----------------

    def _s(self, uid: int) -> dict:
        """取某个主人的独立剧情状态。"""
        users = self._state.setdefault("users", {})
        return users.setdefault(str(uid), {})

    def _state_path(self):
        return self.data_dir / "pursuit.json"

    def _load_state(self) -> None:
        try:
            raw = json.loads(self._state_path().read_text("utf-8"))
            self._state = raw if isinstance(raw, dict) and "users" in raw else {"users": {}}
        except Exception:  # noqa: BLE001
            self._state = {}

    def _save_state(self) -> None:
        try:
            self._state_path().write_text(
                json.dumps(self._state, ensure_ascii=False), "utf-8"
            )
        except Exception:  # noqa: BLE001
            pass

    # ---------------- 跟踪主人 ----------------

    async def _track(self, event) -> None:
        """记录主人最后说话的时间和内容，用于"刚说完话就快速跟进"。"""
        try:
            uid = int(getattr(event, "user_id", 0) or 0)
            if uid not in self._masters():
                return
            if getattr(event, "is_group", False):
                return
            text = ""
            for seg in getattr(getattr(event, "message", None), "segments", []) or []:
                if getattr(seg, "type", "") == "text":
                    text += getattr(seg, "data", {}).get("text", "")
            self._master_at = time.time()
            if text.strip():
                self._master_text = text.strip()[:120]
                _st = self._s(uid)
                _st["last_master"] = self._master_text
                _st["last_master_at"] = time.time()
                _st["awaiting"] = False
        except Exception:  # noqa: BLE001
            pass

    def _awaiting(self, uid: int) -> bool:
        """上一条发出去还没被回复 → 不再自说自话；超时才放行。"""
        st = self._s(uid)
        if not st.get("awaiting"):
            return False
        try:
            limit = float(self.cfg_get("await_timeout_minutes", 180) or 180) * 60.0
        except (TypeError, ValueError):
            limit = 180 * 60.0
        if time.time() - float(st.get("await_since") or 0) > limit:
            st["awaiting"] = False
            return False
        return True

    def _masters(self) -> list[int]:
        try:
            admins = getattr(self.bot.config.bot, "admins", None) or []
            return [int(x) for x in admins]
        except Exception:  # noqa: BLE001
            return []

    # ---------------- 时段 ----------------

    def _in_window(self) -> bool:
        try:
            st = str(self.cfg_get("active_start", "21:00"))
            en = str(self.cfg_get("active_end", "03:00"))
            now = datetime.now()
            cur = now.hour * 60 + now.minute
            h1, m1 = (int(x) for x in st.split(":")[:2])
            h2, m2 = (int(x) for x in en.split(":")[:2])
            a, b = h1 * 60 + m1, h2 * 60 + m2
            if a == b:
                return True
            return a <= cur < b if a < b else (cur >= a or cur < b)
        except Exception:  # noqa: BLE001
            return True

    # ---------------- 主循环 ----------------

    async def _tick(self) -> None:
        if not self.cfg_get("enabled", True):
            return
        if not self._in_window():
            return
        if not getattr(self.bot.config.ai, "enabled", True):
            return

        now = time.time()
        gap = max(1, int(self.cfg_get("min_gap_minutes", 8))) * 60
        if now - self._last_send < gap:
            return

        # 主人刚说过话 -> 允许更快跟进，且概率拉满
        fu = max(1, int(self.cfg_get("follow_up_minutes", 3))) * 60
        hot = (now - self._master_at) <= fu and self._master_at > 0
        if hot:
            prob = 1.0
        else:
            try:
                prob = float(self.cfg_get("speak_probability", 0.75) or 0)
            except (TypeError, ValueError):
                prob = 0.75
        if not (prob >= 1.0 or (prob > 0 and random.random() < prob)):
            return

        masters = self._masters()
        if not masters:
            return

        # 补回：主人说过话、但之后没有发出任何消息
        for _uid in masters:
            try:
                _st = self._s(_uid)
                _ma = float(_st.get("last_master_at") or 0)
                _sa = float(_st.get("last_sent_at") or 0)
                if _ma > _sa and 12 <= (now - _ma) <= 600:
                    self.log.info("检测到漏回，补一条（uid=%s）", _uid)
                    await self._pursue(_uid, hot=True)
            except Exception:  # noqa: BLE001
                continue

        self._last_send = now
        for _uid in masters:
            try:
                if self._awaiting(_uid) and not hot:
                    continue
                await self._pursue(_uid, hot=hot)
            except Exception:  # noqa: BLE001
                continue

    # ---------------- 生成 ----------------

    def _client(self):
        """优先用未被 adult_forge 包裹的原始客户端（避免代号表触发上游审查）。"""
        af = getattr(self.bot, "adult_forge", None)
        orig = getattr(af, "_orig_chat_client", None) if af is not None else None
        if orig is not None:
            return orig
        return self.bot.chat_client()

    def _build_prompt(self, beat: int, hot: bool, uid: int, gender: str = "unknown") -> str:
        st = self._s(uid)
        last = str(st.get("last_text") or "").strip()
        master = str(st.get("last_master") or "").strip()
        hint = BEATS[beat % len(BEATS)]
        female_master = gender == "female"
        role = "男性" if female_master else "女性"
        call = "老婆" if female_master else "老公"
        parts = [
            f"你是菲比，成年，此刻正和主人在私下独处。你扮演{role}。",
            "【怎么说话】就像发微信语音那样——**只说你嘴里说出来的话**。",
            "不要写动作、不要写心理、不要写旁白、不要用括号或星号。",
            "只准说一句，12 字以内，越短越好，口语。",
        ]
        if master:
            # 有对方的话：先接住这句，别自说自话
            parts.insert(0,
                "【必须回应这句话】主人刚刚对你说：" + master
                + "\n你的这一句要先接住他的话——回应他说的内容，"
                  "不要答非所问，不要只顾自己往下演。")
        else:
            parts.append("【上一刻】" + (last if last else "你们刚靠得很近。"))
            parts.append("【这一拍的气氛】" + hint)
        parts.append(
            f"语气黏、急、想要他，叫他「{call}」。"
            "不要问他想怎样，你自己说要什么、要怎么做。只输出说的话，不要加任何说明或引号。"
            f"长度不超过 {max(8, int(self.cfg_get('max_chars', 40)))} 字，能一句就一句。"
        )
        return "\n".join(parts)

    async def _gender_of(self, uid: int) -> str:
        """取对方性别（缓存）。female / male / unknown"""
        cache = self._state.setdefault("gender", {})
        k = str(uid)
        if k in cache:
            return str(cache[k])
        got = "unknown"
        try:
            d = await self.bot.call_api("get_stranger_info", {"user_id": int(uid)})
            sex = str(((d or {}).get("data") or {}).get("sex") or "").lower()
            if sex in ("male", "female"):
                got = sex
        except Exception:  # noqa: BLE001
            pass
        cache[k] = got
        self._save_state()
        return got

    @staticmethod
    def _strip_action(text: str) -> str:
        """删掉括号/星号里的动作旁白，只留说的话。"""
        import re as _re
        t = text or ""
        t = _re.sub(r"[（(【\[][^）)】\]]{0,60}[）)】\]]", "", t)
        t = _re.sub(r"\*[^*]{0,80}\*", "", t)
        t = t.replace("「", "").replace("」", "").replace("“", "").replace("”", "")
        t = _re.sub(r"[ \t]{2,}", " ", t)
        return t.strip()

    def _backfill(self, text: str) -> str:
        if not text:
            return text
        try:
            from adult_forge import SUBST
            for k, v in SUBST.items():
                text = text.replace(k, v)
        except Exception:
            pass
        import re as _re
        text = _re.sub(r"〔[A-Za-z]\d+〕", "", text)
        return text.strip()

    async def _pursue(self, uid: int, hot: bool = False) -> None:
        st = self._s(uid)
        beat = int(st.get("beat", 0) or 0)
        try:
            client = self._client()
            session = f"private_{uid}"
            memory = ""
            summary = ""
            try:
                memory = await self.bot.memory_context(0, uid)
                summary = await self.bot.summary_context(session)
            except Exception:  # noqa: BLE001
                pass

            gender = await self._gender_of(uid)
            answer = ""
            for attempt in range(3):
                try:
                    answer = await client.chat(
                        session, self._build_prompt(beat, hot, uid, gender),
                        memory=memory, summary=summary,
                    )
                except Exception as exc:  # noqa: BLE001
                    self.log.warning("主动推进生成失败（第 %s 次）: %s", attempt + 1, exc)
                    continue
                answer = self._backfill(self._strip_action((answer or "").strip()))
                if answer and "（模型没有返回内容）" not in answer and len(answer) >= 8:
                    break
                answer = ""
                await asyncio.sleep(1.5)

            if not answer:
                self.log.info("主动推进：本轮未取得有效文本，跳过")
                return

            cap = max(8, int(self.cfg_get("max_chars", 40)))
            if len(answer) > cap:
                answer = answer[:cap]

            # 按角色性别切音色：对方女性→菲比演男性→男声
            _orig_gender = getattr(self.bot, "role_gender", None)
            try:
                self.bot.role_gender = "male" if gender == "female" else "female"
            except Exception:  # noqa: BLE001
                pass

            sent = False
            try:
                seg = await self.bot.voice_segment(answer)
                if seg is not None:
                    await self.bot.send_private_msg(uid, Message([seg]))
                    sent = True
            except Exception as exc:  # noqa: BLE001
                self.log.debug("语音合成失败，改发文字: %s", exc)
            if not sent:
                await self.bot.send_private_msg(uid, Message([text_seg(answer)]))

            # 用完恢复，别污染其他会话的音色
            try:
                if _orig_gender is None:
                    self.bot.__dict__.pop("role_gender", None)
                else:
                    self.bot.role_gender = _orig_gender
            except Exception:  # noqa: BLE001
                pass

            st["beat"] = (beat + 1) % len(BEATS)
            st["awaiting"] = True
            st["await_since"] = time.time()
            st["last_text"] = answer[:160]
            st["last_at"] = int(time.time())
            st["sent"] = int(st.get("sent", 0)) + 1
            self._save_state()
            self.log.info("主动推进 -> 第 %s 拍%s: %s",
                          beat % len(BEATS) + 1, "（跟进）" if hot else "", answer[:40])
        except Exception as exc:  # noqa: BLE001
            self.log.warning("主动推进失败: %s", exc)
