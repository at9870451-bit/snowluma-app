"""persona_voice — 角色卡解析 → 声音风格参数。

输入：QQBot 角色卡 prompt（ai.personas[active].prompt）或人设文本。
输出：基线 VoiceStyle（音色/语速/音调/音量）+ 角色元信息（名称/年龄/性别/性格标签）。

解析方式：关键词规则（零成本、无需模型）。
  - 性别/年龄 → 音色池选择（女/男 × 少/中/长）
  - 性格词（活泼/毒舌/温柔/冷淡/软糯…）→ 语速、音调、音量基线
  - 说话习惯（短句/慢/快/撒娇）→ 语速微调
配置可覆盖任何自动推断（config.role_tts.roles.<角色名>.*）。
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any

from .engines.base import VoiceStyle

# 女声池 / 男声池（piper 现有音色 + 常见云端音色名，按引擎自动取可用者）
FEMALE_VOICES = ["xiaoya", "huayan_fast", "huayan", "alloy", "nova", "shimmer"]
MALE_VOICES = ["chaowen", "onyx", "echo", "fable"]

# edge-tts 中文音色池（按气质）
EDGE_VOICE_BY_TRAIT = {
    "活泼": "zh-CN-XiaoyiNeural",
    "开朗": "zh-CN-XiaoyiNeural",
    "可爱": "zh-CN-XiaoyiNeural",
    "软糯": "zh-CN-XiaoyiNeural",
    "撒娇": "zh-CN-XiaoyiNeural",
    "温柔": "zh-CN-XiaoxiaoNeural",
    "成熟": "zh-CN-XiaoxiaoNeural",
    "稳重": "zh-CN-XiaoxiaoNeural",
    "毒舌": "zh-CN-liaoning-XiaobeiNeural",   # 东北大妞，活人感最强
    "傲娇": "zh-CN-liaoning-XiaobeiNeural",
    "高冷": "zh-CN-XiaoxiaoNeural",
    "冷淡": "zh-CN-XiaoxiaoNeural",
}
EDGE_FEMALE_DEFAULT = "zh-CN-XiaoyiNeural"
EDGE_MALE_DEFAULT = "zh-CN-YunxiNeural"

# 性格 → (语速系数, 音调半音, 音量 dB)
TRAITS = {
    "活泼": (1.08, 1.5, 1.0),
    "开朗": (1.06, 1.0, 0.8),
    "可爱": (1.02, 2.5, 0.5),
    "软糯": (0.96, 2.0, 0.0),
    "撒娇": (0.98, 2.0, 0.5),
    "温柔": (0.94, 0.5, 0.0),
    "冷淡": (0.96, -1.5, -1.0),
    "毒舌": (1.05, 0.5, 1.0),
    "傲娇": (1.03, 1.5, 0.8),
    "成熟": (0.95, -1.0, 0.0),
    "活泼嘴碎": (1.10, 1.5, 1.2),
    "高冷": (0.94, -2.0, -1.5),
    "稳重": (0.93, -0.5, 0.0),
}

# 英文标记式角色卡（如 PERSONALITY_SMART_LAZY / TSUNDERE / LOLI）
EN_TRAITS = {
    "LOLI": "可爱", "CUTE": "可爱", "SWEET": "温柔", "GENTLE": "温柔",
    "TSUNDERE": "傲娇", "SMART": "成熟", "LAZY": "冷淡", "COLD": "冷淡",
    "KUUDERE": "高冷", "ENERGETIC": "活泼", "CHEERFUL": "开朗",
    "SASSY": "毒舌", "MATURE": "成熟", "SHY": "软糯",
}

AGE_YOUNG = ("萝莉", "少女", "学生", "岁", "1", "2")
AGE_MATURE = ("成熟", "御姐", "大叔", "中年")


@dataclass
class PersonaProfile:
    name: str = ""
    gender: str = "female"
    age_hint: str = ""
    traits: list[str] = field(default_factory=list)
    speech_notes: list[str] = field(default_factory=list)
    style: VoiceStyle = field(default_factory=VoiceStyle)


def _first_match(text: str, keys) -> str:
    for k in keys:
        if k in text:
            return k
    return ""


def parse_persona(card_text: str, *, role_cfg: dict[str, Any] | None = None,
                  engine: str = "piper") -> PersonaProfile:
    """从角色卡文本解析声音风格；role_cfg 里的显式配置优先级最高。"""
    text = card_text or ""
    role_cfg = role_cfg or {}
    prof = PersonaProfile()

    # 名称：优先配置，其次「你是「X」」/「你叫X」/「我叫X」
    name = str(role_cfg.get("name") or "").strip()
    if not name:
        for pat in (r"你是[「\"']([^」\"']{1,12})[」\"']",
                    r"你叫[「\"']?([^\s，。、」\"']{1,12})",
                    r"我是[「\"']([^」\"']{1,12})[」\"']",
                    r"^([A-Z][A-Z_]{3,24})\s*$"):
            m = re.search(pat, text, re.M)
            if m:
                name = m.group(1)
                break
    EN_NAME = {"CETACEA": "鲸鱼", "WHALE": "鲸鱼", "LOLI": "萝莉",
               "CAT": "猫", "FOX": "狐狸", "RABBIT": "兔"}
    if name and name.isupper() and "_" in name:
        parts = [EN_NAME.get(x, "") for x in name.split("_")]
        readable = "".join(p for p in parts if p)
        if readable:
            name = readable
    prof.name = name

    # 性别
    gender = str(role_cfg.get("gender") or "").lower()
    if not gender:
        if re.search(r"(女孩|女生|女|少女|姐姐|妹妹|老婆|她|LOLI|GIRL|FEMALE|SHE)", text):
            gender = "female"
        elif re.search(r"(男孩|男生|男|少年|哥哥|弟弟|大叔|他)", text):
            gender = "male"
        else:
            gender = "female"
    prof.gender = "male" if gender in ("male", "男", "m") else "female"

    # 性格标签
    traits = [k for k in TRAITS if k in text]
    upper = text.upper()
    for en, zh in EN_TRAITS.items():
        if en in upper and zh not in traits:
            traits.append(zh)
    prof.traits = traits[:4]

    # 说话习惯
    notes: list[str] = []
    if re.search(r"(短句|一句|简短|话少|冷淡|简洁)", text):
        notes.append("short")
    if re.search(r"(话多|啰嗦|话痨|碎碎念)", text):
        notes.append("chatty")
    if re.search(r"(慢|轻|温柔)", text):
        notes.append("slow")
    if re.search(r"(快|急|蹦豆)", text):
        notes.append("fast")
    prof.speech_notes = notes

    # —— 合成基线 ——
    speed, pitch, volume = 1.0, 0.0, 0.0
    for t in traits:
        ds, dp, dv = TRAITS[t]
        speed = (speed + ds) / 2 if speed != 1.0 else ds
        pitch += dp * 0.6
        volume += dv * 0.5
    if "short" in notes:
        speed *= 1.03
    if "slow" in notes:
        speed *= 0.95
    if "fast" in notes:
        speed *= 1.05
    if "chatty" in notes:
        speed *= 1.02

    # 音色池：按引擎区分
    voice = str(role_cfg.get("voice") or "").strip()
    if engine == "edge":
        if not voice:
            # 按性格挑最贴合的 edge 音色
            for t in traits:
                if t in EDGE_VOICE_BY_TRAIT:
                    voice = EDGE_VOICE_BY_TRAIT[t]
                    break
            if not voice:
                voice = EDGE_FEMALE_DEFAULT if prof.gender == "female" else EDGE_MALE_DEFAULT
        elif not voice.startswith("zh-") and not voice.startswith("en-"):
            # 用户填的是 piper 音色名 → 映射到 edge 对应气质
            voice = EDGE_VOICE_BY_TRAIT.get(traits[0], EDGE_FEMALE_DEFAULT) if traits else EDGE_FEMALE_DEFAULT
    else:
        pool = FEMALE_VOICES if prof.gender == "female" else MALE_VOICES
        if not voice:
            voice = pool[0]
        if engine == "piper":
            piper_pool = (["xiaoya", "huayan_fast", "huayan"]
                          if prof.gender == "female" else ["chaowen"])
            voice = voice if voice in piper_pool else piper_pool[0]

    prof.style = VoiceStyle(
        voice=voice,
        speed=max(0.7, min(1.4, float(role_cfg.get("speed") or speed))),
        pitch=float(role_cfg.get("pitch") or round(pitch, 1)),
        volume=max(-6.0, min(6.0, float(role_cfg.get("volume") or round(volume, 1)))),
    )
    return prof


def describe(prof: PersonaProfile) -> str:
    st = prof.style
    return (f"角色「{prof.name or '未命名'}」"
            f"（{'女' if prof.gender == 'female' else '男'}声）"
            f" 音色={st.voice} 语速={st.speed:.2f} 音调={st.pitch:+.1f} 音量={st.volume:+.1f}"
            + (f" 性格={'/'.join(prof.traits)}" if prof.traits else ""))
