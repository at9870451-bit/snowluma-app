"""TTS 文本处理：长度裁剪 + 口语化润色（去除人机味）。"""

from __future__ import annotations

import random
import re

CONNECTORS_TO_STRIP = [
    "而且", "然后", "所以", "但是", "不过", "因为", "其实", "真的",
    "确实", "可能", "应该", "或者",
]

EMO_EXTRA = {
    "happy": ["哈", "嘿嘿", "好"],
    "sad": ["唉", "唉"],
    "cute": ["嘛", "呀"],
    "angry": ["啧"],
    "cold": [],
    "shy": ["那个"],
    "confused": ["诶"],
    "neutral": [],
}

TAIL_PARTICLES = ["呀", "啦", "呗", "嘛", "吧", "", "", ""]


def shrink_for_voice(text: str, max_len: int = 30) -> str:
    """语音专用长度裁剪：只取第一句/前 30 字（真人语音不会说太长）。"""
    t = (text or "").strip()
    for sep in ("。", "！", "？", "\n"):
        if sep in t:
            first = t.split(sep)[0].strip()
            if len(first) >= 3:
                t = first
            break
    if len(t) > max_len:
        cut = t[:max_len]
        if " " in cut:
            cut = cut[:cut.rfind(" ")].strip()
        t = cut
    return t


def polish_for_tts(text: str, emotion: str = "neutral", *,
                   seed: int | None = None) -> str:
    """TTS 文本处理：去书面标点连用、保留停顿、加语气词/拉长音。"""
    t = (text or "").strip()
    if not t:
        return t
    rng = random.Random(seed if seed is not None else abs(hash(text)))
    # 保留句号/问号/感叹号作停顿，压缩连续标点，顿号转逗号
    t = re.sub(r"，{2,}", "，", t)
    t = re.sub(r",{2,}", ",", t)
    t = t.replace("、", "，")
    t = re.sub(r"。{2,}", "。", t)
    # 去书面连接词
    for w in CONNECTORS_TO_STRIP:
        t = t.replace(w, "")
    t = re.sub(r"\s+", " ", t).strip()
    # 30% 省略尾句（只说一半）
    if " " in t and rng.random() < 0.30:
        parts = t.rsplit(" ", 1)
        if len(parts) == 2 and len(parts[0]) >= 4:
            t = parts[0].strip()
    # 拉长音
    if rng.random() < 0.40:
        chars = list(t)
        idxs = [i for i, ch in enumerate(chars)
                if ch in "好行对是嗯哦啊累乖可" and i > 0]
        if idxs:
            i = rng.choice(idxs)
            chars[i] = chars[i] + "~"
            t = "".join(chars)
    # 语气词
    extra = EMO_EXTRA.get(emotion, [])
    if extra and rng.random() < 0.30:
        t = rng.choice(extra) + t
    # 句尾助词
    if rng.random() < 0.35:
        tail = rng.choice(TAIL_PARTICLES)
        if tail and not t.endswith(("呀", "啦", "呗", "嘛", "吧", "~", "…")):
            t = t + tail
    # 代理词缀剥离保险
    for _ in range(3):
        m = re.match(r"^[（(][^（）()]{1,6}[)）]\s*(\S.*)$", t)
        if not m:
            break
        t = m.group(1)
    return t.strip()


def jitter_params(base_speed: float, base_pitch: float, *,
                  seed: int | None = None) -> tuple[float, float]:
    """给语速/音调加随机微抖动（±3%），让同一句话每次也不完全一样。"""
    rng = random.Random(seed)
    ds = rng.uniform(-0.07, 0.09)   # 语速 ±7~9%（真人说话有快有慢）
    dp = rng.uniform(-2.5, 2.5)     # 音调 ±2.5Hz
    return (max(0.7, min(1.4, base_speed + ds)),
            max(-4.0, min(4.0, base_pitch + dp)))


def add_pause_marks(text: str, emotion: str = "neutral") -> str:
    """在长句的逗号后加停顿感（省略号模拟呼吸）。"""
    if len(text) < 20:
        return text
    if emotion in ("sad", "cold", "shy"):
        t = re.sub(r"(?<![，。！？…])，(?![，。！？…])", "，…", text, count=1)
        t = t.replace("。", "。…") if len(t) > 30 else t
        return t
    return text