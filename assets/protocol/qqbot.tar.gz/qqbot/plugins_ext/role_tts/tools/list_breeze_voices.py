#!/usr/bin/env python3
"""列出 BreezeBlue 可用音色（拿到 API Key 后跑一次挑 voice_id）。

用法：python3 list_breeze_voices.py <API_KEY> [language_code]
"""
import json
import sys

import httpx


def main() -> None:
    key = sys.argv[1] if len(sys.argv) > 1 else ""
    lang = sys.argv[2] if len(sys.argv) > 2 else "zh"
    if not key:
        print("用法: python3 list_breeze_voices.py <API_KEY> [zh|en...]")
        return
    with httpx.Client(timeout=30) as cli:
        r = cli.get("https://api.breeze.blue/v1/voices",
                    params={"language_code": lang, "page_size": 50},
                    headers={"xi-api-key": key})
        print("HTTP", r.status_code)
        data = r.json() if r.content else {}
        items = data.get("items") or data.get("voices") or data.get("data") or []
        if not items:
            print("原始响应:", json.dumps(data, ensure_ascii=False)[:600])
            return
        for v in items[:40]:
            vid = v.get("voice_id") or v.get("id") or "?"
            name = v.get("name") or ""
            gender = v.get("gender") or v.get("labels", {}).get("gender", "")
            tags = v.get("tags") or v.get("labels") or ""
            print(f"{vid}  {name}  [{gender}] {str(tags)[:60]}")


if __name__ == "__main__":
    main()
