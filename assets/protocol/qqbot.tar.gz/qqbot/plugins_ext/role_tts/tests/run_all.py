"""role_tts 测试套件（离线，不调外部 API）。

运行：cd /opt/qqbot && python3 plugins_ext/role_tts/tests/run_all.py
"""

from __future__ import annotations

import asyncio
import sys
import tempfile
import time
from pathlib import Path

sys.path.insert(0, "/opt/qqbot")
sys.path.insert(0, "/opt/qqbot/plugins_ext")

PASS = FAIL = 0


def check(name: str, cond: bool, detail: str = "") -> None:
    global PASS, FAIL
    if cond:
        PASS += 1
        print(f"  ✓ {name}")
    else:
        FAIL += 1
        print(f"  ✗ {name} {detail}")


def t_persona():
    print("[1] 角色卡解析 → 声音风格")
    from role_tts import persona_voice

    card = """【身份】你是「菲比」，QQ 群里的真人女孩，不是 AI 助手。
【性格】活泼嘴碎、爱调侃、偶尔毒舌但心软。
【说话】短句口语大白话。"""
    p = persona_voice.parse_persona(card, engine="piper")
    check("解析名称", p.name == "菲比", p.name)
    check("识别女声", p.gender == "female")
    check("识别性格", "活泼" in "".join(p.traits), str(p.traits))
    check("音色在 piper 池", p.style.voice in ("xiaoya", "huayan_fast", "huayan"), p.style.voice)
    check("语速合理", 0.7 <= p.style.speed <= 1.4, str(p.style.speed))
    # 男声角色
    p2 = persona_voice.parse_persona("你是一个稳重的男生，说话简短", engine="piper")
    check("男声识别", p2.gender == "male" and p2.style.voice == "chaowen",
          f"{p2.gender}/{p2.style.voice}")
    # 显式覆盖
    p3 = persona_voice.parse_persona(card, role_cfg={"voice": "huayan", "speed": 1.2},
                                     engine="piper")
    check("配置覆盖生效", p3.style.voice == "huayan" and abs(p3.style.speed - 1.2) < 0.01)


def t_emotion():
    print("[2] 情绪分析 + 参数叠加")
    from role_tts import emotion as E
    from role_tts.engines.base import VoiceStyle

    base = VoiceStyle(voice="xiaoya", speed=1.0, pitch=0.0, volume=0.0)
    cases = {
        "哈哈哈笑死我了": "happy",
        "滚 别烦我": "angry",
        "人家想要嘛": "cute",
        "唉 算了 没劲": "sad",
        "啊？什么鬼": "confused",
        "哦 行吧": "cold",
    }
    for text, want in cases.items():
        got, _ = E.analyze(text)
        check(f"识别「{text[:6]}」→ {want}", got == want, got)
    emo, s = E.analyze("哈哈哈哈哈太好了！！！")
    check("强度随感叹号增强", s > 0.3, str(s))
    st = E.apply_emotion(base, "happy", 0.8)
    check("开心：语速变快", st.speed > base.speed, f"{base.speed}→{st.speed}")
    check("开心：音调升高", st.pitch > base.pitch, f"{st.pitch}")
    st2 = E.apply_emotion(base, "sad", 0.8)
    check("悲伤：语速变慢", st2.speed < base.speed, f"{st2.speed}")
    check("情绪进 cache_key", "happy" in st.cache_key())


def t_cache():
    print("[3] 语音缓存（LRU + 磁盘）")
    from role_tts.cache import VoiceCache

    c = VoiceCache(Path(tempfile.mkdtemp()) / "cache", max_items=5, max_mem_items=2)
    k = VoiceCache.make_key("piper", "xiaoya|1.00|0.0|0.0|happy|0.8", "你好")
    check("空缓存未命中", c.get(k) is None)
    c.put(k, b"audio-bytes")
    check("写入后命中", c.get(k) == b"audio-bytes")
    check("同文本同参 key 一致", k == VoiceCache.make_key(
        "piper", "xiaoya|1.00|0.0|0.0|happy|0.8", "你好"))
    check("不同情绪 key 不同", k != VoiceCache.make_key(
        "piper", "xiaoya|1.00|0.0|0.0|sad|0.8", "你好"))
    st = c.stats()
    check("统计正确", st["files"] == 1 and st["mem"] >= 1, str(st))
    n = c.clear()
    check("清空", n == 1 and c.get(k) is None)


def t_audio():
    print("[4] 音频统一（wav→ogg）")
    from role_tts import audio

    ok = audio.has_ffmpeg()
    print(f"    ffmpeg 可用: {ok}")
    if not ok:
        check("无 ffmpeg 时优雅降级", True)
        return
    # 造 0.3s 静音 wav
    import io
    import struct
    import wave

    buf = io.BytesIO()
    with wave.open(buf, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(16000)
        w.writeframes(b"\x00\x00" * 4800)
    wav = buf.getvalue()
    out, fmt = asyncio.run(audio.normalize(wav, "wav"))
    check("转码为 ogg", fmt == "ogg", fmt)
    check("体积显著缩小", len(out) < len(wav), f"{len(wav)}→{len(out)}")
    check("ogg 魔数正确", out[:4] == b"OggS", out[:4])


def t_engine_registry():
    print("[5] 引擎注册表（可插拔）")
    from role_tts import engines

    check("内置三引擎", set(engines.available()) >= {"piper", "openai", "custom"},
          str(engines.available()))
    e = engines.build("piper", {"base_url": "http://127.0.0.1:8765"})
    check("构造 piper", e.name == "piper")
    try:
        engines.build("nope", {})
        check("未知引擎报错", False)
    except RuntimeError:
        check("未知引擎报错", True)


def t_trigger():
    print("[6] 触发与限流（概率/冷却/上限/长度）")
    from role_tts import RoleTTSPlugin
    from types import SimpleNamespace

    class FakeBus:
        def on(self, t, h, p=None):
            class _S:
                def cancel(self): pass
            return _S()

    class FakeAI:
        enabled = True
        triggers = []
        personas = [{"name": "默认", "prompt": "你是「菲比」，QQ群里的女孩，活泼"}]
        active_persona = "默认"
        system_prompt = ""

    class FakeCfg:
        paths = type("P", (), {"plugin_data_dir": Path(tempfile.mkdtemp())})()
        custom = {}
        ai = FakeAI()
        def save(self): pass

    class FakeBot:
        config = FakeCfg()
        bus = FakeBus()
        async def voice_segment(self, text): return None

    bot = FakeBot()
    p = RoleTTSPlugin(bot)
    p._ready = True
    p.cfg.update({"reply_rate": 1.0, "cooldown_seconds": 0,
                  "max_chars": 20, "daily_limit": 3, "on_at": True})
    check("超长文本不发语音", not p.should_speak(session="s1", text="很长的文本" * 10))
    check("正常短文本（概率 1.0）发语音", p.should_speak(session="s1", text="在吗"))
    p.cfg["cooldown_seconds"] = 300
    check("冷却期内不发", not p.should_speak(session="s1", text="在吗"))
    p.cfg["cooldown_seconds"] = 0
    p._day_count = {"day": time.strftime("%Y-%m-%d"), "n": 3}
    check("达每日上限不发", not p.should_speak(session="s2", text="在吗"))
    p._day_count = {"day": time.strftime("%Y-%m-%d"), "n": 0}
    p.cfg["reply_rate"] = 0.0
    check("概率 0 且未 @ 不发", not p.should_speak(session="s3", text="在吗"))
    check("@ 时必发", p.should_speak(session="s3", text="在吗", is_at=True))
    check("对方要求时必发", p.should_speak(session="s4", text="发条语音", requested=True))


def t_lifecycle():
    print("[7] 插件生命周期 + 降级")
    from role_tts import RoleTTSPlugin
    from types import SimpleNamespace

    class FakeBus:
        def on(self, t, h, p=None):
            class _S:
                def cancel(self): pass
            return _S()

    class FakeAI:
        enabled = True
        triggers = []
        personas = [{"name": "默认", "prompt": "你是「菲比」，女孩，活泼嘴碎"}]
        active_persona = "默认"
        system_prompt = ""

    class FakeCfg:
        paths = type("P", (), {"plugin_data_dir": Path(tempfile.mkdtemp())})()
        custom = {}
        ai = FakeAI()
        def save(self): pass

    class FakeBot:
        config = FakeCfg()
        bus = FakeBus()
        async def voice_segment(self, text): return "orig-segment"

    bot = FakeBot()
    p = RoleTTSPlugin(bot)
    asyncio.run(p.on_load())
    check("加载后解析角色", p._profile is not None and p._profile.name == "菲比",
          str(p._profile.name if p._profile else None))
    check("包装了 voice_segment", bot.voice_segment.__name__ == "wrapped")
    # 引擎不可用（piper 未启动场景）→ 返回 None 降级
    p.cfg["engine_config"]["piper"]["base_url"] = "http://127.0.0.1:1"
    asyncio.run(p.reload_persona())  # 让引擎用新配置重建
    await_res = asyncio.run(p.synthesize_segment("测试降级"))
    check("合成失败返回 None（可降级文字）", await_res is None)
    asyncio.run(p.on_unload())
    check("卸载还原 voice_segment", bot.voice_segment.__name__ == "voice_segment")


if __name__ == "__main__":
    t_persona()
    t_emotion()
    t_cache()
    t_audio()
    t_engine_registry()
    t_trigger()
    t_lifecycle()
    print(f"\n结果：{PASS} 通过 / {FAIL} 失败")
    sys.exit(1 if FAIL else 0)
