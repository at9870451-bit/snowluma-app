"""emotion — 智能情绪分析（规则式，毫秒级）。

从回复文本 + 上下文识别：开心/生气/害羞/撒娇/悲伤/疑惑/冷淡/中性，
输出情绪标签 + 强度（0~1），供 TTS 动态调整语速/音调/音量。
"""

from __future__ import annotations

import re
from typing import Any

from .engines.base import VoiceStyle

PATTERNS: dict[str, list[str]] = {
    "happy": ["哈哈", "笑死", "开心", "好耶", "太棒", "舒服", "爽", "乐", "😄", "😆", "嘿嘿"],
    # 注意：不用单字「气」（会被「天气/气象/客气」误判）
    "angry": ["滚", "闭嘴", "烦", "生气", "气死", "无语", "行吧", "随你", "呵", "别惹我", "服了"],
    "shy": ["害羞", "不好意思", "别说了", "讨厌", "…", "那个", "嗯…", "脸红"],
    "cute": ["嘛", "呀", "啦", "人家", "哼", "好不好", "求求", "抱抱", "嘤"],
    "sad": ["难受", "难过", "想哭", "算了", "没劲", "累", "唉", "丧"],
    "confused": ["啊？", "啥", "什么", "没懂", "？？", "怎么回事", "真的假的"],
    "cold": ["哦", "嗯", "行", "知道了", "随便", "无所谓"],
}

# 情绪 → (语速系数, 音调半音, 音量 dB)
EMOTION_TUNING: dict[str, tuple[float, float, float]] = {
    # 幅度加大：语速 ±15%、音调 ±3 半音，听感差异才明显
    "happy": (1.15, 3.0, 2.0),
    "angry": (1.10, 1.5, 3.0),
    "shy": (0.90, 2.0, -1.5),
    "cute": (1.02, 3.5, 1.0),
    "sad": (0.85, -2.5, -2.0),
    "confused": (1.05, 2.5, 0.8),
    "cold": (0.92, -3.0, -1.8),
    "neutral": (1.0, 0.0, 0.0),
}


def analyze(text: str, context: list[str] | None = None) -> tuple[str, float]:
    """返回 (情绪标签, 强度 0~1)。上下文用于在文本过短时补充判断。"""
    t = (text or "").strip()
    if not t:
        return "neutral", 0.0
    scores: dict[str, int] = {}
    for emo, words in PATTERNS.items():
        c = sum(t.count(w) for w in words)
        if c:
            scores[emo] = c
    # 文本极短（≤3 字）时参考上一条上下文情绪延续
    if len(t) <= 3 and context:
        prev_emo, _ = analyze(context[-1])
        if prev_emo != "neutral":
            scores[prev_emo] = scores.get(prev_emo, 0) + 1
    if not scores:
        return "neutral", 0.2
    emo = max(scores, key=lambda k: scores[k])
    strength = min(1.0, scores[emo] / max(2, len(t) / 8))
    # 感叹号/连续标点增强情绪
    if re.search(r"[!！]{2,}|[?？]{2,}", t):
        strength = min(1.0, strength + 0.2)
    return emo, round(strength, 2)


def apply_emotion(base: VoiceStyle, emotion: str, strength: float) -> VoiceStyle:
    """把情绪叠加到基线风格上（强度线性插值，避免夸张）。"""
    ds, dp, dv = EMOTION_TUNING.get(emotion, (1.0, 0.0, 0.0))
    s = max(0.0, min(1.0, strength))
    st = VoiceStyle(
        voice=base.voice,
        speed=max(0.7, min(1.45, base.speed * (1 + (ds - 1) * s))),
        pitch=round(base.pitch + dp * s, 1),
        volume=round(max(-8.0, min(8.0, base.volume + dv * s)), 1),
        emotion=emotion,
        emotion_strength=s,
        pause_ms=int(80 * s) if emotion in ("sad", "cold", "shy") else 0,
        extra=dict(base.extra),
    )
    return st
