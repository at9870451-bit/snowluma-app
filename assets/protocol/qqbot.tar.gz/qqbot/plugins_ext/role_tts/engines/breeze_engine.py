"""breeze — BreezeBlue 云端 TTS 引擎（Breeze TTS 2 · voice direction）。

HTTP 契约（docs.breezeblue.ai）：
  POST https://api.breeze.blue/v1/text-to-speech/{voice_id}
      ?output_format=mp3_24000_128&delivery=sync
  Header: xi-api-key: <key>
  Body: {text, model_id:"breeze-tts-2", language_code:"zh", instructions, voice_settings:{guidance_scale}}
  响应：二进制音频（audio/mpeg 等）

人味来源：把情绪/强度翻译成「表演指令」（instructions），
例：happy → "语气开心、轻快，带一点笑意"；sad → "语气低沉、有点丧，语速偏慢"。
"""

from __future__ import annotations

from typing import Any

import httpx

from .base import TTSEngine, VoiceStyle

BASE = "https://api.breeze.blue"

# 情绪 → 中文表演指令（写给模型听的「怎么念」）
EMOTION_INSTRUCTIONS = {
    "happy": "语气开心、轻快，带一点笑意",
    "angry": "语气有点冲，带着明显的不满和火气",
    "shy": "语气放轻，带点不好意思和犹豫",
    "cute": "语气撒娇、软一点，尾音甜",
    "sad": "语气低沉、有点丧，语速偏慢",
    "confused": "语气疑惑，像没太听懂",
    "cold": "语气平淡、疏离，不带情绪起伏",
    "neutral": "像日常微信语音一样自然，不要播报腔",
}


class BreezeEngine(TTSEngine):
    name = "breeze"
    supports = ("emotion", "voice", "speed", "voice_clone")

    def __init__(self, cfg: dict[str, Any]) -> None:
        super().__init__(cfg)

    def _is_singing(self, text: str) -> bool:
        return ("[唱歌]" in text) or ("[哼歌]" in text)

    def _voice_id(self, style: VoiceStyle, text: str = "") -> str:
        # 唱歌可单独指定音色（sing_voice_id），否则用主音色
        if self._is_singing(text):
            sv = str(self.cfg.get("sing_voice_id") or "").strip()
            if sv:
                return sv
        # 角色性别对应的音色（男声/女声）
        g = str((getattr(style, "extra", None) or {}).get("role_gender") or "").strip()
        if g == "male":
            mv = str(self.cfg.get("male_voice_id") or "").strip()
            if mv:
                return mv
        elif g == "female":
            fv = str(self.cfg.get("female_voice_id") or "").strip()
            if fv:
                return fv
        v = str(style.voice or "")
        if v.startswith("voc_"):
            return v
        return str(self.cfg.get("voice_id") or "").strip()

    def _instructions(self, style: VoiceStyle, text: str = "") -> str:
        if self._is_singing(text):
            sing = str(self.cfg.get("sing_instructions") or "").strip() or (
                "用流行歌演唱的方式唱出来：旋律流畅、有感情、咬字清楚，"
                "声音明亮一点，像在轻声哼唱一首喜欢的歌")
            if style.emotion and style.emotion != "neutral":
                flavor = EMOTION_INSTRUCTIONS.get(style.emotion, "")
                if flavor:
                    sing += "；" + flavor.replace("语气", "演唱语气")
            return sing
        zh_only = "全程使用普通话，不要夹杂英语、日语或其他语言。"
        adult_ins = str((style.extra or {}).get("adult_instruction") or "").strip()
        if adult_ins:
            # 只保留一句表演描述 + 一句节奏，避免指令堆叠导致发音崩坏
            tail = "语速偏慢但咬字清楚，每个字都发完整，句尾轻轻拖住"
            cfg_extra = str(self.cfg.get("instructions") or "").strip()
            bits = [adult_ins, tail]
            if cfg_extra:
                bits.append(cfg_extra)
            bits.append(zh_only)
            return "，".join(bits)
        parts = [zh_only,
                 EMOTION_INSTRUCTIONS.get(style.emotion,
                                          EMOTION_INSTRUCTIONS["neutral"])]
        if style.emotion_strength >= 0.7:
            parts.append("情绪更明显一些")
        if style.speed >= 1.06:
            parts.append("语速稍快")
        elif style.speed <= 0.98:
            parts.append("语速放慢一点，别赶")
        extra = str(self.cfg.get("instructions") or "").strip()
        if extra:
            parts.append(extra)
        return "，".join(parts)

    async def synthesize(self, text: str, style: VoiceStyle) -> tuple[bytes, str]:
        import os
        key = str(self.cfg.get("api_key") or "").strip()             or os.environ.get("BREEZE_API_KEY", "").strip()
        if not key:
            raise RuntimeError("Breeze API Key 未配置（engine_config.breeze.api_key）")
        voice_id = self._voice_id(style, text)
        if not voice_id:
            raise RuntimeError("Breeze voice_id 未配置")
        params = {
            "output_format": str(self.cfg.get("output_format")
                                 or "mp3_24000_128"),
            "delivery": "sync",
        }
        body: dict[str, Any] = {
            "text": text,
            "model_id": str(self.cfg.get("model_id") or "breeze-tts-2"),
            "language_code": str(self.cfg.get("language_code") or "zh"),
            "instructions": self._instructions(style, text),
        }
        gs = self.cfg.get("guidance_scale")
        if self._is_singing(text):
            gs = self.cfg.get("sing_guidance_scale") or gs
        adult_gs = (style.extra or {}).get("adult_guidance")
        if adult_gs:
            gs = adult_gs
        if gs:
            # 文本太短时降低 guidance，避免发音崩坏
            try:
                if len(text or "") < 12:
                    gs = min(float(gs), 5.5)
            except (TypeError, ValueError):
                pass
            body["voice_settings"] = {"guidance_scale": float(gs)}
        timeout = float(self.cfg.get("timeout") or 60)
        async with httpx.AsyncClient(timeout=timeout) as cli:
            r = await cli.post(
                f"{BASE}/v1/text-to-speech/{voice_id}",
                params=params,
                headers={"xi-api-key": key, "Content-Type": "application/json"},
                json=body)
            if r.status_code in (429, 503):
                retry = r.headers.get("retry-after", "")
                raise RuntimeError(
                    f"Breeze 限流（HTTP {r.status_code}，retry_after={retry}）")
            r.raise_for_status()
            ctype = r.headers.get("content-type", "")
            if "wav" in ctype:
                fmt = "wav"
            elif "flac" in ctype:
                fmt = "flac"
            elif "opus" in ctype:
                fmt = "opus"
            elif "aac" in ctype:
                fmt = "aac"
            elif "pcm" in ctype:
                fmt = "pcm"
            else:
                fmt = "mp3"
            if not r.content:
                raise RuntimeError("Breeze 返回空音频")
            return r.content, fmt
