"""引擎注册表：按名称构造引擎实例（可插拔）。"""

from __future__ import annotations

from typing import Any

from .base import TTSEngine, VoiceStyle
from .breeze_engine import BreezeEngine
from .custom_http import CustomHTTPEngine
from .edge_tts_engine import EdgeTTSEngine
from .openai_tts import OpenAITTSEngine
from .piper_local import PiperEngine

REGISTRY: dict[str, type[TTSEngine]] = {
    "edge": EdgeTTSEngine,
    "piper": PiperEngine,
    "openai": OpenAITTSEngine,
    "custom": CustomHTTPEngine,
    "breeze": BreezeEngine,
}


def build(name: str, cfg: dict[str, Any]) -> TTSEngine:
    cls = REGISTRY.get((name or "piper").lower())
    if cls is None:
        raise RuntimeError(f"未知 TTS 引擎：{name}（可用：{', '.join(REGISTRY)}）")
    return cls(cfg)


def available() -> list[str]:
    return list(REGISTRY)


__all__ = ["TTSEngine", "VoiceStyle", "build", "available", "REGISTRY"]
