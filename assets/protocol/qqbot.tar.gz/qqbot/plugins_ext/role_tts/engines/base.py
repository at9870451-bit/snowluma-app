"""TTS 引擎接口（可插拔）。

每个引擎实现 synthesize(text, style) → (audio_bytes, fmt)。
style 是 persona_voice 产出的声音参数（音色/语速/音调/情绪/停顿）。
新增引擎：继承 TTSEngine，实现 name / synthesize，在 engines/__init__.py 注册。
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class VoiceStyle:
    """一次合成用的声音参数（由角色卡 + 情绪共同决定）。"""

    voice: str = ""              # 引擎内的音色名
    speed: float = 1.0           # 语速倍率 0.5~2.0
    pitch: float = 0.0           # 音调偏移（半音，部分引擎支持）
    volume: float = 0.0          # 音量 dB（-10~10）
    emotion: str = "neutral"     # 情绪标签
    emotion_strength: float = 0.0  # 0~1
    pause_ms: int = 0            # 句间停顿（部分引擎支持）
    extra: dict[str, Any] = field(default_factory=dict)

    def cache_key(self) -> str:
        return (f"{self.voice}|{self.speed:.2f}|{self.pitch:.1f}|"
                f"{self.volume:.1f}|{self.emotion}|{self.emotion_strength:.1f}")


class TTSEngine:
    """引擎基类。"""

    name: str = "base"
    supports: tuple[str, ...] = ()   # 支持的能力：emotion/pitch/speed/voice_clone

    def __init__(self, cfg: dict[str, Any]) -> None:
        self.cfg = cfg or {}

    async def synthesize(self, text: str, style: VoiceStyle) -> tuple[bytes, str]:
        """返回 (音频字节, 格式如 wav/mp3/ogg)。失败抛异常，由上层降级。"""
        raise NotImplementedError

    def describe(self) -> str:
        caps = "/".join(self.supports) or "基础"
        return f"{self.name}（{caps}）"
