"""OpenAI 兼容 TTS 引擎（/v1/audio/speech），支持情绪类模型时可用 instructions 传语气。"""

from __future__ import annotations

import base64
from typing import Any

from .base import TTSEngine, VoiceStyle

EMOTION_HINT = {
    "happy": "语气轻快、带笑",
    "angry": "语气冲、带火气",
    "shy": "语气发虚、带点不好意思",
    "cute": "撒娇、软糯",
    "sad": "语气低落、有点无力",
    "confused": "疑惑、上扬疑问",
    "cold": "语气冷淡、简短",
    "neutral": "自然平实",
}


class OpenAITTSEngine(TTSEngine):
    name = "openai"
    supports = ("speed", "voice", "emotion", "instructions")

    async def synthesize(self, text: str, style: VoiceStyle) -> tuple[bytes, str]:
        base = str(self.cfg.get("base_url") or "https://api.openai.com/v1").rstrip("/")
        key = str(self.cfg.get("api_key") or "")
        model = str(self.cfg.get("model") or "tts-1")
        fmt = str(self.cfg.get("format") or "mp3").lstrip(".")
        timeout = float(self.cfg.get("timeout") or 45)
        if not key:
            raise RuntimeError("未配置 TTS API Key")
        body: dict[str, Any] = {
            "model": model,
            "input": text,
            "voice": style.voice or str(self.cfg.get("voice") or "alloy"),
            "speed": max(0.25, min(4.0, float(style.speed or 1.0))),
            "response_format": fmt,
        }
        # gpt-4o-tts 等支持自然语言语气控制
        if "instructions" in self.supports and style.emotion != "neutral":
            body["instructions"] = EMOTION_HINT.get(style.emotion, "")
        import httpx

        async with httpx.AsyncClient(timeout=timeout) as client:
            resp = await client.post(
                base + "/audio/speech",
                json=body,
                headers={"Authorization": f"Bearer {key}"},
            )
            if resp.status_code >= 400:
                raise RuntimeError(f"TTS HTTP {resp.status_code}: {resp.text[:120]}")
            data = resp.content
            ctype = resp.headers.get("content-type", "")
        if "json" in ctype:
            # 少数服务商返回 {"audio": "base64..."}
            import json

            try:
                j = json.loads(data.decode("utf-8", "ignore"))
                b64 = j.get("audio") or j.get("data") or ""
                data = base64.b64decode(b64)
            except Exception:
                pass
        if not data:
            raise RuntimeError("TTS 返回空音频")
        return data, fmt
