"""通用 HTTP 引擎：自定义 URL / 请求体模板 / 响应模式（binary|b64|json_url）。

模板占位符：${text} ${voice} ${speed} ${pitch} ${volume} ${emotion} ${format} ${api_key}
"""

from __future__ import annotations

import base64
import json
from typing import Any

from .base import TTSEngine, VoiceStyle


def _render(tpl: str, values: dict[str, Any]) -> str:
    out = tpl
    for k, v in values.items():
        out = out.replace("${" + k + "}", str(v))
    return out


class CustomHTTPEngine(TTSEngine):
    name = "custom"
    supports = ("speed", "pitch", "volume", "emotion", "voice")

    async def synthesize(self, text: str, style: VoiceStyle) -> tuple[bytes, str]:
        cfg = self.cfg
        url = str(cfg.get("url") or "").strip()
        if not url:
            raise RuntimeError("未配置自定义 TTS 地址")
        fmt = str(cfg.get("format") or "mp3").lstrip(".")
        timeout = float(cfg.get("timeout") or 45)
        values = {
            "text": text, "voice": style.voice, "speed": style.speed,
            "pitch": style.pitch, "volume": style.volume,
            "emotion": style.emotion, "format": fmt,
            "api_key": str(cfg.get("api_key") or ""),
        }
        tpl = str(cfg.get("request_template") or "")
        headers: dict[str, str] = {"Content-Type": "application/json"}
        hdr_tpl = str(cfg.get("headers") or "")
        if hdr_tpl:
            try:
                for k, v in json.loads(_render(hdr_tpl, values)).items():
                    headers[str(k)] = str(v)
            except Exception:
                pass
        elif values["api_key"]:
            headers["Authorization"] = f"Bearer {values['api_key']}"

        body: dict[str, Any] = {}
        if tpl:
            try:
                body = json.loads(_render(tpl, values))
            except Exception:
                body = {"text": text}
        else:
            body = {"text": text, "voice": style.voice, "speed": style.speed}

        import httpx

        async with httpx.AsyncClient(timeout=timeout) as client:
            resp = await client.post(url, json=body, headers=headers)
            if resp.status_code >= 400:
                raise RuntimeError(f"TTS HTTP {resp.status_code}: {resp.text[:120]}")
            data = resp.content
            ctype = resp.headers.get("content-type", "")

        mode = str(cfg.get("response_mode") or "auto")
        if mode == "json_url" or (mode == "auto" and "json" in ctype):
            try:
                j = json.loads(data.decode("utf-8", "ignore"))
            except Exception:
                j = {}
            path = str(cfg.get("response_path") or "data.url")
            cur: Any = j
            for part in path.split("."):
                cur = cur.get(part) if isinstance(cur, dict) else None
            if isinstance(cur, str) and cur.startswith("http"):
                async with httpx.AsyncClient(timeout=timeout) as client:
                    r2 = await client.get(cur)
                    data = r2.content
            elif isinstance(cur, str):
                try:
                    data = base64.b64decode(cur)
                except Exception:
                    pass
        elif mode == "b64" or (mode == "auto" and "json" in ctype):
            try:
                j = json.loads(data.decode("utf-8", "ignore"))
                b64 = j.get(str(cfg.get("response_path") or "audio")) or ""
                if b64:
                    data = base64.b64decode(b64)
            except Exception:
                pass

        if not data:
            raise RuntimeError("自定义 TTS 返回空音频")
        return data, fmt
