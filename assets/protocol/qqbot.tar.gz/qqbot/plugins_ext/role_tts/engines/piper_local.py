"""本地 piper 引擎（现有 8765 服务，零成本、离线、快）。"""

from __future__ import annotations

import asyncio
from typing import Any

from .base import TTSEngine, VoiceStyle


class PiperEngine(TTSEngine):
    name = "piper"
    supports = ("speed", "volume", "voice")

    async def synthesize(self, text: str, style: VoiceStyle) -> tuple[bytes, str]:
        base = str(self.cfg.get("base_url") or "http://127.0.0.1:8765").rstrip("/")
        timeout = float(self.cfg.get("timeout") or 30)
        voice = style.voice or str(self.cfg.get("voice") or "xiaoya")
        payload: dict[str, Any] = {
            "text": text,
            "voice": voice,
            "speed": max(0.5, min(2.0, float(style.speed or 1.0))),
            "gain": max(-10.0, min(10.0, float(style.volume or 0.0))),
        }
        import httpx

        async with httpx.AsyncClient(timeout=timeout) as client:
            resp = await client.post(base + "/tts", json=payload)
            if resp.status_code >= 400:
                raise RuntimeError(f"piper HTTP {resp.status_code}: {resp.text[:120]}")
            data = resp.content
        if not data:
            raise RuntimeError("piper 返回空音频")
        return data, "wav"
