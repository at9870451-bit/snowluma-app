"""edge-tts 引擎（情感风格版）：微软 Edge 免费 TTS + SSML 情感表达。

在 edge-tts 基础参数上，通过 Monkey-patch mkssml 注入 mstts:express-as
情感样式（cheerful/angry/sad/affectionate…）——让「开心真的带笑、伤心真的带哭腔」。

支持的情感 → 样式映射（仅对支持 express-as 的音色生效，如 Xiaoxiao/Xiaoyi）：
  happy→cheerful  angry→angry  shy→gentle  cute→affectionate
  sad→sad  cold→disgruntled  confused/neutral→（不注入）

mp3：edge-tts 原生输出 mp3（audio-24khz-48kbitrate-mono-mp3），无需额外转码。
"""

from __future__ import annotations

from .base import TTSEngine, VoiceStyle

VOICE_HINTS = {
    "lively": "zh-CN-XiaoyiNeural",
    "warm": "zh-CN-XiaoxiaoNeural",
    "cute": "zh-CN-YunxiaNeural",
    "humorous": "zh-CN-liaoning-XiaobeiNeural",
    "bright": "zh-CN-shaanxi-XiaoniNeural",
    "male_lively": "zh-CN-YunxiNeural",
    "male_steady": "zh-CN-YunyangNeural",
}

# 情绪 → express-as 情感样式
EMOTION_STYLE = {
    "happy": "cheerful",
    "angry": "angry",
    "shy": "gentle",
    "cute": "affectionate",
    "sad": "sad",
    "cold": "disgruntled",
    "confused": "",
    # 普通对话也给「聊天」语气（Xiaoxiao 支持 chat），避免默认播音腔
    "neutral": "chat",
}

# 支持 express-as 的音色白名单（不支持的音色注入样式会被忽略）
STYLE_SAFE_VOICES = {
    "zh-CN-XiaoxiaoNeural", "zh-CN-XiaoyiNeural", "zh-CN-YunxiNeural",
    "zh-CN-YunyangNeural", "zh-CN-YunjianNeural", "zh-CN-YunxiaNeural",
}

# 全局 style 承载（Monkey-patch 用）
_STYLE_HOLDER: dict[str, str] = {"style": ""}


def _install_style_patch() -> None:
    """给 edge_tts.communicate.mkssml 打补丁，注入 express-as。幂等。"""
    try:
        from edge_tts import communicate as _ec
    except Exception:
        return
    if getattr(_ec, "_style_patched", False):
        return
    orig = _ec.mkssml

    def _mkssml_with_style(tc, text):
        if isinstance(text, bytes):
            text = text.decode("utf-8")
        base = orig(tc, text) if callable(orig) else text
        style = _STYLE_HOLDER.get("style") or ""
        voice = getattr(tc, "voice", "") or ""
        if style and voice in STYLE_SAFE_VOICES and "express-as" not in base:
            base = base.replace(
                "<speak version='1.0' xmlns='http://www.w3.org/2001/10/synthesis' "
                "xml:lang='en-US'>",
                "<speak version='1.0' xmlns='http://www.w3.org/2001/10/synthesis' "
                "xmlns:mstts='https://www.w3.org/2001/mstts' xml:lang='zh-CN'>")
            base = base.replace(
                f"<prosody pitch='{tc.pitch}' rate='{tc.rate}' volume='{tc.volume}'>",
                f"<prosody pitch='{tc.pitch}' rate='{tc.rate}' volume='{tc.volume}'>"
                f"<mstts:express-as style='{style}'>")
            base = base.replace("</prosody>", "</mstts:express-as></prosody>")
        return base

    _ec.mkssml = _mkssml_with_style
    _ec._style_patched = True


class EdgeTTSEngine(TTSEngine):
    name = "edge"
    supports = ("speed", "pitch", "volume", "voice", "emotion_style", "mp3")

    async def synthesize(self, text: str, style: VoiceStyle) -> tuple[bytes, str]:
        import edge_tts

        _install_style_patch()
        # 当前情绪 → 情感样式
        _STYLE_HOLDER["style"] = EMOTION_STYLE.get(style.emotion, "")

        voice = style.voice or str(self.cfg.get("voice") or VOICE_HINTS["lively"])
        rate_pct = int(round((float(style.speed or 1.0) - 1.0) * 100))
        rate_pct = max(-40, min(50, rate_pct))
        pitch_hz = int(round(float(style.pitch or 0.0) * 8))
        pitch_hz = max(-50, min(50, pitch_hz))
        vol_pct = int(round(float(style.volume or 0.0) * 6))
        vol_pct = max(-40, min(40, vol_pct))

        if style.pause_ms >= 120:
            text = text.replace("，", "，，").replace("。", "。。")

        audio = bytearray()
        c = edge_tts.Communicate(
            text, voice,
            rate=f"{rate_pct:+d}%",
            pitch=f"{pitch_hz:+d}Hz",
            volume=f"{vol_pct:+d}%",
        )
        async for chunk in c.stream():
            if chunk.get("type") == "audio":
                audio.extend(chunk.get("data") or b"")
        if not audio:
            raise RuntimeError("edge-tts 返回空音频")
        # edge 原生输出 mp3（24k 48kbps mono）
        return bytes(audio), "mp3"