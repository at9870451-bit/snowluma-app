"""audio — 统一音频格式：任意输入 → ogg/opus（QQ 友好、体积小）。

QQBot 发送 record 段要求容器内可读 → 统一转 base64://。
优先 opus（体积 1/15），转码失败退回原始格式（仍可发送）。
"""

from __future__ import annotations

import asyncio
import shutil
import subprocess
import tempfile
from pathlib import Path


def has_ffmpeg() -> bool:
    return shutil.which("ffmpeg") is not None


def _to_ogg_sync(data: bytes, src_fmt: str, bitrate: str = "16k") -> bytes:
    if not has_ffmpeg():
        raise RuntimeError("未安装 ffmpeg，无法转码")
    with tempfile.TemporaryDirectory() as td:
        src = Path(td) / f"in.{src_fmt or 'wav'}"
        dst = Path(td) / "out.ogg"
        src.write_bytes(data)
        subprocess.run(
            ["ffmpeg", "-y", "-loglevel", "error", "-i", str(src),
             "-c:a", "libopus", "-b:a", bitrate, "-application", "voip",
             "-ar", "24000", "-ac", "1", str(dst)],
            check=True, timeout=20, capture_output=True)
        return dst.read_bytes()


async def normalize(data: bytes, fmt: str, *, target: str = "ogg",
                    bitrate: str = "16k") -> tuple[bytes, str]:
    """统一格式：默认转 ogg/opus。失败时原样返回（调用方仍可发送）。"""
    fmt = (fmt or "wav").lower().lstrip(".")
    if target == "ogg" and fmt in ("ogg", "opus"):
        return data, "ogg"
    try:
        out = await asyncio.to_thread(_to_ogg_sync, data, fmt, bitrate)
        if out:
            return out, "ogg"
    except Exception:
        pass
    return data, fmt
