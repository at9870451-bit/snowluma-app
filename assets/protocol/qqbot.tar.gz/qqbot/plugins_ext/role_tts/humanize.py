"""humanize — 文本润色：让 TTS 念出来更像活人说话。

TTS 的「机器感」有一半来自文本本身：书面标点、没有语气词、句尾没有起伏。
本模块在合成前按情绪给文本加：
  - 语气词（嗯/啊/诶/唔/哈哈）
  - 停顿标点（…、，）
  - 句尾语气助词（呀/啦/嘛/呢/哦）
  - 拉长音（好~ 对~）
只做轻量、可控的改动，不改变语义。
"""

from __future__ import annotations

import random
import re

# 情绪 → (句首语气词, 句尾助词, 拉长音概率)
EMOTION_FILLERS = {
    "happy": (["哈哈哈 ", "嘿 ", "哇 "], ["呀", "啦", "嘿嘿"], 0.35),
    "angry": (["啧 ", "行吧 ", "呵 "], ["", "行吧"], 0.1),
    "shy": (["嗯… ", "那个… "], ["…", "啦"], 0.3),
    "cute": (["诶嘿 ", "唔 "], ["嘛", "呀", "啦"], 0.45),
    "sad": (["唉… ", "唔… "], ["…", "吧"], 0.25),
    "confused": (["啊？ ", "诶？ "], ["？", "吧"], 0.2),
    "cold": (["哦 ", "嗯 "], ["", "吧"], 0.05),
    "neutral": ([], ["", ""], 0.1),
}


def humanize(text: str, emotion: str = "neutral", strength: float = 0.5,
             *, seed: int | None = None) -> str:
    """按情绪润色文本（幂等：已含语气词则跳过）。"""
    t = (text or "").strip()
    if not t:
        return t
    rng = random.Random(seed)
    head_pool, tail_pool, stretch_p = EMOTION_FILLERS.get(
        emotion, EMOTION_FILLERS["neutral"])
    s = max(0.0, min(1.0, strength))

    # 1) 句首语气词（强度够才加，避免每句都「哈哈哈」）
    if head_pool and s >= 0.35 and rng.random() < 0.55:
        filler = rng.choice(head_pool)
        if not t.startswith(tuple(w.strip() for w in head_pool)):
            t = filler + t

    # 2) 句尾助词（原本没语气词才加）
    if tail_pool and s >= 0.3 and rng.random() < 0.5:
        last = t[-1]
        if last not in "。！？…~～呢呀啦嘛哦吧啊":
            tail = rng.choice(tail_pool)
            if tail:
                t = t.rstrip("。.") + tail

    # 3) 拉长音（好→好~），只对句尾单字
    if rng.random() < stretch_p * s:
        t = re.sub(r"([好行对是嗯哦啊])([。！!]?)$", r"\1~\2", t)

    # 4) 感叹号弱化（TTS 念感叹号会硬）
    t = t.replace("！！", "！").replace("!!", "!")
    return t


def split_sentences(text: str) -> list[str]:
    """按标点切句（供分段合成，制造自然停顿）。"""
    parts = re.split(r"(?<=[。！？!?…])", text or "")
    return [p.strip() for p in parts if p.strip()]


def jitter_params(base_speed: float, base_pitch: float, *,
                  seed: int | None = None) -> tuple[float, float]:
    """给语速/音调加随机微抖动（±3%），让同一句话每次也不完全一样。"""
    import random
    rng = random.Random(seed)
    ds = rng.uniform(-0.03, 0.03)
    dp = rng.uniform(-1.5, 1.5)
    return (max(0.7, min(1.4, base_speed + ds)),
            max(-4.0, min(4.0, base_pitch + dp)))


def add_pause_marks(text: str, emotion: str = "neutral") -> str:
    """在长句的逗号后加停顿感（省略号模拟呼吸）。"""
    if len(text) < 20:
        return text
    if emotion in ("sad", "cold", "shy"):
        return re.sub(r"(?<![，。！？…])，(?![，。！？…])", "，…", text, count=1)
    return text
