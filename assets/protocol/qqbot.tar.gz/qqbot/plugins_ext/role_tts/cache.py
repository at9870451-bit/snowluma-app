"""cache — 语音缓存（LRU，磁盘 + 内存双层）。

key = engine|voice|speed|pitch|volume|emotion|strength|text
同一句话同一角色同一参数 → 直接复用，零合成开销。
"""

from __future__ import annotations

import hashlib
import json
import threading
import time
from collections import OrderedDict
from pathlib import Path


class VoiceCache:
    def __init__(self, cache_dir: Path, *, max_items: int = 200,
                 max_mem_items: int = 32, ttl_days: int = 7) -> None:
        self.dir = Path(cache_dir)
        self.dir.mkdir(parents=True, exist_ok=True)
        self.index_file = self.dir / "index.json"
        self.max_items = max(20, max_items)
        self.max_mem = max(8, max_mem_items)
        self.ttl = max(1, ttl_days) * 86400
        self._mem: OrderedDict[str, bytes] = OrderedDict()
        self._lock = threading.Lock()

    # ---------- key ----------

    @staticmethod
    def make_key(engine: str, style_key: str, text: str) -> str:
        raw = f"{engine}|{style_key}|{text}".encode("utf-8")
        return hashlib.sha1(raw).hexdigest()[:20]

    # ---------- 读 ----------

    def get(self, key: str) -> bytes | None:
        with self._lock:
            if key in self._mem:
                self._mem.move_to_end(key)
                return self._mem[key]
        f = self.dir / f"{key}.ogg"
        if not f.is_file():
            f = self.dir / f"{key}.bin"
            if not f.is_file():
                return None
        try:
            data = f.read_bytes()
        except OSError:
            return None
        with self._lock:
            self._mem[key] = data
            if len(self._mem) > self.max_mem:
                self._mem.popitem(last=False)
        return data

    # ---------- 写 ----------

    def put(self, key: str, data: bytes, fmt: str = "ogg") -> None:
        ext = "ogg" if (fmt or "").lower() in ("ogg", "opus") else "bin"
        f = self.dir / f"{key}.{ext}"
        try:
            f.write_bytes(data)
        except OSError:
            return
        with self._lock:
            self._mem[key] = data
            if len(self._mem) > self.max_mem:
                self._mem.popitem(last=False)
        self._touch_index(key)

    def _touch_index(self, key: str) -> None:
        try:
            idx: dict[str, float] = {}
            if self.index_file.is_file():
                idx = json.loads(self.index_file.read_text("utf-8") or "{}")
            idx[key] = time.time()
            # 超限/过期清理
            now = time.time()
            alive = {k: t for k, t in idx.items() if now - t < self.ttl}
            if len(alive) > self.max_items:
                keep = sorted(alive.items(), key=lambda kv: -kv[1])[: self.max_items]
                alive = dict(keep)
            for k in list(idx):
                if k not in alive:
                    for ext in ("ogg", "bin"):
                        try:
                            (self.dir / f"{k}.{ext}").unlink()
                        except OSError:
                            pass
            self.index_file.write_text(json.dumps(alive), encoding="utf-8")
        except Exception:
            pass

    # ---------- 维护 ----------

    def stats(self) -> dict[str, int]:
        files = list(self.dir.glob("*.ogg")) + list(self.dir.glob("*.bin"))
        total = sum(f.stat().st_size for f in files if f.is_file())
        return {"files": len(files), "bytes": total,
                "mem": len(self._mem), "max": self.max_items}

    def clear(self) -> int:
        n = 0
        for f in list(self.dir.glob("*.ogg")) + list(self.dir.glob("*.bin")):
            try:
                f.unlink()
                n += 1
            except OSError:
                pass
        with self._lock:
            self._mem.clear()
        try:
            self.index_file.write_text("{}", encoding="utf-8")
        except OSError:
            pass
        return n
