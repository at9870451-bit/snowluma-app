"""QQBot RoleTTS — 角色卡驱动的 TTS 语音合成插件 v1.0.0

模块化：角色卡解析 → 声音风格 → 情绪分析 → TTS 引擎 → 音频统一 → 缓存 → QQ 发送。

与 QQBot 集成（不重写核心）：
  - on_load 时注册 `bot.role_tts` 服务对象，内置插件/其他插件可直接调用
  - 包装 `bot.voice_segment`：启用后接管语音合成（角色音色 + 情绪 + 缓存）
  - 支持三种发送模式：voice（纯语音）/ both（文字+语音）/ text（纯文字）
  - 触发条件：概率、被 @、关键词、对方要求语音

管理员指令：
  /role_tts 状态 | 重载 | 试听 <文本> | 清缓存
  /role_tts 引擎 piper|openai|custom
  /role_tts 模式 voice|both|text
  /role_tts 概率 <0-100>
"""

from __future__ import annotations

import asyncio
import base64
import json
import random
import re
import time
from pathlib import Path
from typing import Any

from qqbot.plugins.base import Plugin

from . import audio, emotion as emo_mod, humanize as hz, persona_voice
from .tts_text_polish import polish_for_tts, shrink_for_voice
from .cache import VoiceCache
from .engines import build as build_engine
from .engines.base import VoiceStyle

DEFAULT_CONFIG = {
    "enabled": True,
    # 引擎：piper（本地，免费）/ openai（云端）/ custom（自定义 HTTP）
    "engine": "piper",
    "engine_config": {
        "edge": {"voice": "zh-CN-XiaoyiNeural", "timeout": 40},
        "piper": {"base_url": "http://127.0.0.1:8765", "voice": "xiaoya", "timeout": 30},
        "openai": {"base_url": "https://api.openai.com/v1", "api_key": "",
                   "model": "tts-1", "voice": "nova", "format": "mp3", "timeout": 45},
        "custom": {"url": "", "api_key": "", "request_template": "",
                   "response_mode": "auto", "format": "mp3", "timeout": 45},
    },
    # 发送模式：voice=纯语音 / both=文字+语音 / text=纯文字
    "send_mode": "voice",
    # 触发：概率 / 被@ / 关键词 / 对方要求
    "reply_rate": 0.3,
    "on_at": True,
    "on_request": True,        # 对方说「语音」「说话」「发语音」
    "keywords": ["语音", "说句话", "发条语音"],
    # 限制
    "max_chars": 30,
    "cooldown_seconds": 20,    # 同会话两条语音最小间隔
    "daily_limit": 200,        # 每日语音上限
    # 角色 → 声音覆盖（留空则从角色卡自动推断）
    "roles": {},
    # 缓存
    "cache_max": 200,
    "cache_ttl_days": 7,
    # 音频
    "audio_bitrate": "16k",
    # 情绪
    "emotion_enabled": True,
    "emotion_strength_scale": 1.0,
    "voicepack_enabled": True,
    "voicepack_rate": 0.3,
    "auto_learn_enabled": True,
    "auto_learn_interval_hours": 6,
    "auto_learn_sources": "https://www.v2ex.com/?tab=hot,https://www.v2ex.com/go/create",
    "voicepack_only": False,
    # 文本润色（语气词/停顿/句尾助词），显著提升活人感
    "humanize_enabled": True,
}

CONFIG_LABELS = {
    "enabled": "启用角色语音",
    "engine": "TTS 引擎（piper/openai/custom）",
    "send_mode": "发送模式（voice/both/text）",
    "reply_rate": "语音概率（0~1）",
    "on_at": "被 @ 时必发语音",
    "max_chars": "最长文本（超出转文字）",
    "cooldown_seconds": "同会话语音冷却（秒）",
    "daily_limit": "每日语音上限",
    "emotion_enabled": "按情绪调整语气",
}


class RoleTTSPlugin(Plugin):
    name = "role_tts"
    display_name = "角色卡语音合成"
    version = "1.0.0"
    description = "角色卡驱动 TTS：人设决定音色/语速，情绪决定语气，带缓存与降级"
    priority = 88  # 晚于聊天插件，只负责语音能力

    default_config = DEFAULT_CONFIG
    config_labels = CONFIG_LABELS

    def __init__(self, bot) -> None:
        super().__init__(bot)
        self.cache = VoiceCache(self.data_dir / "cache",
                                max_items=int(self.cfg_get("cache_max", 200)),
                                ttl_days=int(self.cfg_get("cache_ttl_days", 7)))
        self._profile: persona_voice.PersonaProfile | None = None
        self._engine = None
        self._last_at: dict[str, float] = {}
        self._day_count = {"day": "", "n": 0}
        self._adult_voice_at: dict[str, float] = {}
        self._orig_voice_segment = None
        self._ready = False

    # ---------- 生命周期 ----------

    async def on_load(self) -> None:
        if not self.cfg_get("enabled", True):
            self.log.info("角色语音未启用")
            return
        self._learn_task = None
        try:
            await self.reload_persona()
            self._wrap_voice_segment()
            self._bind_voice_decide()
            if self.cfg_get("auto_learn_enabled", True):
                self._learn_task = asyncio.get_running_loop().create_task(
                    self._auto_learn_loop())
            self._ready = True
            self.add_command("role_tts", self._cmd, aliases=("rt",),
                             admin=True, description="角色语音：状态/重载/试听/清缓存")
            self.log.info("角色语音已启用：%s", persona_voice.describe(self._profile))
            self.log.info("引擎：%s，模式：%s，概率：%s",
                          self.cfg_get("engine"), self.cfg_get("send_mode"),
                          self.cfg_get("reply_rate"))
        except Exception as exc:  # noqa: BLE001
            self.log.error("角色语音初始化失败（不影响文字聊天）: %s", exc)

    async def on_unload(self) -> None:
        if getattr(self, "_learn_task", None):
            self._learn_task.cancel()
        self._unwrap_voice_segment()
        self._unbind_voice_decide()

    def _wrap_voice_segment(self) -> None:
        if self._orig_voice_segment is not None:
            return
        self._orig_voice_segment = self.bot.voice_segment

        async def wrapped(text: str):
            if not self._ready:
                return await self._orig_voice_segment(text)
            seg = await self.synthesize_segment(text)
            if seg is not None:
                return seg
            return await self._orig_voice_segment(text)

        self.bot.voice_segment = wrapped

    def _unwrap_voice_segment(self) -> None:
        if self._orig_voice_segment is not None:
            try:
                self.bot.voice_segment = self._orig_voice_segment
            except Exception:
                pass
            self._orig_voice_segment = None

    # ---------- 角色卡 → 声音 ----------

    async def reload_persona(self) -> None:
        """重新解析当前激活角色卡，重建引擎。"""
        ai_cfg = self.bot.config.ai
        card = ""
        try:
            name = str(getattr(ai_cfg, "active_persona", "") or "")
            for p in getattr(ai_cfg, "personas", []) or []:
                if name and p.get("name") == name:
                    card = str(p.get("prompt") or "")
                    break
            if not card:
                card = str(getattr(ai_cfg, "system_prompt", "") or "")
        except Exception:
            pass
        role_cfg = dict((self.cfg_get("roles") or {}).get(self._role_name(card)) or {})
        engine_name = str(self.cfg_get("engine", "piper"))
        self._profile = persona_voice.parse_persona(
            card, role_cfg=role_cfg, engine=engine_name)
        # 全局覆盖（前端「音色」面板设置，优先于角色卡推断）
        st = self._profile.style
        if self.cfg_get("voice_speed") is not None:
            st.speed = max(0.7, min(1.4, float(self.cfg_get("voice_speed") or 1.0)))
        if self.cfg_get("voice_pitch") is not None:
            st.pitch = float(self.cfg_get("voice_pitch") or 0.0)
        if self.cfg_get("voice_volume") is not None:
            st.volume = float(self.cfg_get("voice_volume") or 0.0)
        eng_voice = str(((self.cfg_get("engine_config") or {}).get(engine_name) or {}).get("voice") or "")
        if eng_voice:
            st.voice = eng_voice
        # 上传 MP3 的音色模仿：pitch/音量/音色向上传音频特征对齐
        try:
            vp_path = Path("/opt/qqbot/data/voicepacks/profile.json")
            if vp_path.is_file() and self.cfg_get("use_voicepack_pitch", True):
                prof = json.loads(vp_path.read_text("utf-8") or "{}")
                if prof.get("pitch_hz"):
                    po = float(prof.get("pitch_offset") or 0)
                    if po:
                        st.pitch = round(max(-4.0, min(4.0, st.pitch + po)), 1)
                    vo = float(prof.get("volume_offset") or 0)
                    if vo:
                        st.volume = round(max(-6.0, min(6.0, st.volume + vo)), 1)
                    sv = str(prof.get("suggest_voice") or "")
                    # 模仿模式：建议音色优先（engine_config 里的静态音色让位）
                    if sv:
                        st.voice = sv
                    self._mimicking = True
        except Exception:
            pass
        eng_cfg = dict((self.cfg_get("engine_config") or {}).get(engine_name) or {})
        self._engine = build_engine(engine_name, eng_cfg)

    @staticmethod
    def _role_name(card: str) -> str:
        m = re.search(r"你是[「\"']([^」\"']{1,12})[」\"']", card or "")
        return m.group(1) if m else ""

    # ---------- 合成 ----------

    def _style_for(self, text: str, context: list[str] | None = None) -> VoiceStyle:
        base = (self._profile.style if self._profile else VoiceStyle())
        if not self.cfg_get("emotion_enabled", True):
            return base
        emo, strength = emo_mod.analyze(text, context)
        scale = float(self.cfg_get("emotion_strength_scale", 1.0) or 1.0)
        return emo_mod.apply_emotion(base, emo, min(1.0, strength * scale))

    async def synthesize_bytes(self, text: str, *,
                               context: list[str] | None = None
                               ) -> tuple[bytes, str, VoiceStyle] | None:
        """合成音频（带缓存）。失败返回 None（调用方降级文字）。"""
        text = (text or "").strip()
        if not text or self._engine is None:
            return None
        style = self._style_for(text, context)
        style = self._adult_style(style, text)
        try:
            _g = str(getattr(self.bot, "role_gender", "") or "")
            if _g in ("male", "female"):
                style.extra = dict(style.extra or {})
                style.extra["role_gender"] = _g
        except Exception:  # noqa: BLE001
            pass
        # 文本润色：加语气词/停顿/句尾助词，让念出来更像活人
        # （唱歌除外：歌词不能被塞进「哈哈哈/呀/…」这类口头禅）
        singing = ("[唱歌]" in text) or ("[哼歌]" in text)
        _adult_lv = int((getattr(style, "extra", None) or {}).get("adult_level") or 0)
        if (self.cfg_get("humanize_enabled", True) and not singing
                and _adult_lv < 2):
            # 用原文 hash 作 seed：同一句话润色结果稳定，缓存才有效
            seed = abs(hash(text)) % (2 ** 31)
            text = hz.humanize(text, style.emotion, style.emotion_strength, seed=seed)
            js, jp = hz.jitter_params(style.speed, style.pitch, seed=seed)
            style.speed = js
            style.pitch = jp
            if style.pause_ms >= 100:
                text = hz.add_pause_marks(text, style.emotion)
        engine_name = str(self.cfg_get("engine", "piper"))
        key = VoiceCache.make_key(engine_name, style.cache_key(), text)
        hit = self.cache.get(key)
        if hit:
            return hit, "ogg", style
        try:
            data, fmt = await asyncio.wait_for(
                self._engine.synthesize(text, style), timeout=60)
        except Exception as exc:  # noqa: BLE001
            self.log.warning("TTS 合成失败（降级文字）: %s", exc)
            return None
        data, fmt = await audio.normalize(
            data, fmt, target="ogg", bitrate=str(self.cfg_get("audio_bitrate", "16k")))
        if not data:
            return None
        self.cache.put(key, data, fmt)
        return data, fmt, style

    # ---------- TTS 文本清洗 ----------

    _RE_EMOJI = re.compile(
        "[\U0001F000-\U0001FAFF\u2600-\u27BF\u2B00-\u2BFF\uFE0F]+")
    _RE_STAGE = re.compile(
        r"【[^】]{0,120}】|（[^）]{0,120}）|\([^)]{0,120}\)|\*[^*]{0,120}\*"
        r"|\[[^\]]{0,120}\]|〔[^〕]{0,60}〕")
    _RE_CODE = re.compile(r"〔[^〕]{1,5}〕?")

    _STAGE_WORDS_TTS = ("小声嘟囔", "心里想", "心想", "暗自", "默默",
                        "忍不住", "往你那边", "往你这边", "了一下",
                        "地看向", "地望", "地笑", "抬起眼", "低下头",
                        "转过头", "别过脸", "红了脸", "喘了一下", "轻笑",
                        "挑眉", "勾唇", "叹了口气", "低声道", "开口",
                        "说着", "顺势", "俯身", "倾身", "侧头", "歪头",
                        "眨了眨眼", "视线", "目光", "眼神", "想着",
                        "垂下眼", "抬眸", "噘嘴", "撇嘴", "揉捏", "揉着",
                        "娇喘", "喘息", "轻轻", "捏着", "抚过", "抚摸",
                        "含住", "抵着", "舔舐", "吸吮", "吻着", "摩挲",
                        "颤了", "抖了", "喘了一声", "嗯了一声", "呻吟",
                        "低吟", "呢喃", "埋进", "蹭了蹭")
    _STAGE_HEAD_TTS = ("我伸手", "我抬手", "我低头", "我抬头", "我转身",
                       "我靠近", "我贴", "我蹭", "我揉", "我捏", "我摸",
                       "我抱", "我吻", "我舔", "我咬", "我坐", "我站",
                       "我躺", "我趴", "我蜷", "我缩", "我挪", "我抓",
                       "我攥", "我掐", "我推", "我拉", "我凑", "我靠",
                       "我起身", "我开口", "我低声", "我轻咳", "我愣了一下",
                       "我笑了", "我收回", "我别过", "我叹了口气", "我哼了一声",
                       "揉捏轻轻", "轻轻揉", "伸手揉", "指尖揉", "手指抚",
                       "唇瓣含住", "舌头舔", "手掌贴", "她揉", "她捏")

    def _strip_action_sent(self, text: str) -> str:
        """整句删掉动作/心理旁白，只留说出口的话。"""
        if not text:
            return text
        # 全文提取引号里的台词（避免按问号切句把引号切断）
        import re as _re0
        _inner = []
        for _q, _e in (("「", "」"), ("“", "”"), (chr(34), chr(34))):
            _inner += _re0.findall(_re0.escape(_q) + "(.*?)" + _re0.escape(_e), text)
        _inner = [x.strip() for x in _inner if x.strip()]
        if _inner:
            return "，".join(_inner)
        # 没有引号：按句删掉动作/心理旁白
        parts = re.split(r"(?<=[。！？!?\n])", text)
        kept = []
        for part in parts:
            seg = part.strip()
            if not seg:
                continue
            if seg.startswith(self._STAGE_HEAD_TTS):
                continue
            if any(w in seg for w in self._STAGE_WORDS_TTS):
                continue
            kept.append(seg)
        return "".join(kept).strip()

    @staticmethod
    def _fix_person(text: str) -> str:
        """对话里「他/她」→「你」，保护「他们/她们」。"""
        t = text or ""
        t = t.replace("他们", "\u0001").replace("她们", "\u0002")
        t = t.replace("他", "你").replace("她", "你")
        t = t.replace("\u0001", "他们").replace("\u0002", "她们")
        return t

    def _tts_sanitize(self, text: str) -> str:
        """剥掉不该念出来的：旁白、emoji、代号、标签。"""
        t = text or ""
        if "[唱歌]" in t or "[哼歌]" in t:
            return t
        t = self._RE_STAGE.sub("，", t)
        t = self._RE_EMOJI.sub("", t)
        t = self._RE_CODE.sub("", t)
        t = t.replace("～", "").replace("~", "")
        t = re.sub(r"\s+", " ", t)
        t = re.sub(r"[，]{2,}", "，", t).strip("，, ")
        t = self._strip_action_sent(t)
        t = self._fix_person(t)
        return t

    async def synthesize_segment(self, text: str, *, context: list[str] | None = None):
        """返回 record 消息段（base64://，容器可直接发送）。"""
        text = self._tts_sanitize((text or "").strip())
        if not text:
            return None
        # 唱歌文本不受长度限制（[唱歌]/[哼歌] 标签走 Breeze 演唱）
        singing = ("[唱歌]" in text) or ("[哼歌]" in text)
        if not singing and len(text) > int(self.cfg_get("max_chars", 200)):
            self.log.debug("文本超长（%d 字），转文字", len(text))
            return None
        # 语音包直发已停用（上传音频用于 TTS 模仿而非直发）；保留概率直发可配
        vp_only = False
        vp_seg = await self._maybe_voicepack(force=vp_only)
        if vp_seg is not None:
            return vp_seg
        result = await self.synthesize_bytes(text, context=context)
        if not result:
            return None
        data, _fmt, style = result
        from qqbot.core.message import record as record_seg

        self.log.info("语音已合成：%s（%s，%d 字节）",
                      style.emotion, style.voice, len(data))
        return record_seg("base64://" + base64.b64encode(data).decode())

    async def _auto_learn_loop(self) -> None:
        hours = max(1, int(self.cfg_get("auto_learn_interval_hours", 6)))
        first = True
        while True:
            try:
                await asyncio.sleep(60 if first else hours * 3600)
                first = False
                srcs = [u.strip() for u in str(
                    self.cfg_get("auto_learn_sources", "") or "").split(",") if u.strip()]
                total_added = 0
                for url in srcs[:4]:
                    try:
                        def _do(u=url):
                            import subprocess as _sp
                            r = _sp.run(
                                ["python3", "/opt/ai_gateway/web_learn.py", u, "30"],
                                capture_output=True, text=True, timeout=90)
                            return json.loads(r.stdout.strip() or "{}")
                        res = await asyncio.to_thread(_do)
                        total_added += int(res.get("added") or 0)
                    except Exception as exc:
                        self.log.debug("auto learn fail %s: %s", url[:40], exc)
                self.log.info("auto learn done: +%s", total_added)
            except asyncio.CancelledError:
                raise
            except Exception as exc:
                self.log.warning("auto learn error: %s", exc)
                await asyncio.sleep(300)

    async def _maybe_voicepack(self, force: bool = False):
        """随机发一个上传的语音包（真声录音）；force=True 时跳过概率必发。"""
        if not self.cfg_get("voicepack_enabled", True):
            return None
        if not force:
            rate = float(self.cfg_get("voicepack_rate", 0.3) or 0)
            if rate <= 0 or random.random() >= rate:
                return None
        try:
            vp_dir = Path("/opt/qqbot/data/voicepacks")
            files = sorted(vp_dir.glob("vp_*.ogg")) or sorted(vp_dir.glob("vp_*.mp3"))
            if not files:
                return None
            pick = random.choice(files)
            from qqbot.core.message import record as record_seg

            self.log.info("发送语音包：%s", pick.name)
            return record_seg("base64://" + base64.b64encode(pick.read_bytes()).decode())
        except Exception as exc:  # noqa: BLE001
            self.log.debug("语音包发送失败: %s", exc)
            return None

    # ---------- 成人语音（极彩） ----------

    def _bind_voice_decide(self) -> None:
        try:
            self.bot.voice_decide = self.voice_decide
        except Exception:
            pass

    def _unbind_voice_decide(self) -> None:
        try:
            if getattr(self.bot, "voice_decide", None) is self.voice_decide:
                delattr(self.bot, "voice_decide")
        except Exception:
            pass

    def _adult_hint(self) -> dict:
        h = getattr(self.bot, "adult_voice_hint", None)
        if not isinstance(h, dict) or not h.get("level"):
            return {}
        if time.time() - float(h.get("ts") or 0) > 150:
            return {}
        return h

    def _adult_min_level(self) -> int:
        try:
            return max(1, min(5, int(self.cfg_get("adult_voice_min_level", 2))))
        except (TypeError, ValueError):
            return 2

    def voice_decide(self, ctx, text: str) -> bool:
        """成人语境的语音判定：按概率发语音（默认 90%），抽不中的走文字。

        另加每会话最小间隔（adult_voice_min_interval 秒），防连环语音。
        """
        if not self.cfg_get("adult_voice_force", True):
            return False
        h = self._adult_hint()
        if not h or int(h.get("level") or 0) < self._adult_min_level():
            return False
        hud = h.get("uid")
        cur = None
        try:
            cur = getattr(getattr(ctx, "event", ctx), "user_id", None)
            gid = getattr(getattr(ctx, "event", ctx), "group_id", None)
        except Exception:
            cur = None
            gid = None
        if hud and cur and str(hud) != str(cur):
            return False
        # 会话间隔：刚发过语音就先文字
        try:
            gap = max(0, int(self.cfg_get("adult_voice_min_interval", 45) or 0))
        except (TypeError, ValueError):
            gap = 45
        key = "g%s" % gid if gid else "u%s" % cur
        if gap and time.time() - self._adult_voice_at.get(key, 0.0) < gap:
            return False
        # 概率：adult_voice_rate（默认 0.9 = 九成语音一成文字）
        try:
            rate = float(self.cfg_get("adult_voice_rate", 0.9) or 0.9)
        except (TypeError, ValueError):
            rate = 0.9
        if rate < 1.0 and random.random() > rate:
            self._adult_voice_at[key] = time.time() - gap + 5.0  # 文字后很快可再发
            return False
        # 60 秒内刚发过兜底句 → 本条走文字（语音不念兜底，避免循环感）
        if time.time() - float(getattr(self.bot, "adult_fallback_at", 0) or 0) < 60:
            return False
        self._adult_voice_at[key] = time.time()
        return True

    def _adult_style(self, style, text: str):
        h = self._adult_hint()
        if not h or int(h.get("level") or 0) < self._adult_min_level():
            return style
        extra = dict(getattr(style, "extra", None) or {})
        extra["adult_instruction"] = str(h.get("instruction") or "")
        try:
            _lv = int(h.get("level") or 3)
        except (TypeError, ValueError):
            _lv = 3
        _table = self.cfg_get("adult_guidance_by_level") or {}
        _gl = None
        if isinstance(_table, dict):
            _gl = _table.get(str(_lv)) or _table.get(_lv)
        extra["adult_guidance"] = float(_gl or h.get("guidance") or 5.5)
        extra["adult_level"] = int(h.get("level") or 0)
        try:
            style.extra = extra
        except Exception:
            return style
        if str(getattr(style, "emotion", "") or "") in ("", "neutral"):
            style.emotion = "cute"
            style.emotion_strength = max(0.7, float(style.emotion_strength or 0))
            style.pause_ms = 120
            style.speed = min(1.02, max(0.90, float(style.speed or 1.0) * 0.95))
        return style

    # ---------- 触发判定 ----------

    def should_speak(self, *, session: str, text: str,
                     is_at: bool = False, requested: bool = False) -> bool:
        if not self.cfg_get("enabled", True) or not self._ready:
            return False
        if not text.strip() or len(text) > int(self.cfg_get("max_chars", 60)):
            return False
        # 每日上限
        today = time.strftime("%Y-%m-%d")
        if self._day_count["day"] != today:
            self._day_count = {"day": today, "n": 0}
        if self._day_count["n"] >= int(self.cfg_get("daily_limit", 200)):
            return False
        # 冷却
        now = time.time()
        cd = max(0, int(self.cfg_get("cooldown_seconds", 20)))
        if now - self._last_at.get(session, 0) < cd:
            return False
        # 必发条件
        if requested and self.cfg_get("on_request", True):
            self._mark(session)
            return True
        if is_at and self.cfg_get("on_at", True):
            self._mark(session)
            return True
        kws = [str(k) for k in (self.cfg_get("keywords") or []) if str(k)]
        if kws and any(k in text for k in kws):
            self._mark(session)
            return True
        # 概率
        rate = float(self.cfg_get("reply_rate", 0.3) or 0)
        if rate > 0 and random.random() < rate:
            self._mark(session)
            return True
        return False

    def _mark(self, session: str) -> None:
        self._last_at[session] = time.time()
        self._day_count["n"] = self._day_count.get("n", 0) + 1

    # ---------- 管理指令 ----------

    async def _cmd(self, ctx, args: str) -> Any:
        a = (args or "").strip()
        head, _, rest = a.partition(" ")
        head = head.lower()

        if head in ("", "状态", "status"):
            st = self.cache.stats()
            lines = [
                "【角色语音】",
                persona_voice.describe(self._profile) if self._profile else "角色卡未解析",
                f"引擎：{self.cfg_get('engine')} · 模式：{self.cfg_get('send_mode')} · "
                f"概率：{self.cfg_get('reply_rate')}",
                f"今日已发：{self._day_count.get('n', 0)}/{self.cfg_get('daily_limit')} · "
                f"冷却 {self.cfg_get('cooldown_seconds')}s",
                f"缓存：{st['files']} 条 / {st['bytes'] // 1024}KB（上限 {st['max']}）",
            ]
            await ctx.reply("\n".join(lines))
            return self.stop()

        if head == "重载":
            await self.reload_persona()
            await ctx.reply("已按当前角色卡重载：\n" +
                            (persona_voice.describe(self._profile) if self._profile else "解析失败"))
            return self.stop()

        if head == "试听":
            text = rest or "你好呀，我是你的角色语音"
            seg = await self.synthesize_segment(text)
            if seg is None:
                await ctx.reply("合成失败（已降级文字）。看日志确认引擎配置。")
                return self.stop()
            from qqbot.core.message import Message

            await ctx.send(Message([seg]))
            return self.stop()

        if head == "清缓存":
            n = self.cache.clear()
            await ctx.reply(f"已清空语音缓存（{n} 个文件）。")
            return self.stop()

        if head == "引擎" and rest:
            name = rest.strip().lower()
            if name not in ("piper", "openai", "custom"):
                await ctx.reply("引擎只能是 piper / openai / custom")
                return self.stop()
            self.cfg["engine"] = name
            self.save_config()
            await self.reload_persona()
            await ctx.reply(f"引擎已切到 {name}。")
            return self.stop()

        if head == "模式" and rest:
            mode = rest.strip().lower()
            if mode not in ("voice", "both", "text"):
                await ctx.reply("模式只能是 voice / both / text")
                return self.stop()
            self.cfg["send_mode"] = mode
            self.save_config()
            await ctx.reply(f"发送模式已设为 {mode}。")
            return self.stop()

        if head == "概率" and rest:
            try:
                v = max(0.0, min(1.0, float(rest)))
            except ValueError:
                await ctx.reply("用法：/role_tts 概率 0.3")
                return self.stop()
            self.cfg["reply_rate"] = v
            self.save_config()
            await ctx.reply(f"语音概率已设为 {v:.0%}。")
            return self.stop()

        await ctx.reply("用法：/role_tts 状态｜重载｜试听 <文本>｜清缓存｜"
                        "引擎 piper|openai|custom｜模式 voice|both|text｜概率 0.3")
        return self.stop()
