"""表情包自动收藏插件：AI 看到群里/私聊的表情包就存进自己的表情库。

功能
  1. 自动收藏：消息里的图片（表情包）自动下载入库（md5 命名天然去重）
  2. 库容量控制：超过上限自动删最旧的收藏
  3. 发送：配合内置表情包技能（config.sticker），AI 回复时输出 [表情:标签]
     即从「自己账号的收藏」里随机挑一张发送——只发自己库里有的，绝不外找

收藏标签：默认「收藏」；若 vision 模型可用，后续可扩展自动打情绪标签。
数据位置：data/stickers/（与内置表情包技能共用一个库 = AI 的账号收藏）
"""

from __future__ import annotations

import asyncio
import base64
import hashlib
import json
import time
from typing import Any

from qqbot.plugins.base import Plugin

ALLOWED_EXT = {".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp"}


def _guess_ext(data: bytes, url: str) -> str:
    if data[:8] == b"\x89PNG\r\n\x1a\n":
        return ".png"
    if data[:3] == b"GIF":
        return ".gif"
    if data[:4] == b"RIFF" and data[8:12] == b"WEBP":
        return ".webp"
    if data[:2] == b"\xff\xd8":
        return ".jpg"
    u = (url or "").split("?")[0].lower()
    for ext in ALLOWED_EXT:
        if u.endswith(ext):
            return ext
    return ".jpg"


def _pick_url(seg) -> str:
    """从 image 段提取可下载的地址 / base64 数据。"""
    data = getattr(seg, "data", None) or {}
    url = str(data.get("url") or "")
    if url.startswith("http"):
        return url
    f = str(data.get("file") or "")
    if f.startswith("base64://"):
        return f
    if f.startswith("http"):
        return f
    return ""


class StickerCollectPlugin(Plugin):
    name = "sticker_collect"
    display_name = "表情包自动收藏"
    version = "1.0.0"
    description = "自动收藏群里/私聊看到的表情包到 AI 自己的账号库，回复时只发自己收藏的"
    priority = 95  # 最后处理，纯收藏不干扰其它插件

    default_config = {
        "enabled": True,
        "tag": "收藏",            # 自动收藏的标签
        "max_keep": 200,          # 收藏上限（超过删最旧）
        "min_bytes": 2000,        # 小于该值视为占位图，不收
        "max_bytes": 6 * 1024 * 1024,
        "allow_groups": [],       # 只在这些群收藏（空=所有群）
        "collect_self": False,    # 是否收藏自己（机器人）发出的图
    }

    config_labels = {
        "enabled": "启用表情包自动收藏",
        "tag": "收藏标签",
        "max_keep": "收藏上限（张）",
        "allow_groups": "限定群号（空=全部）",
    }

    def __init__(self, bot) -> None:
        super().__init__(bot)
        self._busy = set()  # 正在下载的 url 去重
        # 已收藏内容的 md5 集合（StickerStore 用 uuid 存储，无法按名去重，这里自己记）
        self._md5_file = self.data_dir / "collected_md5.json"
        try:
            self._md5s: set[str] = set(json.loads(self._md5_file.read_text("utf-8")))
        except (OSError, ValueError):
            self._md5s = set()

    async def on_load(self) -> None:
        if not self.cfg_get("enabled", True):
            return
        # 确保内置「表情包技能」开启（AI 回复才可能带 [表情:xx]）
        st = self.bot.config.sticker
        if not st.enabled:
            st.enabled = True
            self.bot.config.save()
            self.log.info("已自动开启内置表情包技能（config.sticker.enabled=true）")
        self.log.info("表情包自动收藏已启用（当前收藏 %d 张）", len(self.bot.stickers.list()))

    async def on_message(self, ctx) -> Any:
        if not self.cfg_get("enabled", True):
            return None
        # 只收藏自己的图则跳过自己
        if not self.cfg_get("collect_self", False) and self.bot.self_id \
                and int(ctx.user_id or 0) == int(self.bot.self_id):
            return None
        allow = [int(g) for g in (self.cfg_get("allow_groups") or []) if str(g).isdigit()]
        if allow and ctx.group_id and int(ctx.group_id) not in allow:
            return None

        for seg in ctx.message:
            if getattr(seg, "type", "") != "image":
                continue
            src = _pick_url(seg)
            if not src:
                continue
            if src in self._busy:
                continue
            self._busy.add(src)
            asyncio.get_running_loop().create_task(self._collect(src))
        return None

    async def _collect(self, src: str) -> None:
        try:
            await asyncio.wait_for(self._download_and_save(src), timeout=20)
        except Exception as exc:  # noqa: BLE001
            self.log.debug("收藏失败（跳过）: %s", str(exc)[:80])
        finally:
            self._busy.discard(src)

    async def _download_and_save(self, src: str) -> None:
        if src.startswith("base64://"):
            raw = base64.b64decode(src[len("base64://"):])
        else:
            import httpx

            async with httpx.AsyncClient(timeout=15, follow_redirects=True) as client:
                resp = await client.get(src)
                resp.raise_for_status()
                raw = resp.content

        min_b = int(self.cfg_get("min_bytes", 2000))
        max_b = int(self.cfg_get("max_bytes", 6 * 1024 * 1024))
        if len(raw) < min_b or len(raw) > max_b:
            return

        ext = _guess_ext(raw, src)
        # 长宽比检测：只收藏接近正方形的表情包（0.68~1.47），长条截图不收
        try:
            from PIL import Image
            import io as _io
            with Image.open(_io.BytesIO(raw)) as _im:
                _w, _h = _im.size
            if _h == 0 or (_w / _h) < 0.68 or (_w / _h) > 1.47:
                return
        except Exception:
            pass
        # 不收藏疑似真人照片：大体积 jpg（表情包多为 gif/png/压缩图）
        if ext in (".jpg", ".jpeg") and len(raw) > 1500 * 1024:
            return
        digest = hashlib.md5(raw).hexdigest()
        if digest in self._md5s:
            return
        name = "c" + digest[:12] + ext
        tag = str(self.cfg_get("tag", "收藏"))

        def _save() -> None:
            lib = self.bot.stickers
            lib.add(name, raw, [tag])
            self._md5s.add(digest)
            self._md5_file.write_text(
                json.dumps(list(self._md5s)), encoding="utf-8")
            self._prune()

        await asyncio.to_thread(_save)
        self.log.info("已收藏表情包 %s（库内 %d 张）",
                      name, len(self.bot.stickers.list()))

    def _prune(self) -> None:
        """超出上限时删最旧的收藏。"""
        max_keep = max(20, int(self.cfg_get("max_keep", 200)))
        items = self.bot.stickers.list()
        if len(items) <= max_keep:
            return
        # list 按添加顺序返回（见 StickerLib._load），最旧的在前面
        for item in items[: len(items) - max_keep]:
            try:
                self.bot.stickers.delete(item.get("id"))
            except Exception:  # noqa: BLE001
                pass
