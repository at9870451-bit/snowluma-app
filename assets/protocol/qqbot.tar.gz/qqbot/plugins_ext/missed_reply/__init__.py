"""漏回补偿插件（missed_reply）。

监听所有私聊消息；如果对方发了消息、机器人因为忙/异常没回，
在 12~600 秒内检测到就自动补一条自然回复。

只处理非管理员私聊（管理员的漏回由 master_pursuit 用剧情推进补）。
补回内容走普通聊天语气，不涉及成人内容。
"""

from __future__ import annotations

import asyncio
import time
from typing import Any

from qqbot.core.message import Message, text as text_seg
from qqbot.plugins.base import Plugin


class MissedReplyPlugin(Plugin):
    name = "missed_reply"
    display_name = "漏回补偿"
    version = "1.0.0"
    description = "私聊消息没被回复时，自动补一条自然回应"
    priority = 93

    default_config = {
        "enabled": True,
        "check_seconds": 45,       # 多久扫一次
        "min_delay": 12,           # 至少等多久才补（给对方/机器人留缓冲）
        "max_delay": 600,          # 超过这个时间就不补了
        "max_chars": 60,
    }

    config_labels = {
        "enabled": "启用漏回补偿",
        "check_seconds": "检查间隔（秒）",
        "min_delay": "最少等待（秒）",
        "max_delay": "超过多久不再补（秒）",
        "max_chars": "补回字数上限",
    }

    def __init__(self, bot) -> None:
        super().__init__(bot)
        self._task: asyncio.Task | None = None
        self._state: dict[str, Any] = {}

    # ---------------- 生命周期 ----------------

    async def on_load(self) -> None:
        self._load()
        self.subscribe("message", self._track)
        if self.cfg_get("enabled", True):
            try:
                self._orig_send = self.bot.send_private_msg

                async def _wrapped(uid, message):
                    try:
                        self._st(int(uid))["last_sent_at"] = time.time()
                        self._save()
                    except Exception:  # noqa: BLE001
                        pass
                    return await self._orig_send(uid, message)

                self.bot.send_private_msg = _wrapped
            except Exception:  # noqa: BLE001
                pass
            self._spawn()
            self.log.info("漏回补偿已启用（检查 %ss，窗口 %ss~%ss）",
                          self.cfg_get("check_seconds"),
                          self.cfg_get("min_delay"),
                          self.cfg_get("max_delay"))

    async def on_unload(self) -> None:
        if self._task:
            self._task.cancel()

    def _spawn(self) -> None:
        async def _run() -> None:
            while True:
                try:
                    await asyncio.sleep(max(15, int(self.cfg_get("check_seconds", 45) or 45)))
                    await self._tick()
                except asyncio.CancelledError:
                    raise
                except Exception as exc:  # noqa: BLE001
                    self.log.warning("漏回检查异常: %s", exc)
                    await asyncio.sleep(20)

        self._task = asyncio.create_task(_run())

    # ---------------- 状态 ----------------

    def _path(self):
        return self.data_dir / "pending.json"

    def _load(self) -> None:
        try:
            import json
            self._state = json.loads(self._path().read_text("utf-8"))
        except Exception:  # noqa: BLE001
            self._state = {}

    def _save(self) -> None:
        try:
            import json
            self._path().write_text(json.dumps(self._state, ensure_ascii=False), "utf-8")
        except Exception:  # noqa: BLE001
            pass

    def _st(self, uid: int) -> dict:
        return self._state.setdefault("users", {}).setdefault(str(uid), {})

    # ---------------- 跟踪 ----------------

    def _admins(self) -> set[int]:
        try:
            return {int(a) for a in (self.bot.config.bot.admins or [])}
        except Exception:  # noqa: BLE001
            return set()

    async def _track(self, event) -> None:
        try:
            if getattr(event, "is_group", False):
                return
            uid = int(getattr(event, "user_id", 0) or 0)
            if not uid or uid in self._admins():
                return  # 管理员的漏回由 master_pursuit 负责
            if self.bot.self_id and uid == int(self.bot.self_id):
                return
            text = ""
            for seg in getattr(getattr(event, "message", None), "segments", []) or []:
                if getattr(seg, "type", "") == "text":
                    text += getattr(seg, "data", {}).get("text", "")
            text = text.strip()
            if not text:
                return
            st = self._st(uid)
            st["last_msg"] = text[:120]
            st["last_msg_at"] = time.time()
            self._save()
        except Exception:  # noqa: BLE001
            pass

    # ---------------- 补回 ----------------

    def _client(self):
        af = getattr(self.bot, "adult_forge", None)
        orig = getattr(af, "_orig_chat_client", None) if af is not None else None
        if orig is not None:
            return orig
        return self.bot.chat_client()

    async def _tick(self) -> None:
        if not self.cfg_get("enabled", True):
            return
        now = time.time()
        lo = float(self.cfg_get("min_delay", 12) or 12)
        hi = float(self.cfg_get("max_delay", 600) or 600)
        for k, st in list((self._state.get("users") or {}).items()):
            try:
                uid = int(k)
                ma = float(st.get("last_msg_at") or 0)
                sa = float(st.get("last_sent_at") or 0)
                if not (ma > sa):
                    continue
                gap = now - ma
                if gap < lo or gap > hi:
                    continue
                if await self._make_up(uid, str(st.get("last_msg") or "")):
                    st["last_sent_at"] = time.time()
                    self._save()
            except Exception:  # noqa: BLE001
                continue

    async def _make_up(self, uid: int, said: str) -> bool:
        try:
            client = self._client()
            session = f"private_{uid}"
            memory = ""
            summary = ""
            try:
                memory = await self.bot.memory_context(0, uid)
                summary = await self.bot.summary_context(session)
            except Exception:  # noqa: BLE001
                pass
            prompt = (
                "（刚才对方发了消息，你因为手头有别的事没来得及回。现在补一句，"
                "像刚忙完回来看到消息那样自然，1 到 2 句，别解释你在忙什么，别说抱歉，"
                "直接接着他刚才说的话往下聊。）\n"
                f"对方刚才说：{said}"
            )
            answer = ""
            for _ in range(2):
                try:
                    answer = (await client.chat(session, prompt, memory=memory,
                                                summary=summary) or "").strip()
                except Exception as exc:  # noqa: BLE001
                    self.log.debug("补回生成失败: %s", exc)
                    answer = ""
                if answer and "（模型没有返回内容）" not in answer and len(answer) >= 4:
                    break
                answer = ""
                await asyncio.sleep(1.5)
            if not answer:
                return False
            cap = max(8, int(self.cfg_get("max_chars", 60)))
            if len(answer) > cap:
                answer = answer[:cap]
            await self.bot.send_private_msg(uid, Message([text_seg(answer)]))
            self.log.info("漏回补回 -> %s: %s", uid, answer[:40])
            return True
        except Exception as exc:  # noqa: BLE001
            self.log.warning("补回失败: %s", exc)
            return False
