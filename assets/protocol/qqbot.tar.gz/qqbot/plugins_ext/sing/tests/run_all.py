"""sing 插件测试（歌名解析/歌词清洗/触发/频控/降级）。"""
from __future__ import annotations

import asyncio
import sys
import tempfile
from pathlib import Path
from types import SimpleNamespace

try:
    from qqbot.core.bus import STOP  # noqa: F401
    from qqbot.core.message import Message, text as text_seg  # noqa: F401
except ImportError:
    import types as _t
    _qqbot = _t.ModuleType("qqbot")
    _core = _t.ModuleType("qqbot.core")
    _bus = _t.ModuleType("qqbot.core.bus")
    _bus.STOP = "STOP"
    _msg = _t.ModuleType("qqbot.core.message")

    class _Msg:
        def __init__(self, segs):
            self.segs = segs

        def __str__(self):
            return "|".join(str(s) for s in self.segs)

    _msg.Message = _Msg
    _msg.text = lambda t: t
    _plugins = _t.ModuleType("qqbot.plugins")
    _base = _t.ModuleType("qqbot.plugins.base")

    class _Plugin:
        priority = 50

        def __init__(self, bot=None):
            import logging
            self.bot = bot
            self.cfg = dict(getattr(self, "default_config", {}) or {})
            self._cmds = {}
            self.log = logging.getLogger("stub")

        @property
        def data_dir(self):
            return Path(tempfile.mkdtemp())

        def cfg_get(self, key, default=None):
            return self.cfg.get(key, default)

        def add_command(self, name, handler, **kw):
            self._cmds[name] = (handler, kw)

        @staticmethod
        def stop():
            return _bus.STOP

    _base.Plugin = _Plugin
    _qqbot.core = _core
    _core.bus = _bus
    _core.message = _msg
    _qqbot.plugins = _plugins
    _plugins.base = _base
    for _n, _m in {"qqbot": _qqbot, "qqbot.core": _core, "qqbot.core.bus": _bus,
                   "qqbot.core.message": _msg, "qqbot.plugins": _plugins,
                   "qqbot.plugins.base": _base}.items():
        sys.modules[_n] = _m
    from qqbot.core.bus import STOP  # noqa: F401
    from qqbot.core.message import Message, text as text_seg  # noqa: F401

_PKG = Path(__file__).resolve().parent.parent
for _p in ("/opt/qqbot/plugins_ext", "/opt/qqbot", str(_PKG.parent)):
    if _p not in sys.path:
        sys.path.insert(0, _p)

try:
    import sing  # noqa: F401
except ImportError:
    import sing_dev as sing  # noqa: F401
    sys.modules.setdefault("sing", sing)

PASS = FAIL = 0


def check(name, cond, detail=""):
    global PASS, FAIL
    if cond:
        PASS += 1
        print(f"  ✓ {name}")
    else:
        FAIL += 1
        print(f"  ✗ {name} {detail}")


def _make(cfg_extra=None):
    from sing import SingPlugin

    class FakeChat:
        async def chat(self, session, prompt, context, **kw):
            return "这是现编的歌词一句，再来一句凑数，第三句押个韵，最后收尾。"

    class FakeCfg:
        class bot:  # noqa: N801
            admins = [3227868908]

    class FakeBot:
        config = FakeCfg()
        voice = []
        msgs = []

        async def voice_segment(self, text):
            FakeBot.voice.append(text)
            return Message([text_seg(f"[语音]{text}")])

        async def send_group_msg(self, gid, message, *a, **k):
            FakeBot.msgs.append(("g", gid, str(message)))
            return {}

        async def send_private_msg(self, uid, message, *a, **k):
            FakeBot.msgs.append(("p", uid, str(message)))
            return {}

        chat_client = lambda self: FakeChat()  # noqa: E731

    bot = FakeBot()
    p = SingPlugin(bot)
    p.cfg.update(cfg_extra or {})
    return bot, p


def _ctx(uid=5, text="", gid=111):
    ev = SimpleNamespace(user_id=uid, group_id=gid, text=text,
                         sender={"card": "u", "nickname": "u"},
                         message_id=1, message=[], raw_message=text)
    c = SimpleNamespace(event=ev, user_id=uid, group_id=gid, text=text,
                        is_group=gid is not None, is_admin=False, replies=[])

    async def _reply(msg, **kw):
        c.replies.append(msg)

    c.reply = _reply
    return c


def t_parse():
    print("[1] 歌名解析")
    bot, p = _make()
    cases = {
        "唱《稻香》": "稻香",
        "唱首稻香": "稻香",
        "来一首周杰伦的稻香": "周杰伦的稻香",
        "给我唱首歌": "",
        "唱首歌": "",
        "今天天气不错": None,
        "唱两句": "",
    }
    ok = True
    for text, want in cases.items():
        got = p._parse_song(text)
        if got != want:
            ok = False
            print(f"    {text!r} → {got!r}（期望 {want!r}）")
    check("解析全部正确", ok)


def t_clean():
    print("[2] 歌词清洗")
    bot, p = _make()
    raw = """[00:00.00] 作词：方文山
[00:01.00] 作曲：周杰伦
[00:02.00]
[00:03.00] 在这个世界如果你有太多的抱怨
[00:06.00] 跌倒了就不敢继续往前走
[00:09.00] 为什么人要这么的脆弱堕落
"""
    out = p._clean_lyrics(raw)
    check("去时间戳与制作信息", out.startswith("在这个世界"), out[:30])
    check("有内容", len(out) > 10)


def t_trigger():
    print("[3] 触发与频控")
    bot, p = _make()
    # 打桩歌词源：命中返回自定义歌词
    async def fake_fetch(title):
        return ("在这个世界如果你有太多的抱怨，跌倒了就不敢继续往前走", "稻香（周杰伦）")
    p._fetch_lyrics = fake_fetch
    r = asyncio.run(p.on_message(_ctx(5, "唱首《稻香》")))
    check("触发返回 STOP", r is STOP)
    check("发出语音", bot.voice and "[唱歌]" in bot.voice[0], str(bot.voice[:1]))
    check("歌词来自歌曲", "抱怨" in bot.voice[0])
    # 冷却内第二次被拦
    r2 = asyncio.run(p.on_message(_ctx(6, "唱首稻香")))
    check("同群冷却拦截", r2 is None)
    # 无关消息不触发
    r3 = asyncio.run(p.on_message(_ctx(7, "今天吃啥")))
    check("无关消息放行", r3 is None)
    # 管理员（主人）关键词也能触发
    p3 = _make({"group_cooldown_seconds": 0})[1]

    async def fake3(title):
        return ("管理员测试歌词", title)
    p3._fetch_lyrics = fake3
    ctxa = _ctx(3227868908, "唱《两三句》")
    ctxa.is_admin = True
    ra = asyncio.run(p3.on_message(ctxa))
    check("管理员关键词触发", ra is STOP and p3.bot.voice, str(ra))
    # 每日上限
    p2 = _make({"group_cooldown_seconds": 0, "daily_limit_per_group": 2})[1]

    async def fake2(title):
        return ("测试歌词一二三四", "测试")
    p2._fetch_lyrics = fake2
    asyncio.run(p2.on_message(_ctx(5, "唱首歌", gid=222)))
    asyncio.run(p2.on_message(_ctx(5, "唱首歌", gid=222)))
    r4 = asyncio.run(p2.on_message(_ctx(5, "唱首歌", gid=222)))
    check("每日上限拦截", r4 is None)


def t_fallback():
    print("[4] 无歌词源 → LLM 现编")
    bot, p = _make()

    async def no_fetch(title):
        return "", ""
    p._fetch_lyrics = no_fetch
    r = asyncio.run(p.on_message(_ctx(5, "唱首不存在的歌")))
    check("LLM 兜底触发", r is STOP and bot.voice and "现编" in bot.voice[0],
          str(bot.voice[:1]))


def t_cmd():
    print("[5] /sing 指令")
    bot, p = _make()

    async def fake_fetch(title):
        return ("指令测试歌词一句", title)
    p._fetch_lyrics = fake_fetch

    class C:
        def __init__(self):
            self.replies = []

        async def reply(self, msg):
            self.replies.append(msg)

    asyncio.run(p._cmd(C(), "稻香"))
    check("指令唱出", bot.voice and "[唱歌]" in bot.voice[0])


if __name__ == "__main__":
    t_parse()
    t_clean()
    t_trigger()
    t_fallback()
    t_cmd()
    print(f"\n结果：{PASS} 通过 / {FAIL} 失败")
    sys.exit(1 if FAIL else 0)
