"""QQBot Sing 唱歌插件 v1.1.0

发歌名，菲比唱出来（Breeze TTS 2 的 [唱歌]/[哼歌] 标签）：

  触发（群聊/私聊）：
    「唱《稻香》」「唱首稻香」「来一首周杰伦的稻香」「唱首歌」
  管理员：
    /sing 稻香

歌词来源链：
  1. LRCLIB 开放歌词库（免鉴权，中文流行歌覆盖好）
  2. 找不到 → LLM 按歌名现编四句（原创，不冒充原曲）

防刷：同群 10 分钟一次、每群每日 6 次；TTS 失败降级文字歌词。
"""

from __future__ import annotations

import asyncio
import re
import time
from typing import Any

import httpx

from qqbot.core.bus import STOP
from qqbot.plugins.base import Plugin

_TRIGGER_RE = re.compile(r"(唱|来)一?首?个?(首歌|歌)")
_SING_ANY_RE = re.compile(r"(唱首歌|唱个歌|来首歌|唱两句|唱一个|唱唱)")
# 《稻香》/「稻香」/"稻香" 或 唱(首/个/一首)(周杰伦的)稻香
_QUOTED_RE = re.compile(r"[《「\"“]([^》」\"”]{1,20})[》」\"”]")
# 严格模式：必须带量词（唱/来 + 首|个），否则普通句子会被误判成点歌
_NAME_RE = re.compile(
    r"(?:唱|来)(?:一?首|一?个|首歌|个歌)"
    r"(?:关于)?\s*([^\s，,。！？；;、~～《》「」\"”]{1,20})")
# 宽松模式（旧行为，strict_trigger=false 时启用）
_NAME_RE_LOOSE = re.compile(
    r"(?:唱|来)(?:一?首|一?个|首歌|个歌)?"
    r"(?:一首|一个)?(?:关于)?\s*([^\s，,。！？《》「」\"”]{1,20})")
# 明显不是歌名的碎片（口语助词/短虚词）
_BAD_NAMES = {"了", "呀", "的", "吗", "呢", "吧", "哦", "嗯", "啊", "嘛", "咯",
              "啦", "哈", "过", "没", "我", "你", "他", "她", "它", "这", "那",
              "就是", "然后", "所以", "但是", "而且", "因为", "如果", "可以",
              "好的", "点歌", "给我听", "起来"}
_BAD_TAIL = ("了", "呀", "吗", "呢", "吧", "哦", "嗯", "啊", "嘛", "咯", "啦")
_ARTIST_SPLIT = re.compile(r"^(.{1,12})的(.{1,20})$")
_CREDIT_RE = re.compile(r"^(作词|作曲|编曲|制作|演唱|混音|原唱|词|曲)[:：]")
_LRC_TAG = re.compile(r"\[[^\]]*\]")


class SingPlugin(Plugin):
    name = "sing"
    display_name = "唱歌"
    version = "1.1.0"
    description = "发歌名就唱：LRCLIB 取歌词 + Breeze [唱歌] 标签，真人感演唱"
    priority = 19

    default_config = {
        "enabled": True,
        "group_cooldown_seconds": 600,
        "daily_limit_per_group": 6,
        "max_lyric_chars": 90,
        "sing_tag": "[唱歌]",
        "hum_tag": "[哼歌]",
        "sing_prelude": True,   # 先轻声念一遍第一句再开唱（emo 歌更对味）
        "prelude_tag": "[耳语]",
        "lyrics_api": "https://lrclib.net/api/search",
        "lyrics_timeout": 15,
        "llm_timeout": 20,        # LLM 现编歌词的超时（秒）
        "strict_trigger": True,   # 量词必填，防普通句子被当成点歌
    }

    config_labels = {
        "enabled": "启用唱歌",
        "group_cooldown_seconds": "同群冷却（秒）",
        "daily_limit_per_group": "每群每日次数",
        "max_lyric_chars": "每次唱多少字",
        "strict_trigger": "严格触发（必须「唱/来+首/个」才算点歌）",
        "llm_timeout": "现编歌词超时（秒）",
    }

    def __init__(self, bot) -> None:
        super().__init__(bot)
        self._last_by_group: dict[str, float] = {}
        self._day_count: dict[tuple[str, str], int] = {}
        self._last_fallback: dict[str, str] = {}
        self._fallback_turn: dict[str, int] = {}

    async def on_load(self) -> None:
        if not self.cfg_get("enabled", True):
            return
        self.add_command("sing", self._cmd, aliases=("唱歌", "点歌"),
                         admin=True, description="唱歌：/sing <歌名或主题>")
        self.log.info("唱歌插件已启用（歌词源 LRCLIB，冷却 %ss）",
                      self.cfg_get("group_cooldown_seconds", 600))

    # ---------------- 消息入口 ----------------

    async def on_message(self, ctx) -> Any:
        if not self.cfg_get("enabled", True):
            return None
        m = self._norm(ctx)
        text = m["text"]
        if not text:
            return None
        # 管理员也可以关键词点歌（/sing 指令走指令通道，不冲突）
        song = self._parse_song(text)
        if song is None and not _SING_ANY_RE.search(text):
            return None
        if song and not self._plausible_song(song):
            # 像聊天不像点歌 → 不抢话，交给普通 AI 聊天
            return None
        gid = str(m["group_id"]) if m["is_group"] else f"u{m['user_id']}"
        if not self._rate_ok(gid):
            return None
        await self._sing(ctx, m, song or "")
        return STOP

    # ---------------- 歌名解析 ----------------

    def _parse_song(self, text: str) -> str | None:
        m_dg = re.match(r"^\s*点歌\s+(.+)$", text or "")
        if m_dg:
            name = m_dg.group(1).strip()
            return name if self._plausible_song(name) else None
        q = _QUOTED_RE.search(text)
        if q and re.search(r"唱|来", text):
            name = q.group(1).strip()
            return name if self._plausible_song(name) else None
        rx = _NAME_RE if self.cfg_get("strict_trigger", True) else _NAME_RE_LOOSE
        m = rx.search(text)
        if not m:
            return None
        name = m.group(1).strip()
        if name in ("歌", "首歌", "个", "首", "一个", "一首", "两句", "两句歌",
                    "一遍", "一下", "一曲", "起来", "给我听", "点歌"):
            return ""
        if name and not self._plausible_song(name):
            return None
        return name or None

    def _plausible_song(self, name: str) -> bool:
        """歌名可信度：短虚词、句子碎片一律不算点歌（放给普通聊天）。"""
        n = (name or "").strip()
        if len(n) < 2 or len(n) > 20:
            return False
        if n in _BAD_NAMES:
            return False
        if re.search(r"[，,。.！!？?；;：:、~～]", n):
            return False
        if len(n) <= 3 and n.endswith(_BAD_TAIL):
            return False
        return True

    # ---------------- 歌词 ----------------

    async def _fetch_lyrics(self, title: str) -> tuple[str, str]:
        """返回 (歌词文本, 显示名)；失败返回 ("", "")。"""
        if not title:
            return "", ""
        artist = ""
        track = title
        mm = _ARTIST_SPLIT.match(title)
        if mm:
            artist, track = mm.group(1), mm.group(2)
        try:
            url = str(self.cfg_get("lyrics_api",
                                   "https://lrclib.net/api/search"))
            params: dict[str, Any] = {"track_name": track}
            if artist:
                params["artist_name"] = artist
            async with httpx.AsyncClient(
                    timeout=float(self.cfg_get("lyrics_timeout", 15)),
                    follow_redirects=True,
                    headers={"User-Agent": "SnowLuma-QQBot/1.0"}) as cli:
                r = await cli.get(url, params=params)
                items = r.json() if r.status_code == 200 else []
            if not items and artist:
                # 带歌手没搜到 → 只用歌名再搜
                async with httpx.AsyncClient(
                        timeout=float(self.cfg_get("lyrics_timeout", 15)),
                        follow_redirects=True,
                        headers={"User-Agent": "SnowLuma-QQBot/1.0"}) as cli:
                    r = await cli.get(url, params={"track_name": track})
                    items = r.json() if r.status_code == 200 else []
            if not isinstance(items, list):
                items = []
            best = None
            for it in items:
                if it.get("plainLyrics"):
                    best = it
                    break
            if best is None and items:
                best = items[0]
            if best:
                raw = best.get("plainLyrics") or ""
                if raw:
                    name = f"{best.get('trackName') or track}"
                    if best.get("artistName"):
                        name += f"（{best['artistName']}）"
                    return self._clean_lyrics(raw), name
        except Exception as exc:  # noqa: BLE001
            self.log.debug("歌词搜索失败: %s", exc)
        return "", ""

    def _clean_lyrics(self, raw: str) -> str:
        lines: list[str] = []
        for line in raw.splitlines():
            t = _LRC_TAG.sub("", line).strip()
            if not t or _CREDIT_RE.match(t):
                continue
            lines.append(t)
            if sum(len(x) for x in lines) >= int(
                    self.cfg_get("max_lyric_chars", 90)):
                break
        return "，".join(lines)

    async def _llm_lyrics(self, title: str) -> str:
        """LLM 现编四句（超时可调；异常打类型名，别只打一个冒号）。"""
        client = self.bot.chat_client()
        prompt = ("写四句中文歌词，简单上口、押韵，像随口哼的小调，"
                  + (f"主题：{title}。" if title else "主题随意，生活化一点。")
                  + "只输出四句歌词，用逗号或句号分隔，不要歌名、不要解释。")
        budget = float(self.cfg_get("llm_timeout", 20) or 20)
        for attempt in (1, 2):
            try:
                out = (await asyncio.wait_for(
                    client.chat("sing", prompt, ""),
                    timeout=budget)) or ""
                out = re.sub(r"\s*\n+\s*", "，", out.strip()).strip("《》「」\"'")
                if out:
                    return out[:int(self.cfg_get("max_lyric_chars", 90))]
            except Exception as exc:  # noqa: BLE001
                self.log.warning("歌词生成失败(%s/%s): %s: %s",
                                 attempt, type(exc).__name__, type(exc).__name__, exc)
                if attempt == 1:
                    await asyncio.sleep(1.5)
        return ""

    # ---------------- 兜底歌词（池化 + 同群不重复） ----------------

    FALLBACK_POOL = (
        "今晚夜色软，风把心事吹散，我先哼两句，你别嫌我跑调。",
        "街灯亮了两排，脚步慢下来，想到你就笑，这事说不太明白。",
        "窗外雨点敲窗，心事泡成茶汤，喝一口暖一暖，今晚早点睡吧。",
        "月亮挂在楼顶，影子拉得很长，我讲个冷笑话，你先别急着走。",
        "锅里的水开了，日子咕嘟作响，捞一口热乎的，慢慢就顺了。",
        "风从街口过来，带来一点凉意，我把外套裹紧，顺便想你一下。",
        "云走得很慢，天蓝得没道理，什么也不想干，就这样呆一会儿。",
        "地铁来了又走，人群散了又聚，我站在原地，哼两句给自己听。",
    )

    def _fallback_lyrics(self, key: str, title: str) -> str:
        """没有歌词时的原创小调：按群计数轮转整个池子，连唱绝不重样。"""
        pool = self.FALLBACK_POOL
        try:
            seed = sum(ord(c) for c in (key + "|" + title)) or 0
        except Exception:  # noqa: BLE001
            seed = 0
        turn = int(self._fallback_turn.get(key, 0))
        line = pool[(seed + turn) % len(pool)]
        self._fallback_turn[key] = turn + 1
        self._last_fallback[key] = line
        return line

    # ---------------- 唱歌 ----------------

    async def _sing(self, ctx, m: dict[str, Any], song: str) -> None:
        lyrics, shown = ("", "")
        if song:
            lyrics, shown = await self._fetch_lyrics(song)
        if not lyrics:
            lyrics = await self._llm_lyrics(song)
            shown = ""
        if not lyrics:
            gid_key = (str(m["group_id"]) if m["is_group"]
                       else "u" + str(m["user_id"]))
            lyrics = self._fallback_lyrics(gid_key, song or "")
        sing = str(self.cfg_get("sing_tag", "[唱歌]"))
        hum = str(self.cfg_get("hum_tag", "[哼歌]"))
        prelude = ""
        if self.cfg_get("sing_prelude", True) and lyrics:
            first_line = lyrics.split("，")[0].strip()
            if first_line:
                prelude = f"{self.cfg_get('prelude_tag', '[耳语]')}{first_line}。[停顿] "
        # 标签后保留收尾文字，避免文本润色往标签尾部加语气词
        text = f"{prelude}{sing}{lyrics} {hum} 就唱到这儿啦"
        try:
            seg = await self.bot.voice_segment(text)
            if m["is_group"]:
                await self.bot.send_group_msg(m["group_id"], seg)
            else:
                await self.bot.send_private_msg(m["user_id"], seg)
            self.log.info("唱歌：%s 歌=%s 歌词=%s",
                          m["group_id"] or m["user_id"],
                          shown or (song or "原创"), lyrics[:30])
        except Exception as exc:  # noqa: BLE001
            self.log.warning("唱歌失败（降级文字）: %s", exc)
            try:
                await ctx.reply(f"嗓子今天不太行，歌词给你：{lyrics}")
            except Exception:
                pass

    def _rate_ok(self, gid: str) -> bool:
        now = time.time()
        cd = max(0, int(self.cfg_get("group_cooldown_seconds", 600)))
        if now - self._last_by_group.get(gid, 0) < cd:
            return False
        day = time.strftime("%Y-%m-%d")
        key = (gid, day)
        if self._day_count.get(key, 0) >= max(1, int(
                self.cfg_get("daily_limit_per_group", 6))):
            return False
        self._last_by_group[gid] = now
        self._day_count[key] = self._day_count.get(key, 0) + 1
        return True

    # ---------------- 指令 ----------------

    async def _cmd(self, ctx, args: str) -> Any:
        m = self._norm(ctx)
        await self._sing(ctx, m, (args or "").strip())
        return self.stop()

    # ---------------- 工具 ----------------

    def _norm(self, ctx) -> dict[str, Any]:
        event = getattr(ctx, "event", ctx)
        try:
            uid = int(getattr(event, "user_id", 0) or 0)
        except (TypeError, ValueError):
            uid = 0
        gid = getattr(event, "group_id", None)
        try:
            gid = int(gid) if gid else None
        except (TypeError, ValueError):
            gid = None
        return {
            "user_id": uid, "group_id": gid, "is_group": gid is not None,
            "text": str(getattr(event, "text", "") or "").strip(),
            "is_admin": bool(getattr(ctx, "is_admin", False)),
        }
