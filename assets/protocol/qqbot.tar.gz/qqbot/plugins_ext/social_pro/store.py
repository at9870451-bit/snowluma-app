"""social_pro store — 主动社交插件的事件与状态记录（SQLite）。"""

from __future__ import annotations

import sqlite3
import time
from pathlib import Path

SCHEMA = """
CREATE TABLE IF NOT EXISTS events(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ts REAL,
  kind TEXT,          -- qzone_auto / qzone_cmd / ping_private / gate_block
  target TEXT,
  detail TEXT
);
"""


def connect(path: Path) -> sqlite3.Connection:
    conn = sqlite3.connect(str(path), check_same_thread=False, timeout=10)
    conn.row_factory = sqlite3.Row
    return conn


def ensure_schema(conn: sqlite3.Connection) -> None:
    conn.executescript(SCHEMA)
    conn.commit()


def record(conn: sqlite3.Connection, kind: str, target: str = "",
           detail: str = "") -> None:
    conn.execute("INSERT INTO events(ts, kind, target, detail) VALUES(?,?,?,?)",
                 (time.time(), kind, str(target), detail))
    conn.commit()


def count_since(conn: sqlite3.Connection, kind: str, target: str,
                seconds: float) -> int:
    row = conn.execute(
        "SELECT COUNT(*) c FROM events WHERE kind=? AND target=? AND ts>=?",
        (kind, str(target), time.time() - seconds)).fetchone()
    return int(row["c"] or 0)


def last_at(conn: sqlite3.Connection, kind: str, target: str) -> float:
    row = conn.execute(
        "SELECT MAX(ts) m FROM events WHERE kind=? AND target=?",
        (kind, str(target))).fetchone()
    return float(row["m"] or 0.0)
