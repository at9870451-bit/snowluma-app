"""QQBot SocialPro 主动社交插件 v1.0.0

三大能力：
  1. 聊天范围门控：置控台/App 配的「可聊天群聊」白名单（gateway /ai/chat-scope，
     存 /opt/ai_gateway/config.json 的 chatGroups）在这里强制执行——
     白名单非空时，名单外的群不再自动回复（主人消息与指令不受限）
  2. 发 QQ 空间：主人「发空间：<内容>」立即发；自动模式每天 1 条人设说说
  3. 主动私聊：按节奏给主人和名单里的朋友发问候消息（安静时段不发，
     正聊着不打扰，每人每天最多 2 条）

管理员指令：/social 状态｜私聊 on|off｜空间 on|off｜加私聊 <QQ>｜删私聊 <QQ>｜
            名单｜发空间 <内容>｜测试私聊 <QQ>
"""

from __future__ import annotations

import asyncio
import json
import random
import re
import time
from pathlib import Path
from typing import Any

from qqbot.core.bus import STOP
from qqbot.core.message import Message, text as text_seg
from qqbot.plugins.base import Plugin

from . import store

_QZONE_RE = re.compile(r"^发空间[:：\s]+")

# 安静时段（小时制，float）：23:30 ~ 08:30 不主动打扰
_QUIET_START = 23.5
_QUIET_END = 8.5


def _in_quiet_hours(now: float | None = None) -> bool:
    lt = time.localtime(now or time.time())
    h = lt.tm_hour + lt.tm_min / 60.0
    return h >= _QUIET_START or h < _QUIET_END


def _day_of(now: float | None = None) -> str:
    return time.strftime("%Y-%m-%d", time.localtime(now or time.time()))


class SocialProPlugin(Plugin):
    name = "social_pro"
    display_name = "主动社交"
    version = "1.0.0"
    description = "聊天范围白名单门控 + 发QQ空间（指令/每日自动）+ 主动私聊问候（防打扰）"
    priority = 18  # 早于 bot_teacher(19)/humanlike(20)：范围门控要在最前面

    default_config = {
        "enabled": True,
        # ---- 聊天范围门控 ----
        "gate_enabled": True,        # 读取 gateway chatGroups 白名单并强制执行
        "gateway_config": "/opt/ai_gateway/config.json",
        "scope_cache_seconds": 30,
        # ---- QQ 空间 ----
        "qzone_auto": True,          # 每天自动发一条人设说说
        "qzone_hour_min": 10,        # 自动发说说的时段窗口
        "qzone_hour_max": 22,
        "qzone_max_chars": 120,
        # ---- 主动私聊 ----
        "private_enabled": True,
        "private_targets": [],       # 除主人外的私聊对象 QQ
        "private_probability": 0.35, # 每 30 分钟节拍的主观概率
        "private_cooldown_hours": 4, # 同一人两次问候最小间隔
        "private_daily_cap": 2,      # 每人每天最多几条
        "private_quiet_skip": True,  # 安静时段不发
        "active_chat_skip_min": 45,  # 对方刚聊过天就不打扰
        "max_ping_chars": 80,
    }

    config_labels = {
        "enabled": "启用主动社交",
        "gate_enabled": "聊天范围白名单门控",
        "qzone_auto": "每天自动发一条说说",
        "private_enabled": "主动私聊问候",
        "private_targets": "私聊对象 QQ（逗号分隔）",
        "private_probability": "问候概率（每30分钟节拍）",
        "private_cooldown_hours": "同一人问候间隔（小时）",
        "private_daily_cap": "每人每天上限",
    }

    def __init__(self, bot) -> None:
        super().__init__(bot)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self._conn = store.connect(self.data_dir / "social.sqlite3")
        store.ensure_schema(self._conn)
        self._scope_cache: tuple[float, list[str]] = (0.0, [])
        self._last_incoming: dict[int, float] = {}   # uid -> ts（对方最近消息）
        self._qzone_day = ""
        self._loop_task: asyncio.Task | None = None

    # ---------- 生命周期 ----------

    async def on_load(self) -> None:
        if not self.cfg_get("enabled", True):
            return
        self.add_command("social", self._cmd, aliases=("社交",),
                         admin=True, description="主动社交：状态/私聊/空间/发空间/名单")
        self._loop_task = asyncio.get_running_loop().create_task(self._tick_loop())
        self.log.info("主动社交已启用（门控=%s 空间自动=%s 私聊=%s）",
                      self.cfg_get("gate_enabled", True),
                      self.cfg_get("qzone_auto", True),
                      self.cfg_get("private_enabled", True))

    async def on_unload(self) -> None:
        if self._loop_task:
            self._loop_task.cancel()

    # ---------- 聊天范围白名单 ----------

    def _chat_groups(self) -> list[str]:
        """读 gateway 的 chatGroups（缓存 30s）；读不到=沿用上次结果。"""
        now = time.time()
        ts, cached = self._scope_cache
        if now - ts < max(5, int(self.cfg_get("scope_cache_seconds", 30))):
            return cached
        try:
            path = Path(str(self.cfg_get(
                "gateway_config", "/opt/ai_gateway/config.json")))
            data = json.loads(path.read_text(encoding="utf-8"))
            groups = [str(g) for g in (data.get("chatGroups") or [])
                      if str(g).strip()]
        except Exception:
            groups = cached  # 读失败沿用缓存
        self._scope_cache = (now, groups)
        return groups

    # ---------- 消息入口 ----------

    async def on_message(self, ctx) -> Any:
        if not self.cfg_get("enabled", True):
            return None
        m = self._norm(ctx)
        # 记录对方最近活跃（供「正聊着不打扰」判断）
        if m["user_id"]:
            self._last_incoming[m["user_id"]] = time.time()

        # 主人「发空间：<内容>」（群/私聊都行）
        if m["is_admin"] and _QZONE_RE.match(m["text"]):
            await self._post_qzone_cmd(ctx, _QZONE_RE.sub("", m["text"], count=1).strip())
            return self.stop()

        # 聊天范围门控：白名单非空时，名单外的群消息直接拦（主人不受限）
        if self.cfg_get("gate_enabled", True) \
                and m["is_group"] and not m["is_admin"]:
            scope = self._chat_groups()
            if scope and str(m["group_id"]) not in scope:
                return STOP
        return None

    # ---------- 发 QQ 空间 ----------

    async def _post_qzone_cmd(self, ctx, content: str) -> None:
        content = (content or "").strip()
        if not content:
            await self._reply(ctx, "想发啥说说？内容跟在后面就行，例如：发空间：今天天气真好")
            return
        tid = await self._qzone_post(content)
        if tid is None:
            await self._reply(ctx, "发说说失败了，看看日志。")
            return
        store.record(self._conn, "qzone_cmd", detail=content[:60])
        await self._reply(ctx, "发好啦，去看看。" + (f"（tid={tid}）" if tid else ""))

    async def _qzone_post(self, content: str) -> str | None:
        try:
            resp = await self.bot.call_api(
                "send_qzone_msg", {"content": content, "ugc_right": 1})
            data = resp.get("data") if isinstance(resp, dict) else {}
            self.log.info("已发说说：%s", content[:40])
            return str((data or {}).get("tid") or "")
        except Exception as exc:  # noqa: BLE001
            self.log.warning("发说说失败: %s", exc)
            return None

    async def _qzone_auto_content(self) -> str:
        try:
            client = self.bot.chat_client()
            prompt = ("以「菲比」的口吻写一条现在发的朋友圈说说：50 字以内，"
                      "像真人随手记录生活（天气/心情/小事/吐槽都行），"
                      "口语一点，不要话题标签，不要 @ 任何人，只输出说说正文。")
            text = (await asyncio.wait_for(
                client.chat("social_qzone", prompt, ""), timeout=45)) or ""
            return text.strip().strip('"「」')[:int(self.cfg_get("qzone_max_chars", 120))]
        except Exception as exc:  # noqa: BLE001
            self.log.debug("生成说说失败: %s", exc)
            return ""

    # ---------- 主动私聊 ----------

    def _master_uins(self) -> list[int]:
        try:
            return [int(a) for a in (self.bot.config.bot.admins or [])]
        except (TypeError, ValueError):
            return []

    def _ping_targets(self) -> list[int]:
        targets = list(self._master_uins())
        for t in (self.cfg_get("private_targets", []) or []):
            try:
                uid = int(t)
            except (TypeError, ValueError):
                continue
            if uid not in targets:
                targets.append(uid)
        return targets

    def _ping_eligible(self, uid: int, now: float | None = None) -> tuple[bool, str]:
        now = now or time.time()
        if self.cfg_get("private_quiet_skip", True) and _in_quiet_hours(now):
            return False, "安静时段"
        cap = max(0, int(self.cfg_get("private_daily_cap", 2)))
        if store.count_since(self._conn, "ping_private", uid, 86400) >= cap:
            return False, "今日已达上限"
        cd = max(0.0, float(self.cfg_get("private_cooldown_hours", 4))) * 3600
        if now - store.last_at(self._conn, "ping_private", uid) < cd:
            return False, "间隔未到"
        skip = max(0, int(self.cfg_get("active_chat_skip_min", 45))) * 60
        if now - self._last_incoming.get(uid, 0) < skip:
            return False, "对方刚在聊天"
        return True, ""

    async def _ping_content(self, uid: int) -> str:
        try:
            client = self.bot.chat_client()
            lt = time.localtime()
            hour = lt.tm_hour
            period = ("早上" if hour < 11 else "中午" if hour < 14
                      else "下午" if hour < 18 else "晚上")
            prompt = (f"你是「菲比」。现在是{period}，你想主动找一位朋友（QQ {uid}）"
                      "聊两句。写一句开口的话：80 字以内，口语、自然、像熟人突然想起对方，"
                      "可以聊天气/吃的/日常小事，别问「在吗」，只输出这句话。")
            text = (await asyncio.wait_for(
                client.chat(f"social_ping_{uid}", prompt, ""), timeout=45)) or ""
            return text.strip()[:int(self.cfg_get("max_ping_chars", 80))]
        except Exception as exc:  # noqa: BLE001
            self.log.debug("生成问候失败: %s", exc)
            return ""

    # ---------- 定时节拍（每 30 分钟） ----------

    async def _tick_loop(self) -> None:
        await asyncio.sleep(20)  # 启动缓冲
        while True:
            try:
                await self._tick()
            except asyncio.CancelledError:
                raise
            except Exception as exc:  # noqa: BLE001
                self.log.warning("社交节拍异常: %s", exc)
            await asyncio.sleep(30 * 60)

    async def _tick(self) -> None:
        # 0) 把聊天白名单同步给 idle_talk（它是主动发起，不走消息链）
        try:
            scope = self._chat_groups()
            for pl in getattr(getattr(self.bot, "plugins", None), "plugins", []) or []:
                if getattr(pl, "name", "") == "idle_talk":
                    cur = [str(g) for g in (pl.cfg.get("allow_groups") or [])]
                    if cur != scope:
                        pl.cfg["allow_groups"] = list(scope)
                        pl.save_config()
                        self.log.info("已同步 idle_talk 群范围 → %s", scope or "不限")
                    break
        except Exception as exc:  # noqa: BLE001
            self.log.debug("同步 idle_talk 失败: %s", exc)

        # 1) 每日自动说说：到窗口、今天没发过、掷骰
        if self.cfg_get("qzone_auto", True) and self._qzone_day != _day_of():
            h = time.localtime().tm_hour
            lo = int(self.cfg_get("qzone_hour_min", 10))
            hi = int(self.cfg_get("qzone_hour_max", 22))
            if lo <= h < hi and random.random() < 0.25:
                content = await self._qzone_auto_content()
                if content:
                    tid = await self._qzone_post(content)
                    if tid is not None:
                        self._qzone_day = _day_of()
                        store.record(self._conn, "qzone_auto", detail=content[:60])
                else:
                    self._qzone_day = _day_of()  # 生成失败今天不再试

        # 2) 主动私聊问候
        if not self.cfg_get("private_enabled", True):
            return
        if random.random() > float(self.cfg_get("private_probability", 0.35)):
            return
        for uid in self._ping_targets():
            ok, why = self._ping_eligible(uid)
            if not ok:
                continue
            text = await self._ping_content(uid)
            if not text:
                continue
            try:
                await self.bot.send_private_msg(uid, Message([text_seg(text)]))
                store.record(self._conn, "ping_private", uid, text[:40])
                self.log.info("主动问候 → %s：%s", uid, text[:30])
            except Exception as exc:  # noqa: BLE001
                self.log.warning("私聊发送失败(%s): %s", uid, exc)
            break  # 一个节拍最多问候一个人

    # ---------- 管理指令 ----------

    async def _cmd(self, ctx, args: str) -> Any:
        a = (args or "").strip()
        head, _, rest = a.partition(" ")
        rest = rest.strip()

        if head in ("", "状态", "status"):
            scope = self._chat_groups()
            pings = store.count_since(self._conn, "ping_private", "", 86400)
            lines = ["【主动社交】",
                     f"聊天范围门控：{'开' if self.cfg_get('gate_enabled', True) else '关'}"
                     f"（白名单 {len(scope)} 群{'，不限' if not scope else ''}）",
                     f"自动说说：{'开' if self.cfg_get('qzone_auto', True) else '关'}"
                     f"（今天{'已发' if self._qzone_day == _day_of() else '未发'}）",
                     f"主动私聊：{'开' if self.cfg_get('private_enabled', True) else '关'} · "
                     f"对象 {len(self._ping_targets())} 人 · "
                     f"今日已问候 {pings} 次"]
            await self._reply(ctx, "\n".join(lines))
            return self.stop()

        if head == "私聊" and rest in ("on", "off", "开", "关"):
            self.cfg["private_enabled"] = rest in ("on", "开")
            self.save_config()
            await self._reply(ctx, "主动私聊已"
                              + ("开启。" if self.cfg["private_enabled"] else "关闭。"))
            return self.stop()

        if head == "空间" and rest in ("on", "off", "开", "关"):
            self.cfg["qzone_auto"] = rest in ("on", "开")
            self.save_config()
            await self._reply(ctx, "自动说说已"
                              + ("开启。" if self.cfg["qzone_auto"] else "关闭。"))
            return self.stop()

        if head == "发空间":
            await self._post_qzone_cmd(ctx, rest)
            return self.stop()

        if head == "加私聊" and rest.isdigit():
            targets = [str(t) for t in (self.cfg_get("private_targets", []) or [])]
            if rest in targets:
                await self._reply(ctx, "已经在名单里了。")
            else:
                targets.append(rest)
                self.cfg["private_targets"] = targets
                self.save_config()
                await self._reply(ctx, f"已加入私聊名单（共 {len(targets)} 人）。")
            return self.stop()

        if head == "删私聊" and rest.isdigit():
            targets = [str(t) for t in (self.cfg_get("private_targets", []) or [])]
            if rest in targets:
                targets.remove(rest)
                self.cfg["private_targets"] = targets
                self.save_config()
                await self._reply(ctx, f"已移出私聊名单（剩 {len(targets)} 人）。")
            else:
                await self._reply(ctx, "名单里没有这个人。")
            return self.stop()

        if head in ("名单", "targets"):
            tg = self._ping_targets()
            await self._reply(ctx, "私聊对象："
                              + ("、".join(map(str, tg)) if tg else "无"))
            return self.stop()

        if head == "测试私聊" and rest.isdigit():
            text = await self._ping_content(int(rest))
            if not text:
                await self._reply(ctx, "生成问候失败，稍后再试。")
                return self.stop()
            await self.bot.send_private_msg(int(rest), Message([text_seg(text)]))
            store.record(self._conn, "ping_private", rest, text[:40] + "（测试）")
            await self._reply(ctx, f"已发给 {rest}：{text}")
            return self.stop()

        await self._reply(ctx, "用法：/social 状态｜私聊 on|off｜空间 on|off｜"
                               "发空间 <内容>｜加私聊 <QQ>｜删私聊 <QQ>｜名单｜"
                               "测试私聊 <QQ>")
        return self.stop()

    # ---------- 工具 ----------

    async def _reply(self, ctx, message: str) -> None:
        try:
            await ctx.reply(message)
        except Exception as exc:  # noqa: BLE001
            self.log.warning("回复失败: %s", exc)

    def _norm(self, ctx) -> dict[str, Any]:
        event = getattr(ctx, "event", ctx)
        sender = getattr(event, "sender", None) or {}
        try:
            uid = int(getattr(event, "user_id", 0) or 0)
        except (TypeError, ValueError):
            uid = 0
        gid = getattr(event, "group_id", None)
        try:
            gid = int(gid) if gid else None
        except (TypeError, ValueError):
            gid = None
        return {
            "user_id": uid,
            "group_id": gid,
            "is_group": gid is not None,
            "text": str(getattr(event, "text", "") or "").strip(),
            "is_admin": bool(getattr(ctx, "is_admin", False)),
        }
