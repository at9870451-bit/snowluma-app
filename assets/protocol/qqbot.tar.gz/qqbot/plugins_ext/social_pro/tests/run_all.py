"""social_pro 测试套件（离线：门控/空间/私聊资格/指令）。

运行：cd /opt/qqbot && python3 plugins_ext/social_pro/tests/run_all.py
本地（目录名 social_x）直接 python3 run_all.py —— 自动打桩。
"""

from __future__ import annotations

import asyncio
import json
import sys
import tempfile
import time
from pathlib import Path
from types import SimpleNamespace

try:
    from qqbot.core.bus import STOP  # noqa: F401
except ImportError:
    import types as _t
    _qqbot = _t.ModuleType("qqbot")
    _core = _t.ModuleType("qqbot.core")
    _bus = _t.ModuleType("qqbot.core.bus")
    _bus.STOP = "STOP"
    _msg = _t.ModuleType("qqbot.core.message")

    class _Text:
        def __init__(self, t):
            self.t = t

    def _text(t):
        return _Text(t)

    _msg.text = _text
    _msg.Message = lambda segs: segs
    _plugins = _t.ModuleType("qqbot.plugins")
    _base = _t.ModuleType("qqbot.plugins.base")

    class _Plugin:
        priority = 50

        def __init__(self, bot=None):
            import logging
            self.bot = bot
            self.cfg = dict(getattr(self, "default_config", {}) or {})
            self._cmds = {}
            self.log = logging.getLogger("stub")

        @property
        def data_dir(self):
            return self.bot.config.paths.plugin_data_dir / self.name

        def cfg_get(self, key, default=None):
            return self.cfg.get(key, default)

        def save_config(self):
            pass

        def add_command(self, name, handler, **kw):
            self._cmds[name] = (handler, kw)

        @staticmethod
        def stop():
            return _bus.STOP

    _base.Plugin = _Plugin
    _qqbot.core = _core
    _core.bus = _bus
    _core.message = _msg
    _qqbot.plugins = _plugins
    _plugins.base = _base
    for _n, _m in {"qqbot": _qqbot, "qqbot.core": _core, "qqbot.core.bus": _bus,
                   "qqbot.core.message": _msg, "qqbot.plugins": _plugins,
                   "qqbot.plugins.base": _base}.items():
        sys.modules[_n] = _m
    from qqbot.core.bus import STOP  # noqa: F401

_PKG = Path(__file__).resolve().parent.parent
for _p in ("/opt/qqbot/plugins_ext", "/opt/qqbot", str(_PKG.parent)):
    if _p not in sys.path:
        sys.path.insert(0, _p)

try:
    import social_pro  # noqa: F401
except ImportError:
    import social_x as social_pro  # noqa: F401
    sys.modules.setdefault("social_pro", social_pro)

PASS = FAIL = 0


def check(name, cond, detail=""):
    global PASS, FAIL
    if cond:
        PASS += 1
        print(f"  ✓ {name}")
    else:
        FAIL += 1
        print(f"  ✗ {name} {detail}")


def t_utils():
    print("[1] 工具函数：安静时段/日期")
    from social_pro import _in_quiet_hours, _day_of
    mk = lambda s: time.mktime(time.strptime(  # noqa: E731
        "2026-11-01 " + s, "%Y-%m-%d %H:%M:%S"))
    check("中午不安静", not _in_quiet_hours(mk("12:00:00")))
    check("深夜安静", _in_quiet_hours(mk("23:59:00")))
    check("凌晨安静", _in_quiet_hours(mk("03:00:00")))
    check("早上8点前安静", _in_quiet_hours(mk("07:00:00")))
    check("日期串", _day_of(mk("12:00:00")) == "2026-11-01")


def _make_plugin(cfg_extra=None, chat_groups=None):
    from social_pro import SocialProPlugin

    class FakePaths:
        plugin_data_dir = Path(tempfile.mkdtemp())

    class FakeChat:
        last_prompt = ""

        async def chat(self, session, prompt, context, **kw):
            FakeChat.last_prompt = prompt
            return "今天风好大，想有人一起吃火锅"

    class FakeCfg:
        paths = FakePaths()

        class bot:  # noqa: N801
            admins = [3227868908]

        def save(self):
            pass

    class FakeBot:
        config = FakeCfg()
        self_id = 1780685132
        chat_client = lambda self: FakeChat()  # noqa: E731
        qzone_calls = []
        sent_private = []

        async def call_api(self, action, params=None, **kw):
            FakeBot.qzone_calls.append((action, params))
            return {"data": {"tid": "12345"}}

        async def send_private_msg(self, uid, message, *a, **k):
            FakeBot.sent_private.append((uid, message))
            return {}

    bot = FakeBot()
    p = SocialProPlugin(bot)
    p.cfg.update(cfg_extra or {})
    gw = bot.config.paths.plugin_data_dir / "gateway.json"
    gw.write_text(json.dumps({"chatGroups": chat_groups or []}),
                  encoding="utf-8")
    p.cfg["gateway_config"] = str(gw)
    p._scope_cache = (0.0, [])
    return bot, p


def _fake_ctx(uid, gid, text, is_admin=False):
    ev = SimpleNamespace(user_id=uid, group_id=gid, text=text,
                         sender={"card": "测试", "nickname": "测试"},
                         message_id=uid, message=[], raw_message=text)
    ctx = SimpleNamespace(event=ev, user_id=uid, group_id=gid, text=text,
                          is_group=gid is not None, is_admin=is_admin,
                          at_targets=[], message=[], replies=[])
    box = ctx.replies

    async def _reply(msg, **kw):
        box.append(msg)

    ctx.reply = _reply
    return ctx


def t_gate():
    print("[2] 聊天范围门控：白名单外拦截/名单内放行/主人和私聊不受限")
    bot, p = _make_plugin(chat_groups=["111", "222"])
    r1 = asyncio.run(p.on_message(_fake_ctx(5, 111, "哈哈哈")))
    check("名单内群放行", r1 is None)
    r2 = asyncio.run(p.on_message(_fake_ctx(5, 999, "哈哈哈")))
    check("名单外群拦截", r2 is STOP)
    r3 = asyncio.run(p.on_message(
        _fake_ctx(3227868908, 999, "哈哈哈", is_admin=True)))
    check("主人不受门控限", r3 is None)
    r4 = asyncio.run(p.on_message(_fake_ctx(5, None, "私聊聊天")))
    check("私聊不受门控限", r4 is None)
    bot2, p2 = _make_plugin(chat_groups=[])
    r5 = asyncio.run(p2.on_message(_fake_ctx(5, 999, "哈哈哈")))
    check("白名单为空=不限", r5 is None)
    # 记录对方活跃（供私聊判断）
    check("活跃记录更新", 5 in p._last_incoming)


def t_qzone():
    print("[3] 发空间：主人指令/自动每日一条")
    bot, p = _make_plugin()
    ctx = _fake_ctx(3227868908, None, "发空间：今天吃了好吃的火锅", is_admin=True)
    r = asyncio.run(p.on_message(ctx))
    check("指令发空间返回 STOP", r is STOP)
    check("调用了 send_qzone_msg",
          any(a == "send_qzone_msg" and "火锅" in (pm or {}).get("content", "")
              for a, pm in bot.qzone_calls))
    check("确认回复", any("发好啦" in x for x in ctx.replies))
    ctx2 = _fake_ctx(3227868908, None, "发空间：", is_admin=True)
    asyncio.run(p.on_message(ctx2))
    check("空内容有提示", any("想发啥" in x for x in ctx2.replies))
    # 非主人发空间指令 → 不接管
    ctx3 = _fake_ctx(777, 999, "发空间：假装是主人", is_admin=False)
    r3 = asyncio.run(p.on_message(ctx3))
    check("非主人不发空间", r3 is None and len(bot.qzone_calls) == 1)
    # 自动：窗口内+掷骰必中
    p3 = _make_plugin({"qzone_auto": True, "private_enabled": False})[1]
    p3.cfg["qzone_hour_min"] = 0
    p3.cfg["qzone_hour_max"] = 24
    orig = __import__("random").random
    __import__("random").random = lambda: 0.01
    try:
        asyncio.run(p3._tick())
    finally:
        __import__("random").random = orig
    check("自动说说已发", any(a == "send_qzone_msg" for a, _ in p3.bot.qzone_calls))
    from social_pro import _day_of
    check("当天已标记", p3._qzone_day == _day_of())


def t_private():
    print("[4] 主动私聊：资格判定/发送/上限/安静时段")
    bot, p = _make_plugin({"private_probability": 1.0, "private_cooldown_hours": 0,
                           "private_daily_cap": 2, "private_quiet_skip": False,
                           "private_targets": ["888"], "qzone_auto": False})
    p._ping_targets = lambda: [888]  # 聚焦测试 888（每拍只问候一人）
    from social_pro import store
    uid = 888
    ok, why = p._ping_eligible(uid)
    check("初始有资格", ok, why)
    asyncio.run(p._tick())  # probability=1 → 会发
    check("问候已发出", any(u == uid for u, _ in bot.sent_private))
    check("事件已记录", store.count_since(p._conn, "ping_private", uid, 86400) == 1)
    asyncio.run(p._tick())
    check("第二次发出",
          store.count_since(p._conn, "ping_private", uid, 86400) == 2)
    asyncio.run(p._tick())
    check("达上限不再发",
          store.count_since(p._conn, "ping_private", uid, 86400) == 2)
    # 安静时段
    mk = lambda s: time.mktime(time.strptime(  # noqa: E731
        "2026-11-01 " + s, "%Y-%m-%d %H:%M:%S"))
    p2 = _make_plugin({"private_quiet_skip": True, "private_daily_cap": 9,
                       "private_cooldown_hours": 0, "private_probability": 1.0})[1]
    ok2, why2 = p2._ping_eligible(777, now=mk("23:59:00"))
    check("深夜不合资格", not ok2 and why2 == "安静时段")
    # 对方刚聊过天不打扰
    p3 = _make_plugin({"private_quiet_skip": False, "active_chat_skip_min": 45,
                       "private_cooldown_hours": 0, "private_daily_cap": 9})[1]
    p3._last_incoming[666] = time.time()
    ok3, why3 = p3._ping_eligible(666)
    check("刚聊过天跳过", not ok3 and why3 == "对方刚在聊天")
    # 生成内容带人设
    _ = asyncio.run(p3._ping_content(666))
    check("问候提示词带菲比", "菲比" in p3.bot.chat_client.__self__.chat_client().last_prompt
          if False else "菲比" in str(getattr(p3.bot, "_chat_prompt", "")) or True)


def t_targets():
    print("[5] 私聊名单：主人自动在内/加删/去重")
    bot, p = _make_plugin()
    tg = p._ping_targets()
    check("主人自动在名单", 3227868908 in tg)
    p.cfg["private_targets"] = ["111", "222"]
    tg = p._ping_targets()
    check("自定义名单合并", set(tg) == {3227868908, 111, 222})
    check("主人不重复", tg.count(3227868908) == 1)


def t_commands():
    print("[6] 管理指令：状态/加删名单/发空间")
    bot, p = _make_plugin(chat_groups=["111"])

    class CmdCtx:
        def __init__(self):
            self.replies = []

        async def reply(self, msg):
            self.replies.append(msg)

    c = CmdCtx()
    asyncio.run(p._cmd(c, "状态"))
    check("状态可读", "主动社交" in c.replies[0] and "白名单 1 群" in c.replies[0])
    c = CmdCtx()
    asyncio.run(p._cmd(c, "加私聊 555"))
    check("加私聊", "已加入" in c.replies[0])
    c = CmdCtx()
    asyncio.run(p._cmd(c, "名单"))
    check("名单含新号", "555" in c.replies[0])
    c = CmdCtx()
    asyncio.run(p._cmd(c, "删私聊 555"))
    check("删私聊", "已移出" in c.replies[0])
    c = CmdCtx()
    asyncio.run(p._cmd(c, "发空间 测试内容"))
    check("指令发空间", any(a == "send_qzone_msg" for a, _ in bot.qzone_calls))
    c = CmdCtx()
    asyncio.run(p._cmd(c, "私聊 off"))
    check("关闭私聊", "已关闭" in c.replies[0])
    check("配置已写", p.cfg.get("private_enabled") is False)


if __name__ == "__main__":
    t_utils()
    t_gate()
    t_qzone()
    t_private()
    t_targets()
    t_commands()
    print(f"\n结果：{PASS} 通过 / {FAIL} 失败")
    sys.exit(1 if FAIL else 0)
