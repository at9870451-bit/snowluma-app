"""主动开话题插件：每隔一段时间在活跃群里主动发起话题（AI 主动说话）。

与自主模式的分工：
  - 自主模式（auto_chat）：响应别人的消息（@ / 戳 / 关键词 / 概率接话）
  - 本插件（idle_talk）：群里安静时，AI 自己找话题开口，像真人冷场了找话说

触发条件（全部满足才开口）：
  1. 群在最近 active_within_minutes 分钟内有人说过话（活跃群）
  2. 群未被「闭嘴」、置控台未关闭该群 AI 发言
  3. 该群距离上次主动开口已超过 interval（节流）
  4. 按 speak_probability 抽签命中

实现：
  - 用总线订阅记录每个群最后活跃时间（不干预任何插件）
  - 独立 asyncio 定时任务，异常自愈
"""

from __future__ import annotations

import asyncio
import random
import time
from typing import Any

from qqbot.core.message import Message, text as text_seg
from qqbot.plugins.base import Plugin


class IdleTalkPlugin(Plugin):
    name = "idle_talk"
    display_name = "主动开话题"
    version = "1.0.0"
    description = "每隔一段时间在活跃群里主动发起话题（AI 主动说话，可配置间隔与概率）"
    priority = 90

    default_config = {
        "enabled": True,          # 总开关
        "interval_minutes": 30,   # 每多久检查一次 / 每个群最少间隔（分钟）
        "speak_probability": 0.6, # 每次检查时开口概率（0~1）
        "active_within_minutes": 90,  # 群在最近多少分钟内有人说话才算活跃
        "allow_groups": [],       # 只在这些群开话题（空=所有活跃群）
        "max_chars": 60,          # 开话题长度上限
    }

    config_labels = {
        "enabled": "启用主动开话题",
        "interval_minutes": "检查间隔（分钟）",
        "speak_probability": "开口概率（0~1）",
        "active_within_minutes": "群活跃判定窗口（分钟）",
        "allow_groups": "限定群号（逗号分隔，空=全部）",
        "max_chars": "话题长度上限",
    }

    def __init__(self, bot) -> None:
        super().__init__(bot)
        self._active_at: dict[int, float] = {}   # group_id -> 最后活跃时间
        self._last_speak: dict[int, float] = {}  # group_id -> 上次主动开口时间
        self._task: asyncio.Task | None = None

    # ---------- 生命周期 ----------

    async def on_load(self) -> None:
        # 总线订阅：记录每个群的活跃时间（不干预消息分发）
        self.subscribe("message", self._track)
        if self.cfg_get("enabled", True):
            self._spawn()
            self.log.info("主动开话题已启用（间隔=%s 分钟，概率=%s）",
                          self.cfg_get("interval_minutes"), self.cfg_get("speak_probability"))

    async def on_unload(self) -> None:
        if self._task:
            self._task.cancel()

    def _spawn(self) -> None:
        async def _run() -> None:
            while True:
                try:
                    interval = max(5, int(self.cfg_get("interval_minutes", 30))) * 60
                    await asyncio.sleep(interval)
                    await self._maybe_talk()
                except asyncio.CancelledError:
                    raise
                except Exception as exc:  # noqa: BLE001
                    self.log.warning("开话题协程异常，1 分钟后继续: %s", exc)
                    await asyncio.sleep(60)

        self._task = asyncio.get_running_loop().create_task(_run())

    # ---------- 活跃度记录 ----------

    async def _track(self, event) -> None:
        try:
            if getattr(event, "message_type", "") == "group" and event.group_id:
                self._active_at[int(event.group_id)] = time.time()
        except Exception:  # noqa: BLE001
            pass

    # ---------- 主动开口 ----------

    async def _maybe_talk(self) -> None:
        cfg = self.cfg
        if not cfg.get("enabled", True):
            return
        if not self.bot.config.ai.enabled:
            return
        try:
            prob = float(cfg.get("speak_probability", 0.6) or 0)
        except (TypeError, ValueError):
            prob = 0.6
        if not (prob >= 1.0 or (prob > 0 and random.random() < prob)):
            return

        now = time.time()
        window = max(5, int(cfg.get("active_within_minutes", 90))) * 60
        interval = max(5, int(cfg.get("interval_minutes", 30))) * 60

        candidates = [
            gid for gid, t in self._active_at.items()
            if now - t <= window
        ]
        allow = [int(g) for g in (cfg.get("allow_groups") or []) if str(g).isdigit()]
        if allow:
            candidates = [g for g in candidates if g in allow]
        candidates = [
            g for g in candidates
            if not self.bot.is_silenced(g)
            and self.bot.group_ai_enabled(g)
            and now - self._last_speak.get(g, 0) > interval
        ]
        if not candidates:
            return

        gid = random.choice(candidates)
        self._last_speak[gid] = now
        await self._talk_in(gid)

    async def _talk_in(self, gid: int) -> None:
        """生成并发送一条开话题的消息（风格跟随 ai.system_prompt）。"""
        max_chars = max(10, int(self.cfg_get("max_chars", 60)))
        try:
            client = self.bot.chat_client()
            session = f"group_{gid}"
            # 带群记忆/摘要，让话题跟得上群里的来龙去脉
            memory = await self.bot.memory_context(gid, 0)
            summary = await self.bot.summary_context(session)
            # 未授权群：主动话题零成人味（软性提醒）
            try:
                from persona_engine import adult as _ad
                _pe = getattr(self.bot, "persona_engine", None)
                _auth = False
                if _pe is not None:
                    _d = _pe._levels_load()
                    _auth = ("group:%s" % gid) in (_d.get("overrides") or {})
                if not _auth:
                    memory = (memory + "\n" + _ad.SOFT_BLOCK).strip()
            except Exception:  # noqa: BLE001
                pass
            prompt = (
                "（群里暂时没人说话，你自然地开个新话题，像真人随口起个头。"
                "可以顺着最近聊过的事问一句，也可以突然想到什么就说什么，"
                "别太刻意、别 @ 人、别说『我来开个话题』这种话。只发一条。）"
            )
            answer = await client.chat(session, prompt, memory=memory, summary=summary)
            answer = (answer or "").strip().strip('"“”')
            if (not answer or "（模型没有返回内容）" in answer
                    or "（模型没有" in answer):
                return
            if len(answer) > max_chars:
                answer = answer[:max_chars]
            await self.bot.send_group_msg(gid, Message([text_seg(answer)]))
            self.log.info("主动开话题 -> 群 %s: %s", gid, answer[:40])
        except Exception as exc:  # noqa: BLE001
            self.log.warning("开话题失败（不影响后续）: %s", exc)
