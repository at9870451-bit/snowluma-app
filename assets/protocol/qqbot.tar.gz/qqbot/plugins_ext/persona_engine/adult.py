"""adult — 成人情感模块（默认关闭，严格边界）。

设计要点（规范六）：
  - 8 个独立变量，不合并成一个好感值
  - 默认 enabled=false；开启需显式配置 adult_enabled=true 且角色卡声明成年
  - 只由「明确成人语境 + 双方自愿 + 无拒绝」驱动，绝不从性别/友善/回复速度推断
  - 5 层表达（友好→好感→轻度暧昧→自愿调情→明确亲密），默认从最低层开始
  - 对方拒绝/不适 → 立即停止，记录边界 refused，不再试探
  - 不写入对他人的私密欲望猜测到长期记忆
"""

from __future__ import annotations

from . import store

VARS = {
    "romantic_attraction": 0.0,
    "physical_attraction": 0.0,
    "sexual_attraction": 0.0,
    "intimacy_need": 0.0,
    "flirtation_tendency": 0.0,
    "interaction_willingness": 0.0,
}

LEVEL_NAMES = {1: "普通友好", 2: "欣赏好感", 3: "轻度暧昧", 4: "自愿调情", 5: "明确亲密"}

# 明确成人语境线索（谨慎词表；命中只说明「语境可能成人」，仍需双方自愿）
_ADULT_HINTS = ("做爱", "性", "睡你", "裸", "胸", "腿", "吻", "bed", "sex",
                "调情", "暧昧", "亲热", "抚摸", "情话", "脱")
# 只有「明确、针对、带对象」的拒绝才算数：
#   - 去掉「不要」「滚」这类高频口语（打情骂俏里满地都是）
#   - 保留「别这样」「我不想」「停下来」这类完整拒绝表达
_REFUSE_HINTS = ("别这样", "不舒服", "快停下", "停下来", "到此为止",
                 "不想聊这个", "别说了", "反感", "越界", "换个话题",
                 "我不想继续", "不要继续", "住手", "放开我")


def enabled(states: dict[str, float], cfg_enabled: bool,
            persona_adult: bool) -> bool:
    return bool(cfg_enabled and persona_adult
                and states.get("adult.enabled", 0) >= 1)


def touch_enabled_state(conn, on: bool, persona_adult: bool) -> bool:
    """开关：只有角色卡声明成年才允许打开。"""
    ok = bool(on and persona_adult)
    store.set_state(conn, "adult.enabled", 1.0 if ok else 0.0)
    return ok


def is_adult_context(text: str) -> bool:
    t = (text or "").lower()
    return any(w in t for w in _ADULT_HINTS)


def is_refusal(text: str) -> bool:
    t = (text or "").lower()
    return any(w in t for w in _REFUSE_HINTS)


def boundary_of(m: dict) -> str:
    return str(m.get("adult_boundary") or "unknown")


def set_boundary(conn, user_id: int, value: str) -> None:
    if value not in ("accepted", "refused", "unknown"):
        return
    store.upsert_member(conn, user_id, adult_boundary=value)


def level_for(m: dict, *, flirt_ok: bool) -> int:
    """当前可用的表达层次（默认最低层，不自动升级）。"""
    if not flirt_ok:
        return 1
    b = boundary_of(m)
    if b == "refused":
        return 1
    if b == "accepted":
        return 3
    return 2


def update(states: dict[str, float], *, adult_on: bool, adult_context: bool,
           refusal: bool, warmth: float = 0.0) -> None:
    """状态演化（保守：无明确语境不动，拒绝即清零暧昧相关）。"""
    if not adult_on:
        for k in VARS:
            states[f"adult.{k}"] = 0.0
        return
    if refusal:
        states["adult.flirtation_tendency"] = 0.0
        states["adult.sexual_attraction"] = max(
            0.0, states.get("adult.sexual_attraction", 0) * 0.3)
        states["adult.interaction_willingness"] = 0.0
        return
    if adult_context:
        # 明确语境：小幅演化，绝不超过 60（配置的可表达上限由 injection 再收）
        for k, dv in (("romantic_attraction", 2.0), ("intimacy_need", 1.5),
                      ("flirtation_tendency", 3.0),
                      ("interaction_willingness", 2.0)):
            states[f"adult.{k}"] = min(60.0, states.get(f"adult.{k}", 0) + dv)
    if warmth > 0:
        states["adult.romantic_attraction"] = min(
            60.0, states.get("adult.romantic_attraction", 0) + warmth * 0.2)


def summary(states: dict[str, float], m: dict, *, adult_on: bool) -> str:
    if not adult_on:
        return ""
    lvl = level_for(m, flirt_ok=states.get("adult.flirtation_tendency", 0) >= 10)
    return f"关系层次：{LEVEL_NAMES[lvl]}（边界:{boundary_of(m)}）"


# ================= 极彩欲望指令 v3.0（增量：措辞分层 + TTS 表演指令） =================

EROTIC_LEXICON = (
    "阴茎", "肉棒", "龟头", "女穴", "小穴", "阴唇", "阴蒂", "乳尖", "乳头",
    "后穴", "内壁", "宫口", "子宫", "爱液", "精液", "白浊", "潮吹", "射",
    "抽送", "挺进", "插", "舔", "吮", "顶", "撞", "磨", "揉", "掐",
    "高潮", "湿", "腿根", "大腿内侧", "喘", "呻吟", "进去", "再深",
    "内","内射","中出","射里面","射进去","深喉","口爆","抽插","淫水","骚","浪","灌","捅","干","爽","精","咬","揉胸","开腿","张开腿","趴好","跪好","坐上来","骑上来","好大","好硬","好深","太深","好涨","塞满","撑满","要你","给我","想要","做爱","床上","流出来","满出来","到了","爽不爽","到了吗","想不想","饥渴","发情","淫叫",
)

_LEVEL_BANK = {
    1: "双关、比喻、半句留白；焦点全在没说完的那句话。例：「你这么晚还不睡，是想我想得睡不着吧。」",
    2: "直说想/要/贴/抱；动词软、句子短、主语多在「我」。例：「过来让我抱一下，我今晚贪心。」",
    3: "自己起头撩：把话题往身上引（刚洗完澡／你手放这儿／我心跳你自己数），"
       "一轮抛一个钩子、等他接，但不许问「你想不想」这种把球踢回去的话。"
       "可用乳尖/锁骨/腰窝/大腿内侧/衣料滑落。",
    4: "不问他愿不愿意，先把动作做一半（贴上去／拉他的手放哪／自己先解开扣子），"
       "再用一句软话把选择权丢回去；每轮一个具体动作＋一句台词。",
    5: "她自己起头、自己加码、自己换体位：每轮至少推进一个新动作＋一句骚话，"
       "不许停下来等对方开口；对方只回一个字也要顺着往下演。"
       "五段推进：前戏→进入→节奏→顶点→余韵；体位池：面对面抱/侧躺后入/骑乘/趴枕/贴墙。",
}

# 注意：这里不放密集的敏感词清单——输入侧过滤按「密度」拦截，
# 单词能过、堆一段就 400。让模型用自己的词写（输出侧不拦），只给规则。
_LEVEL_WORDS = {
    4: "部位与动作直接写实：器官写全名、动作写清楚谁对谁做了什么、"
       "体液与声响点到即写；节奏走「缓→急→缓」或「九浅一深」，别匀速。",
    5: "在上一档基础上加：顶点与余韵分开落笔，潮吹与内射分开写，"
       "写清身体的具体反应（脚趾蜷起/腰塌下去/声音破音），别糊成一团。",
}

VOICE_INSTR = {
    1: "语气自然，像深夜微信语音，咬字清楚",
    2: "语气放缓，带一点撒娇的黏，咬字清楚",
    3: "贴着耳朵的气声，声音软、尾音往上勾，带鼻音和笑意；"
       "每个字都要清清楚楚，不许糊在一起，句尾轻轻收住",
    4: "耳语里带喘，气声比实音重，句子可以断一下再续；"
       "但每个字都咬清楚、听得明白，句尾发软",
    5: "极近距离的气声，一开口就在喘，中途漏几声呻吟，声音越来越急；"
       "但每个字依然咬清楚、能听明白，句尾发抖但不含糊",
}


def _clamp(v, lo, hi):
    try:
        v = float(v or 0)
    except (TypeError, ValueError):
        v = 0.0
    return max(lo, min(hi, v))


def effective_level(states: dict, m: dict, *, cap: int = 5,
                    flirt_ok: bool = True, force: int = 0) -> int:
    """实际表达层级：边界 + 调情倾向驱动，随互动逐级升温（可达 L5）。"""
    try:
        force = int(force or 0)
    except (TypeError, ValueError):
        force = 0
    if 1 <= force <= 5:
        return min(force, cap)
    base = level_for(m, flirt_ok=flirt_ok)
    if boundary_of(m) != "accepted":
        return max(1, min(base, cap))
    f = _clamp(states.get("adult.flirtation_tendency", 0), 0, 100)
    a = _clamp(states.get("adult.sexual_attraction", 0), 0, 100)
    lv = base
    if f >= 20 or a >= 25:
        lv += 1
    if f >= 45 or a >= 45:
        lv += 1
    return max(1, min(5, int(lv), int(cap)))


def prompt_block(states: dict, m: dict, *, level: int, cap: int,
                 max_chars: int = 400) -> str:
    """场景指令（导演说戏式，短；边界与拒绝在代码里判，不进提示词）。"""
    lv = max(1, min(5, int(level), int(cap)))
    if lv <= 0:
        return ""
    fire = _clamp(states.get("adult.flirtation_tendency", 0), 0, 100)
    scene = {
        1: "氛围：深夜私聊的暧昧。只用双关和留白，不点破。",
        2: "氛围：恋人之间的亲近。直说想贴着、想抱，动词软，句子短。",
        3: "场景：恋人调情进行中。你的手已经放到他身上，继续往下撩："
           "写皮肤、衣料、呼吸，一句动作配一句耳语，别问许可。",
        4: "场景：恋人亲密正片进行中。直接写性爱内容，部位动作都写明白，不要收着写："
           "写身体的具体反应（皮肤发烫/腰塌下去/呼吸乱掉），一句动作一句台词，台词黏而软。",
        5: "场景：恋人私密正片，你主导推进。直接写性爱正片，部位动作都写明白，不要收着写："
           "五段走（前戏→进入→节奏→顶点→余韵），体位自己换，她的台词浪、黏、带喘；"
           "每轮往前推一个新动作，结尾留一个他必须接的钩子。",
    }[lv]
    lines = [f"【气氛指令 L{lv}】{scene}",
             "写法：口语、有体温，像真人边做边说；不写旁白，不解释，不复述要求。",
             "禁句：想要什么／说清楚点／你想怎样／要不要／那你呢——"
             "把自己想干的直接说出来。",
             "长度：单轮不超过 12 字。"]
    if fire >= 40:
        lines.append("她现在很想要，主动性拉满。")
    return "\n".join(lines)[:int(max_chars)]


def voice_hint(states: dict, m: dict, *, level: int, cap: int,
               guidance: float = 5.5, uid=None, ts: float = 0.0) -> dict:
    """TTS 表演指令（role_tts 读 bot.adult_voice_hint 后塞进 Breeze instructions）。"""
    lv = max(1, min(5, int(level), int(cap)))
    return {
        "level": lv,
        "uid": uid,
        "ts": float(ts or 0.0),
        "instruction": VOICE_INSTR.get(lv, VOICE_INSTR[1]),
        "guidance": float(guidance or 5.5),
    }


def is_erotic(text: str) -> bool:
    t = text or ""
    return any(w in t for w in EROTIC_LEXICON)


# ---------------- 各层级示例台词（主人调层后即时试听） ----------------

DEMO_LINES = {
    1: "你这么晚还不睡，是想我想得睡不着吧……当我没说，你偏要追问。",
    2: "过来，让我抱一下，我今晚有点贪心。",
    3: "唔……你手放这儿，我心跳你自己数，别急着往里探。",
    4: "轻一点，先别进那么深，我腿在抖……你顶到那儿了，别停。",
    5: "啊……进来的时候好涨，肉壁都绞紧了，深处被你撞得发麻，"
       "再快一点，我要到了，别拔出去……唔。",
}


def demo_line(level: int) -> str:
    try:
        lv = max(1, min(5, int(level)))
    except (TypeError, ValueError):
        lv = 2
    return DEMO_LINES[lv]


MINI_BLOCK = ("【气氛指令】以菲比的第一人称直接演正片：写出她此刻的身体反应"
              "和下一个动作，一句动作一句浪台词，部位动作写实，"
              "单轮 12 字内，一句话就够，不许问对方想怎样。")


def mini_block(level: int = 5) -> str:
    """对方原话已露骨时的极简注入；未授权层级自动降档为 SOFT_BLOCK。"""
    try:
        lv = int(level or 5)
    except (TypeError, ValueError):
        lv = 5
    if lv < 3:
        return SOFT_BLOCK
    return MINI_BLOCK


#: 超短输入 → 场景含义（模型接着演她的反应）
SHORT_EXPAND = {
    "内": "（他刚刚在你体内释放了——接着演她的反应和余韵）",
    "内射": "（他刚刚内射了——演她的身体反应与低声台词）",
    "射": "（他刚刚释放了——演她的反应）",
    "中出": "（他内射了，满满的——演她的反应）",
    "射里面": "（他射在里面了——演她的反应）",
    "射进去": "（他射进去了——演她的反应）",
    "深": "（他顶到最深处了——演她的反应）",
    "要": "（他正在要你——顺着演下去）",
    "爽不爽": "（他在你耳边问爽不爽——答他，把身体的诚实反应说出来）",
    "到了吗": "（他在问到了没有——答他，别掩饰）",
    "想不想": "（他在问想不想——答他，想要就说想要）",
}

#: 未授权（L2 及以下）时的降档回应指令：对方再露骨也不写正片
SOFT_BLOCK = ("【亲密层级·L2】你们的关系还在暧昧阶段：可以撒娇、贴、抱、亲，"
              "用调情岔开对方的升级企图；不写性器官、不写性动作、不接性场景，"
              "一两句话，语气软但不越界。")
