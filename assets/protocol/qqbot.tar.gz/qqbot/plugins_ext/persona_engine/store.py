"""persona_engine store — 统一状态持久化（SQLite）。

表设计（与规范 13 节对应）：
  states       全局状态键值（personality.* / emotions.* / motives.* / adult.*）
  members      每成员关系档案（与情绪分离，带来源/置信度/有效期）
  events       事件流水（触发标签，不写完整推理过程）
  mood_log     情绪快照（低频，用于连续性与调试）
"""

from __future__ import annotations

import json
import sqlite3
import time
from pathlib import Path
from typing import Any

SCHEMA = """
CREATE TABLE IF NOT EXISTS states(
  key TEXT PRIMARY KEY,
  value REAL NOT NULL,
  updated_at REAL,
  confidence REAL DEFAULT 1.0,
  source TEXT DEFAULT ''
);
CREATE TABLE IF NOT EXISTS members(
  user_id INTEGER PRIMARY KEY,
  name TEXT DEFAULT '',
  familiarity REAL DEFAULT 0,
  trust REAL DEFAULT 0,
  rapport REAL DEFAULT 0,
  tone_hint TEXT DEFAULT '',          -- 关系语气提示（称呼/相处方式）
  preferences TEXT DEFAULT '',        -- 已确认偏好（JSON 数组）
  boundaries TEXT DEFAULT '',         -- 已明确边界（JSON）
  adult_boundary TEXT DEFAULT 'unknown',  -- accepted / refused / unknown
  source TEXT DEFAULT 'interaction',
  confidence REAL DEFAULT 0.3,
  events TEXT DEFAULT '',             -- 最近重要事件（JSON 数组，带时间）
  updated_at REAL,
  ttl_days INTEGER DEFAULT 90
);
CREATE TABLE IF NOT EXISTS events(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ts REAL,
  kind TEXT,          -- intent / emotion / relation / adult / boundary
  user_id INTEGER DEFAULT 0,
  tag TEXT DEFAULT '',
  detail TEXT DEFAULT ''
);
CREATE INDEX IF NOT EXISTS idx_events_ts ON events(ts);
"""



def safe_commit(conn) -> None:
    """并发协程共用连接时，可能出现「无活动事务」——静默跳过。"""
    try:
        safe_commit(conn)
    except Exception:  # noqa: BLE001
        pass


def connect(path: Path) -> sqlite3.Connection:
    conn = sqlite3.connect(str(path), check_same_thread=False, timeout=30)
    conn.row_factory = sqlite3.Row
    try:
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA busy_timeout=30000")
    except Exception:  # noqa: BLE001
        pass
    return conn


def ensure_schema(conn: sqlite3.Connection, defaults: dict[str, float]) -> None:
    conn.executescript(SCHEMA)
    now = time.time()
    for key, value in defaults.items():
        conn.execute(
            "INSERT OR IGNORE INTO states(key, value, updated_at, confidence, source)"
            " VALUES(?,?,?,1.0,'default')", (key, float(value), now))
    safe_commit(conn)


# ---------------- states ----------------

def get_states(conn: sqlite3.Connection) -> dict[str, float]:
    return {r["key"]: float(r["value"])
            for r in conn.execute("SELECT key, value FROM states")}


def set_state(conn: sqlite3.Connection, key: str, value: float,
              confidence: float = 1.0, source: str = "") -> None:
    conn.execute(
        "INSERT INTO states(key, value, updated_at, confidence, source)"
        " VALUES(?,?,?,?,?) ON CONFLICT(key) DO UPDATE SET value=?,"
        " updated_at=?, confidence=?, source=?",
        (key, float(value), time.time(), confidence, source,
         float(value), time.time(), confidence, source))
    safe_commit(conn)


def log_event(conn: sqlite3.Connection, kind: str, user_id: int = 0,
              tag: str = "", detail: str = "") -> None:
    conn.execute(
        "INSERT INTO events(ts, kind, user_id, tag, detail) VALUES(?,?,?,?,?)",
        (time.time(), kind, int(user_id), tag, detail[:200]))
    safe_commit(conn)


# ---------------- members ----------------

def get_member(conn: sqlite3.Connection, user_id: int) -> dict[str, Any]:
    row = conn.execute("SELECT * FROM members WHERE user_id=?",
                       (int(user_id),)).fetchone()
    if row is None:
        return {}
    m = dict(row)
    for k in ("preferences", "boundaries", "events"):
        try:
            m[k] = json.loads(m.get(k) or "[]")
        except Exception:
            m[k] = []
    return m


def upsert_member(conn: sqlite3.Connection, user_id: int, **fields: Any) -> None:
    cur = get_member(conn, user_id)
    if not cur:
        conn.execute("INSERT INTO members(user_id, updated_at) VALUES(?,?)",
                     (int(user_id), time.time()))
        cur = get_member(conn, user_id)
    sets, vals = [], []
    for k, v in fields.items():
        if k in ("preferences", "boundaries", "events") and not isinstance(v, str):
            v = json.dumps(v, ensure_ascii=False)
        sets.append(f"{k}=?")
        vals.append(v)
    sets.append("updated_at=?")
    vals.append(time.time())
    vals.append(int(user_id))
    conn.execute(f"UPDATE members SET {','.join(sets)} WHERE user_id=?", vals)
    safe_commit(conn)


def add_member_event(conn: sqlite3.Connection, user_id: int, tag: str,
                     detail: str = "", keep: int = 8) -> None:
    m = get_member(conn, user_id)
    events = m.get("events") or []
    events.append({"t": time.time(), "tag": tag, "d": detail[:80]})
    events = events[-keep:]
    upsert_member(conn, user_id, events=events)


def expire_members(conn: sqlite3.Connection) -> int:
    """过期档案降权（不删除证据，只降低置信度并收缩熟悉度）。"""
    now = time.time()
    n = 0
    for r in conn.execute("SELECT user_id, updated_at, ttl_days, confidence"
                          " FROM members").fetchall():
        age_days = (now - float(r["updated_at"] or 0)) / 86400
        if age_days > int(r["ttl_days"] or 90):
            c = max(0.1, float(r["confidence"] or 0.3) * 0.8)
            conn.execute("UPDATE members SET confidence=? WHERE user_id=?",
                         (c, r["user_id"]))
            n += 1
    safe_commit(conn)
    return n
