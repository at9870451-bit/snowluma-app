"""persona — 人格核心：10 维稳定人格 + 角色卡解析。

人格只决定长期倾向，不随单条消息改变（规范三）。
角色卡关键词启发式解析（置信度低，仅作初值提示），配置可覆盖。
"""

from __future__ import annotations

import re
from dataclasses import dataclass, asdict

DIMS = {
    "outgoing": ("外向程度", 60.0),
    "social_initiative": ("社交主动性", 55.0),
    "humor": ("幽默程度", 65.0),
    "expressiveness": ("情绪表达度", 60.0),
    "directness": ("直接程度", 55.0),
    "curiosity": ("好奇程度", 70.0),
    "independence": ("独立程度", 65.0),
    "affection": ("亲密倾向", 55.0),
    "conflict_tolerance": ("冲突容忍度", 50.0),
    "reserve": ("表达节制度", 55.0),
}

# 角色卡关键词 → 维度增量（每命中一次）
CARD_HINTS = {
    "活泼": {"outgoing": 12, "humor": 8},
    "开朗": {"outgoing": 10, "expressiveness": 8},
    "热情": {"expressiveness": 8, "affection": 6},
    "傲娇": {"independence": 10, "directness": 6, "affection": -4},
    "毒舌": {"directness": 10, "humor": 8, "conflict_tolerance": -5},
    "温柔": {"affection": 10, "expressiveness": 4, "reserve": -4},
    "话痨": {"outgoing": 10, "expressiveness": 10, "reserve": -10},
    "高冷": {"outgoing": -12, "expressiveness": -10, "reserve": 8},
    "理性": {"directness": 6, "reserve": 5, "expressiveness": -5},
    "好奇": {"curiosity": 10},
    "爱开玩笑": {"humor": 10},
    "安静": {"outgoing": -10, "reserve": 6},
}


@dataclass
class Personality:
    outgoing: float = 60
    social_initiative: float = 55
    humor: float = 65
    expressiveness: float = 60
    directness: float = 55
    curiosity: float = 70
    independence: float = 65
    affection: float = 55
    conflict_tolerance: float = 50
    reserve: float = 55

    def to_dict(self) -> dict[str, float]:
        return asdict(self)

    def clamp(self) -> "Personality":
        for k in DIMS:
            setattr(self, k, max(0.0, min(100.0, float(getattr(self, k)))))
        return self

    def summary(self) -> str:
        """一句话人格摘要（注入用，≤20 字）。"""
        tags = []
        if self.humor >= 70: tags.append("爱玩梗")
        if self.outgoing >= 70: tags.append("主动")
        elif self.outgoing <= 35: tags.append("内敛")
        if self.directness >= 70: tags.append("直爽")
        elif self.directness <= 35: tags.append("含蓄")
        if self.affection >= 70: tags.append("黏人")
        if self.reserve >= 70: tags.append("话少")
        elif self.reserve <= 30: tags.append("话多")
        return "·".join(tags) or "普通"


def load_from_card(card: str, base: Personality | None = None) -> Personality:
    """从角色卡文本解析人格初值（配置覆盖优先于此）。"""
    p = base or Personality()
    text = card or ""
    for word, deltas in CARD_HINTS.items():
        if word in text:
            for dim, dv in deltas.items():
                setattr(p, dim, getattr(p, dim) + dv)
    return p.clamp()


def from_config(cfg: dict, card: str = "") -> Personality:
    p = load_from_card(card)
    for dim in DIMS:
        key = f"persona_{dim}"
        if key in cfg and cfg[key] is not None:
            setattr(p, dim, float(cfg[key]))
    return p.clamp()


def behavior_bias(p: Personality) -> dict[str, float]:
    """人格 → 注入用的行为偏向（规范三/十）。"""
    return {
        "reply_len": 1.0 + (p.reserve - 55) / 100.0,      # 节制度高→短
        "humor_chance": p.humor / 100.0,
        "initiative": p.social_initiative / 100.0,
        "openness": p.outgoing / 100.0,
        "tolerance": p.conflict_tolerance / 100.0,
        "affection_tone": p.affection / 100.0,
    }
