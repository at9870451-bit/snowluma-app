"""motives — 六欲动机：求知/表达/社交/亲近/新奇/自主。

动机决定「为什么想行动」，状态 0~100，向动态目标缓慢回归（规范五）：
  - 求知：问句 +3，目标 55
  - 表达：自己每说一句 -1.5，目标 50
  - 社交：群消息活跃 +0.4（封顶 85），自己说话 -0.5，目标 45
  - 亲近：熟人倾诉/关心 +2，目标随关系升温（30~70）
  - 新奇：玩笑/新话题 +2，目标 55
  - 自主：由人格决定基线（independence），拒绝附和时 +1，几乎不衰减
"""

from __future__ import annotations

BASE = {"curiosity": 55.0, "expression": 50.0, "social": 45.0,
        "closeness": 30.0, "novelty": 55.0, "autonomy": 65.0}

NAMES = {"curiosity": "求知", "expression": "表达", "social": "社交",
         "closeness": "亲近", "novelty": "新奇", "autonomy": "自主"}

# 意图 → 动机增量
INTENT_MOTIVE = {
    "question": {"curiosity": 4, "expression": 1},
    "joke": {"novelty": 3, "social": 1},
    "tease": {"novelty": 2, "social": 1},
    "confide": {"closeness": 3, "social": 1},
    "invite": {"social": 4, "closeness": 2},
    "praise": {"expression": 1, "closeness": 1},
    "argument": {"autonomy": 2, "expression": 2},
    "chat": {"social": 0.6},
}


def update(states: dict[str, float], main_intent: str, *,
           familiar: float = 0.0, independence: float = 65.0) -> None:
    for k, dv in INTENT_MOTIVE.get(main_intent, {}).items():
        states[f"mot.{k}"] = max(0.0, min(100.0, states.get(f"mot.{k}", BASE[k]) + dv))
    # 亲近目标随熟悉度升高
    target = 25.0 + familiar * 0.45
    cur = states.get("mot.closeness", BASE["closeness"])
    states["mot.closeness"] = cur + (target - cur) * 0.3
    states["mot.autonomy"] = max(
        states.get("mot.autonomy", BASE["autonomy"]),
        independence * 0.9)


def on_self_send(states: dict[str, float]) -> None:
    """自己发出一条消息：表达欲消耗、社交欲略降。"""
    states["mot.expression"] = max(0.0, states.get("mot.expression", 50) - 1.5)
    states["mot.social"] = max(0.0, states.get("mot.social", 45) - 0.5)


def decay(states: dict[str, float], rate: float = 0.06) -> None:
    for k, base in BASE.items():
        cur = states.get(f"mot.{k}", base)
        states[f"mot.{k}"] = cur + (base - cur) * rate


def notes(states: dict[str, float], limit: int = 2) -> list[str]:
    """动机 → 行为提示（最多两条）。"""
    out = []
    e = states.get("mot.expression", 50)
    s = states.get("mot.social", 45)
    c = states.get("mot.closeness", 30)
    n = states.get("mot.novelty", 55)
    if e >= 70: out.append("想说话（可以多聊两句）")
    elif e <= 20: out.append("不太想打字（回短点）")
    if s <= 25: out.append("懒得掺和")
    if c >= 60: out.append("想找人唠")
    if n >= 70: out.append("想听新鲜事")
    return out[:limit]
