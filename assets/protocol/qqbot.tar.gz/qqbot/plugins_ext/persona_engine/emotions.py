"""emotions — 七情系统：细分状态 + 多情绪共存 + 衰减 + 冲突处理。

7 大情绪各带细分状态（愉悦/开心/惊喜/兴奋/满足/得意…），
数值 0~100，向基线衰减，强度决定细分标签（规范四/七）。
"""

from __future__ import annotations

from dataclasses import dataclass

# 七情基线
BASE = {"joy": 20.0, "anger": 4.0, "sadness": 8.0, "fear": 5.0,
        "affection": 25.0, "disgust": 4.0, "anticipation": 30.0}

NAMES = {"joy": "喜", "anger": "怒", "sadness": "哀", "fear": "惧",
         "affection": "爱", "disgust": "恶", "anticipation": "欲"}

# 细分状态（按强度区间 + 触发类型）
SUBTYPES: dict[str, list[tuple[float, str]]] = {
    "joy": [(110, "兴奋"), (75, "惊喜"), (55, "开心"), (30, "愉悦")],
    "anger": [(85, "愤怒"), (60, "恼火"), (0, "不满")],
    "sadness": [(75, "悲伤"), (55, "难过"), (30, "失落"), (0, "遗憾")],
    "fear": [(60, "紧张"), (0, "谨慎")],
    "affection": [(75, "依恋"), (55, "亲近"), (30, "好感"), (0, "友善")],
    "disgust": [(60, "反感"), (0, "嫌弃")],
    "anticipation": [(70, "期待"), (0, "有点想")],
}

# 每种情绪的衰减速率（每拍向基线回归比例）——重要事件更持久
DECAY = {"joy": 0.10, "anger": 0.12, "sadness": 0.05, "fear": 0.10,
         "affection": 0.02, "disgust": 0.08, "anticipation": 0.12}


def subtype(emotion: str, value: float) -> str:
    for threshold, label in SUBTYPES.get(emotion, []):
        if value < threshold:
            return label
    return ""


def describe(states: dict[str, float], top_n: int = 2) -> list[tuple[str, str, float]]:
    """返回 [(情绪名, 细分, 强度)]，按超出基线幅度排序，取前 N。"""
    scored = []
    for key, base in BASE.items():
        v = states.get(f"emotion.{key}", base)
        scored.append((v - base, key, v))
    scored.sort(reverse=True)
    out = []
    for ex, key, v in scored[:top_n]:
        if ex <= 3:
            continue
        out.append((NAMES[key], subtype(key, v), v))
    return out


def mood_label(states: dict[str, float]) -> str:
    d = describe(states, 2)
    if not d:
        return "平静"
    main, sub, _ = d[0]
    if sub and sub != main:
        return f"{main}（{sub}）"
    return main


def apply_event(states: dict[str, float], key: str, delta: float,
                *, cap: float = 100.0) -> float:
    cur = states.get(f"emotion.{key}", BASE[key])
    new = max(0.0, min(cap, cur + delta))
    states[f"emotion.{key}"] = new
    return new


def decay(states: dict[str, float], strength: float = 1.0) -> dict[str, float]:
    """每拍向基线回归（不同情绪速率不同）；返回更新后的 states。"""
    for key, base in BASE.items():
        k = f"emotion.{key}"
        cur = states.get(k, base)
        rate = DECAY[key] * strength
        new = cur + (base - cur) * rate
        states[k] = max(0.0, min(100.0, new))
    return states


def conflict_note(states: dict[str, float]) -> str:
    """多情绪共存提示（规范七-3）：返回简短冲突说明，无冲突为空。"""
    v = {k: states.get(f"emotion.{k}", b) for k, b in BASE.items()}
    notes = []
    if v["joy"] > 55 and v["anger"] > 45:
        notes.append("又高兴又有点火，嘴上不饶人")
    if v["sadness"] > 55 and v["affection"] > 55:
        notes.append("难过但也想被安慰")
    if v["anger"] > 50 and v["affection"] > 60:
        notes.append("生气但还在乎，别把话说绝")
    if v["fear"] > 45 and v["anticipation"] > 60:
        notes.append("紧张又期待")
    return "；".join(notes[:1])
