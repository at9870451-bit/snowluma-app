"""QQBot PersonaEngine 人格情感引擎 v2.0.0

把「人格、七情、六欲、关系认知、成人情感、行为选择」统一成一个状态机，
嵌入回复流水线（规范十二）：

  on_message → 消息解析(intent) → 关系读取 → 情绪更新(七情)
            → 动机更新(六欲) → 边界检查(成人) → 行为选择(behavior)
            → [style_hooks 注入] → 模型生成

模块：
  persona.py    人格核心（10 维 + 角色卡解析）
  emotions.py   七情（细分状态/多情绪共存/衰减/冲突）
  motives.py    六欲（求知/表达/社交/亲近/新奇/自主）
  intent.py     意图识别（规则式、多意图、置信度）
  relationship.py 关系认知（熟悉/信任/默契，与情绪分离）
  adult.py      成人情感（默认关闭、5 层、边界状态、拒绝即停）
  behavior.py   行为选择（答/接梗/解释/安慰/拒绝/沉默 + 长度）

指令：/mood（状态）｜关系 <QQ>｜人格 [设置 <维度> <值>]｜成人 on|off｜详情｜设置 <情绪> <值>｜重置
"""

from __future__ import annotations

import asyncio
import json
import time
from typing import Any
from pathlib import Path

from qqbot.plugins.base import Plugin

from . import adult, behavior, emotions, intent, motives, persona, relationship, store

DERIVED_DEFAULTS = {
    **{f"emotion.{k}": v for k, v in emotions.BASE.items()},
    **{f"mot.{k}": v for k, v in motives.BASE.items()},
    **{f"adult.{k}": v for k, v in adult.VARS.items()},
    "adult.enabled": 0.0,
}


class PersonaEnginePlugin(Plugin):
    name = "persona_engine"
    display_name = "人格情感引擎"
    version = "2.0.0"
    description = ("人格10维+七情细分+六欲动机+关系认知+成人情感(默认关)+行为选择，"
                   "统一状态注入回复")
    priority = 16

    default_config = {
        "enabled": True,
        "tick_seconds": 300,
        "emotion_decay_scale": 1.0,
        "inject_enabled": True,
        "inject_max_chars": 260,
        "master_bonus": 1.5,
        "spam_cooldown": 10,
        "poke_annoy_count": 3,
        "persona_adult": False,
        "adult_enabled": False,
        "adult_max_level": 3,
        "adult_force_level": 0,
        "adult_prompt_enabled": True,
        "adult_prompt_max_chars": 760,
        "adult_voice_enabled": True,
        "adult_voice_min_level": 2,
        "adult_voice_guidance_scale": 5.5,
    }

    config_labels = {
        "enabled": "启用人格情感引擎",
        "inject_enabled": "状态注入回复",
        "emotion_decay_scale": "情绪衰减速度",
        "persona_adult": "角色已设定为成年人",
        "adult_enabled": "成人情感模块（需角色成年）",
        "adult_max_level": "成人表达上限层次 1-5",
        "adult_force_level": "强制层级 0=按互动自动升温，1-5 直接锁死",
        "adult_prompt_enabled": "注入极彩欲望执行指令",
        "adult_prompt_max_chars": "极彩指令字数预算",
        "adult_voice_enabled": "成人回复强制发语音",
        "adult_voice_min_level": "发语音的最低层级",
        "adult_voice_guidance_scale": "Breeze 表演指令强度",
    }

    def __init__(self, bot) -> None:
        super().__init__(bot)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self._conn = store.connect(self.data_dir / "persona.sqlite3")
        self._states: dict[str, float] = {}
        self._saved: dict[str, float] = {}
        self._persona: persona.Personality | None = None
        self._last_hit: dict[tuple[int, str], float] = {}
        self._poke_times: dict[int, list[float]] = {}
        self._tick_task: asyncio.Task | None = None
        self._orig_send_group = None
        self._orig_send_private = None

    async def on_load(self) -> None:
        if not self.cfg_get("enabled", True):
            return
        card = ""
        try:
            ai = self.bot.config.ai
            card = str(getattr(ai, "system_prompt", "") or "")
        except Exception:
            pass
        self._persona = persona.from_config(dict(self.cfg), card)
        defaults = {**DERIVED_DEFAULTS,
                    **{f"personality.{k}": v
                       for k, v in self._persona.to_dict().items()}}
        store.ensure_schema(self._conn, defaults)
        self._states = store.get_states(self._conn)
        self._saved = dict(self._states)

        hooks = getattr(self.bot, "style_hooks", None)
        if hooks is None:
            hooks = []
            self.bot.style_hooks = hooks
        if self.mood_injection not in hooks:
            hooks.append(self.mood_injection)
        try:
            self.bot.persona_engine = self
        except Exception:  # noqa: BLE001
            pass
        self.add_command("mood", self._cmd, aliases=("情感", "心情", "人格"),
                         admin=True, description="人格情感：状态/关系/人格/成人/设置")
        self._wrap_send()
        self._tick_task = asyncio.get_running_loop().create_task(self._tick_loop())
        self.log.info("人格情感引擎已启用（人格=%s，成人模块=%s）",
                      self._persona.summary(),
                      "开" if self._adult_on() else "关")

    async def on_unload(self) -> None:
        if self._tick_task:
            self._tick_task.cancel()
        hooks = getattr(self.bot, "style_hooks", None)
        if hooks and self.mood_injection in hooks:
            hooks.remove(self.mood_injection)
        self._unwrap_send()
        self._flush()

    # ---------------- 状态存取 ----------------

    def _flush(self) -> None:
        for k, v in self._states.items():
            if abs(self._saved.get(k, 1e9) - v) > 0.01:
                store.set_state(self._conn, k, v)
                self._saved[k] = v

    def _adult_on(self) -> bool:
        return bool(self.cfg_get("adult_enabled", False)
                    and self.cfg_get("persona_adult", False)
                    and self._states.get("adult.enabled", 0) >= 1)

    # ---------------- 消息入口 ----------------

    async def on_message(self, ctx) -> Any:
        if not self.cfg_get("enabled", True):
            return None
        m = self._norm(ctx)
        if not m["text"] and not m["has_image"]:
            return None
        uid = m["user_id"]
        now = time.time()
        it = intent.analyze(m["text"], is_at_me=m["at_me"],
                            is_reply_me=m["is_reply"],
                            has_image=m["has_image"])
        main = it["main"]

        cd = max(2, int(self.cfg_get("spam_cooldown", 10)))
        key = (uid, main)
        if now - self._last_hit.get(key, 0) >= cd:
            self._last_hit[key] = now
            conf = it["confidence"]
            boost = float(self.cfg_get("master_bonus", 1.5)) \
                if self._is_master(uid) else 1.0
            for emo_key, dv in intent.INTENT_EMOTION.get(main, {}).items():
                emotions.apply_event(self._states, emo_key, dv * conf * boost)

            member = relationship.apply(self._conn, uid, main,
                                        is_group=m["is_group"])

            if self._adult_on():
                if adult.is_refusal(m["text"]):
                    adult.set_boundary(self._conn, uid, "refused")
                    adult.update(self._states, adult_on=True,
                                 adult_context=False, refusal=True)
                    store.log_event(self._conn, "boundary", uid, "refused")
                elif adult.is_adult_context(m["text"]):
                    adult.update(self._states, adult_on=True,
                                 adult_context=True, refusal=False)
            else:
                adult.update(self._states, adult_on=False,
                             adult_context=False, refusal=False)

            motives.update(self._states, main,
                           familiar=float(member.get("familiarity", 0) or 0),
                           independence=self._persona.independence)
            store.log_event(self._conn, "intent", uid, it["main_label"],
                            ";".join(intent.LABELS.get(n, n)
                                     for n, _ in it["intents"][:3]))
            self._flush()
        return None

    async def on_notice(self, event) -> Any:
        """戳一戳：社交事件，按频率和关系变化反应。"""
        if not self.cfg_get("enabled", True):
            return None
        try:
            if str(event.get("sub_type") or "") != "poke":
                return None
            uid = int(getattr(event, "user_id", 0)
                      or (event.get("user_id") if hasattr(event, "get") else 0)
                      or 0)
            if not uid or uid == getattr(self.bot, "self_id", 0):
                return None
            now = time.time()
            times = [t for t in self._poke_times.get(uid, []) if now - t < 60]
            times.append(now)
            self._poke_times[uid] = times
            n = len(times)
            relationship.apply(self._conn, uid, "poke")
            emotions.apply_event(self._states, "anticipation", 3)
            if n >= int(self.cfg_get("poke_annoy_count", 3)):
                emotions.apply_event(self._states, "anger", 5 if n == 3 else 2)
                store.log_event(self._conn, "emotion", uid, "poke_annoy",
                                f"{n}次/分钟")
            self._flush()
        except Exception as exc:  # noqa: BLE001
            self.log.debug("戳一戳处理失败: %s", exc)
        return None

    # ---------------- 注入 ----------------

    async def mood_injection(self, ctx, prompt: str) -> str:
        if not self.cfg_get("inject_enabled", True) or self._persona is None:
            return ""
        try:
            m = self._norm(ctx)
            uid = m["user_id"]
            adult_lvl, adult_cap = 0, 0
            it = intent.analyze(m["text"], is_at_me=m["at_me"],
                                is_reply_me=m["is_reply"],
                                has_image=m["has_image"])
            member = store.get_member(self._conn, uid) if uid else {}
            emo_desc = emotions.describe(self._states, 2)
            mood = " + ".join(f"{n}{('·' + s) if s and s != n else ''}"
                              for n, s, _ in emo_desc) or "平静"
            plan = behavior.choose(
                main_intent=it["main"], emotions=self._states,
                personality=self._persona, member=member,
                at_me=it["at_me"], is_group=m["is_group"])
            lines = [f"【人格情感】心情：{mood}",
                     f"策略：{plan['behavior']}，{behavior.length_hint(plan['max_chars'])}"
                     + (f"；{plan['note']}" if plan["note"] else "")]
            if uid:
                lines.append("对TA：" + relationship.relation_summary(member))
            conflict = emotions.conflict_note(self._states)
            if conflict:
                lines.append("注意：" + conflict)
            mn = motives.notes(self._states)
            if mn:
                lines.append("动机：" + "；".join(mn))
            if self._adult_on():
                cap = max(1, min(5, int(self.cfg_get("adult_max_level", 5))))
                scope_lvl = self._level_for_ctx(m)
                # —— 权限收紧：只有 override（主人 /mood 设置）才可 L3+ ——
                uid0 = int(m.get("user_id") or 0)
                if not self._is_master(uid0):
                    lv = self._levels_load()
                    over = lv.get("overrides") or {}
                    key = ("group:" + str(m.get("group_id"))) \
                        if m.get("is_group") else ("user:" + str(uid0))
                    if key not in over:
                        scope_lvl = min(scope_lvl, 2)  # 无授权 → 硬顶 L2
                # —— 自动回复（随机接话/短应答）也要检测授权 ——
                if getattr(getattr(ctx, "event", ctx), "_auto_random", False):
                    if not self._is_master(uid0):
                        d0 = self._levels_load()
                        o0 = d0.get("overrides") or {}
                        k0 = ("group:" + str(m.get("group_id"))) \
                            if m.get("is_group") else ("user:" + str(uid0))
                        if k0 not in o0:
                            scope_lvl = 0  # 未授权 → 随机接话零成人内容
                adult_cap = cap
                adult_lvl = max(0, min(scope_lvl, cap))
                # 边界拒绝 → 降到 L1（安全闸）；主人豁免，否则一次误判会把他永久钉死
                if (adult_lvl and adult.boundary_of(member) == "refused"
                        and not (self.cfg_get("adult_boundary_master_exempt", True)
                                 and self._is_master(int(m.get("user_id") or 0)))):
                    adult_lvl = 1
                if adult_lvl:
                    lines.append(adult.summary(self._states, member, adult_on=True)
                                 + f"（当前{adult_lvl}层/上限{cap}层）")
            n_poke = len([t for t in self._poke_times.get(uid, [])
                          if time.time() - t < 60])
            if n_poke >= 3:
                lines.append("（TA 一分钟内戳了你 %d 次，表现点不耐烦）" % n_poke)
            out = "\n".join(lines)[:int(self.cfg_get("inject_max_chars", 260))]
            _tl = self._time_line()
            if _tl:
                out = _tl + "\n" + out
            self._adult_voice_sync(ctx, member, adult_lvl, adult_cap)
            if adult_lvl and self.cfg_get("adult_prompt_enabled", True):
                # 未授权（L2 及以下）：统一给降档指令，不给任何正片措辞
                if adult_lvl <= 2:
                    blk = adult.SOFT_BLOCK
                elif adult.is_erotic(m.get("text") or ""):
                    blk = adult.mini_block(adult_lvl)
                else:
                    blk = adult.prompt_block(
                        self._states, member, level=adult_lvl, cap=adult_cap,
                        max_chars=int(self.cfg_get("adult_prompt_max_chars", 760)))
                if blk:
                    out = (out + "\n" + blk).strip()
                # 单字/短词（内/射/内射…）自动补场景，模型才知道接着演什么
                short = adult.SHORT_EXPAND.get((m.get("text") or "").strip())
                if short:
                    out = (out + "\n" + short).strip()
            return out
        except Exception as exc:  # noqa: BLE001
            self.log.debug("人格注入失败: %s", exc)
            return ""

    def _adult_voice_sync(self, ctx, member, lvl: int, cap: int) -> None:
        """把成人层级的 TTS 表演指令挂到 bot 上（role_tts 读取并写进 Breeze）。"""
        try:
            if (not lvl) or (not self.cfg_get("adult_voice_enabled", True)):
                self.bot.adult_voice_hint = None
                return
            uid = 0
            try:
                uid = self._norm(ctx).get("user_id") or 0
            except Exception:
                uid = 0
            self.bot.adult_voice_hint = adult.voice_hint(
                self._states, member, level=lvl, cap=cap,
                guidance=float(self.cfg_get("adult_voice_guidance_scale", 5.5)),
                uid=uid, ts=time.time())
        except Exception as exc:  # noqa: BLE001
            self.log.debug("成人语音指令挂载失败: %s", exc)

    async def _demo_voice(self, ctx, lvl: int) -> None:
        """调完层级立刻发一条该层的示例语音（主人当场听到）。"""
        try:
            seg_fn = getattr(self.bot, "voice_segment", None)
            if seg_fn is None:
                return
            m = self._norm(ctx)
            uid = m.get("user_id") or 0
            member = store.get_member(self._conn, uid) if uid else {}
            self.bot.adult_voice_hint = adult.voice_hint(
                self._states, member, level=lvl, cap=5,
                guidance=float(self.cfg_get("adult_voice_guidance_scale", 5.5)),
                uid=uid, ts=time.time())
            seg = await seg_fn(adult.demo_line(lvl))
            if seg is None:
                return
            try:
                from qqbot.core.message import Message
                await ctx.send(Message([seg]))
            except Exception:
                await ctx.reply("（示例语音合成成功，但发送失败）")
        except Exception as exc:  # noqa: BLE001
            self.log.debug("成人示例语音发送失败: %s", exc)

    # ---------------- 时间感 ----------------

    @staticmethod
    def _period_of(hour: int) -> str:
        if hour < 5:
            return "凌晨"
        if hour < 9:
            return "早上"
        if hour < 11:
            return "上午"
        if hour < 13:
            return "中午"
        if hour < 18:
            return "下午"
        if hour < 19:
            return "傍晚"
        if hour < 23:
            return "晚上"
        return "深夜"

    def _time_line(self) -> str:
        """当前时间（24h + 12h + 时段），并教它怎么读别人嘴里的「四点」。"""
        try:
            now = time.localtime()
            h, mi = int(now.tm_hour), int(now.tm_min)
            week = "一二三四五六日"[int(now.tm_wday)]
            period = self._period_of(h)
            h12 = h % 12 or 12
            ampm = "AM" if h < 12 else "PM"
            return (
                f"【现在】{now.tm_year}-{now.tm_mon:02d}-{now.tm_mday:02d} "
                f"{h:02d}:{mi:02d} 周{week}｜{period}"
                f"｜24小时制 {h:02d}:{mi:02d}｜12小时制 {h12}:{mi:02d} {ampm}"
                "\n说时间一律以上面为准；别人说「N点」先看时段再答，"
                "下午四点别当成凌晨四点，半夜就说半夜。"
            )
        except Exception:  # noqa: BLE001
            return ""

    # ---------------- 分层级（按对象/场景） ----------------

    def _levels_path(self):
        d = getattr(self, "data_dir", None)
        base = Path(d) if d else Path("/opt/qqbot/data/persona_engine")
        base.mkdir(parents=True, exist_ok=True)
        return base / "adult_levels.json"

    def _levels_load(self) -> dict:
        p = self._levels_path()
        try:
            d = json.loads(p.read_text("utf-8"))
            if not isinstance(d, dict):
                d = {}
        except Exception:
            d = {}
        d.setdefault("defaults", {})
        for k, v in (("master", 5), ("user", 1), ("group", 1)):
            d["defaults"].setdefault(k, v)
        d.setdefault("overrides", {})
        return d

    def _levels_save(self, d: dict) -> None:
        try:
            self._levels_path().write_text(
                json.dumps(d, ensure_ascii=False, indent=1), "utf-8")
        except Exception as exc:  # noqa: BLE001
            self.log.debug("层级表写入失败: %s", exc)

    @staticmethod
    def _lv_clamp(v, default: int = 1) -> int:
        try:
            n = int(v)
        except (TypeError, ValueError):
            n = int(default)
        return max(0, min(5, n))

    def _level_for_ctx(self, m: dict) -> int:
        """按场景取层级：主人私聊默认 5，其他人/群默认 1，override 优先。"""
        d = self._levels_load()
        over = d.get("overrides") or {}
        if m.get("is_group"):
            gid = str(m.get("group_id") or 0)
            if ("group:" + gid) in over:
                return self._lv_clamp(over["group:" + gid], 1)
            return self._lv_clamp(d["defaults"].get("group", 1), 1)
        uid = int(m.get("user_id") or 0)
        if ("user:" + str(uid)) in over:
            return self._lv_clamp(over["user:" + str(uid)], 1)
        if self._is_master(uid):
            forced = self._lv_clamp(self.cfg_get("adult_force_level", 0), 0)
            if 1 <= forced <= 5:
                return forced
            return self._lv_clamp(d["defaults"].get("master", 5), 5)
        return self._lv_clamp(d["defaults"].get("user", 1), 1)

    def _levels_text(self, m: dict) -> str:
        d = self._levels_load()
        cur = self._level_for_ctx(m)
        where = (f"本群 {m.get('group_id')}" if m.get("is_group")
                 else f"与 {m.get('nickname') or m.get('user_id')} 的私聊")
        lines = [f"【成人层级】当前 {where}：L{cur}",
                 "默认：主人私聊 L%d · 好友私聊 L%d · 群聊 L%d"
                 % (d["defaults"]["master"], d["defaults"]["user"], d["defaults"]["group"])]
        over = d.get("overrides") or {}
        if over:
            rows = [f"  {k} → L{v}" for k, v in sorted(over.items())]
            lines.append("单独设置：")
            lines.extend(rows[:20])
        else:
            lines.append("单独设置：无")
        lines.append("用法：/mood 等级 5（本窗口）｜/mood 等级 群 <群号> 2"
                     "｜/mood 等级 好友 <QQ> 3｜/mood 等级 默认 群 1｜/mood 等级 清 <目标>")
        return "\n".join(lines)

    def _set_level(self, kind: str, ident: str, lv: int) -> str:
        d = self._levels_load()
        key = f"{kind}:{ident}"
        if lv < 0:
            d.get("overrides", {}).pop(key, None)
            self._levels_save(d)
            return f"已清除 {key} 的单独设置"
        lv = self._lv_clamp(lv, 1)
        d.setdefault("overrides", {})[key] = lv
        self._levels_save(d)
        return f"已设置 {key} → L{lv}"

    # ---------------- 节拍 ----------------

    async def _tick_loop(self) -> None:
        await asyncio.sleep(20)
        while True:
            try:
                await asyncio.to_thread(self._tick)
            except asyncio.CancelledError:
                raise
            except Exception as exc:  # noqa: BLE001
                self.log.warning("人格节拍异常: %s", exc)
            await asyncio.sleep(max(60, int(self.cfg_get("tick_seconds", 300))))

    def _tick(self) -> None:
        scale = float(self.cfg_get("emotion_decay_scale", 1.0))
        emotions.decay(self._states, strength=scale)
        motives.decay(self._states)
        if self._persona:
            cur = self._states.get("mot.autonomy", 65)
            self._states["mot.autonomy"] = cur + (
                self._persona.independence - cur) * 0.05
        store.expire_members(self._conn)
        self._flush()

    # ---------------- bot 发消息 ----------------

    def _wrap_send(self) -> None:
        self._orig_send_group = self.bot.send_group_msg
        self._orig_send_private = self.bot.send_private_msg
        plugin = self

        async def wrapped_group(gid, message, *a, **k):
            plugin._on_self_send()
            return await plugin._orig_send_group(gid, message, *a, **k)

        async def wrapped_private(uid, message, *a, **k):
            plugin._on_self_send()
            return await plugin._orig_send_private(uid, message, *a, **k)

        self.bot.send_group_msg = wrapped_group
        self.bot.send_private_msg = wrapped_private

    def _unwrap_send(self) -> None:
        try:
            if self._orig_send_group:
                self.bot.send_group_msg = self._orig_send_group
            if self._orig_send_private:
                self.bot.send_private_msg = self._orig_send_private
        except Exception:
            pass

    def _on_self_send(self) -> None:
        try:
            motives.on_self_send(self._states)
            self._flush()
        except Exception:
            pass

    # ---------------- 指令 ----------------

    async def _cmd(self, ctx, args: str) -> Any:
        a = (args or "").strip()
        head, _, rest = a.partition(" ")
        rest = rest.strip()

        if head in ("", "状态", "status"):
            await self._reply(ctx, self._status_text())
            return self.stop()

        if head in ("关系", "rel") and rest.isdigit():
            m = store.get_member(self._conn, int(rest))
            if not m:
                await self._reply(ctx, f"QQ {rest} 还没有互动档案。")
                return self.stop()
            prefs = "、".join(x for x in (m.get("preferences") or []) if x) or "无"
            await self._reply(ctx, "\n".join([
                f"【关系 · {m.get('name') or rest}】",
                f"熟悉 {m.get('familiarity', 0)} · 信任 {m.get('trust', 0)} · 默契 {m.get('rapport', 0)}",
                f"语气：{relationship.tone_for(m)}",
                f"偏好：{prefs}",
                f"边界：{m.get('adult_boundary', 'unknown')} · 置信度 {m.get('confidence', 0)}",
            ]))
            return self.stop()

        if head in ("人格",):
            if rest.startswith("设置"):
                parts = rest.split()
                if len(parts) >= 3 and parts[1] in persona.DIMS:
                    try:
                        v = max(0.0, min(100.0, float(parts[2])))
                    except ValueError:
                        v = None
                    if v is not None:
                        setattr(self._persona, parts[1], v)
                        store.set_state(self._conn, f"personality.{parts[1]}", v)
                        await self._reply(ctx, f"{persona.DIMS[parts[1]][0]} 已设为 {v:.0f}")
                        return self.stop()
                await self._reply(ctx, "用法：/mood 人格 设置 <" +
                                  "/".join(persona.DIMS) + "> <0~100>")
                return self.stop()
            if not self._persona:
                await self._reply(ctx, "引擎未初始化（enabled=false？）")
                return self.stop()
            lines = [f"【人格】{self._persona.summary()}"]
            for k, (name, _) in persona.DIMS.items():
                lines.append(f"{name}：{getattr(self._persona, k):.0f}")
            await self._reply(ctx, "\n".join(lines))
            return self.stop()

        if head in ("成人",):
            if rest in ("on", "off", "开", "关"):
                want = rest in ("on", "开")
                if want and not self.cfg_get("persona_adult", False):
                    await self._reply(ctx, "角色未声明成年（persona_adult=false），"
                                           "不能开启成人情感模块。")
                    return self.stop()
                self.cfg["adult_enabled"] = want
                self._states["adult.enabled"] = 1.0 if want else 0.0
                self.save_config()
                await self._reply(ctx, "成人情感模块已" + (
                    "开启（默认最低层次，尊重边界）。" if want else "关闭。"))
                return self.stop()
            await self._reply(ctx, f"成人模块：{'开' if self._adult_on() else '关'}"
                                   f"（/mood 成人 on|off）")
            return self.stop()

        if head in ("等级", "level", "层级"):
            r = (rest or "").strip()
            m0 = self._norm(ctx)
            if not r:
                await self._reply(ctx, self._levels_text(m0))
                return self.stop()
            parts = r.split()
            # 语法：等级 <n> ｜ 等级 群 <群号> <n> ｜ 等级 好友 <QQ> <n>
            #       等级 默认 群|好友|主人 <n> ｜ 等级 清 群 <号> / 好友 <QQ> ｜ 等级 列表
            if parts[0] in ("列表", "list"):
                await self._reply(ctx, self._levels_text(m0))
                return self.stop()
            if parts[0] in ("默认", "default") and len(parts) >= 3:
                kind = {"群": "group", "好友": "user", "主人": "master",
                        "group": "group", "user": "user", "master": "master"
                        }.get(parts[1])
                if not kind:
                    await self._reply(ctx, "用法：/mood 等级 默认 群|好友|主人 <0~5>")
                    return self.stop()
                d = self._levels_load()
                d["defaults"][kind] = self._lv_clamp(parts[2], 1)
                self._levels_save(d)
                await self._reply(ctx, f"默认层级已改：{kind} → L{d['defaults'][kind]}")
                return self.stop()
            if parts[0] in ("清", "clear") and len(parts) >= 2:
                kind = {"群": "group", "好友": "user", "user": "user",
                        "group": "group"}.get(parts[1])
                ident = parts[2] if len(parts) >= 3 else (
                    str(m0.get("group_id")) if kind == "group" else str(m0.get("user_id")))
                if not kind:
                    await self._reply(ctx, "用法：/mood 等级 清 群 <群号> / 清 好友 <QQ>")
                    return self.stop()
                await self._reply(ctx, self._set_level(kind, ident, -1))
                return self.stop()
            if len(parts) >= 3 and parts[0] in ("群", "好友", "user", "group"):
                kind = "group" if parts[0] in ("群", "group") else "user"
                try:
                    n = int(parts[2])
                except ValueError:
                    n = -1
                if not (0 <= n <= 5):
                    await self._reply(ctx, "用法：/mood 等级 群 <群号> 0~5")
                    return self.stop()
                msg = self._set_level(kind, parts[1], n)
                await self._reply(ctx, msg)
                return self.stop()
            try:
                n = int(parts[0])
            except ValueError:
                n = -1
            if not (0 <= n <= 5):
                await self._reply(ctx, "用法：/mood 等级 0~5（本窗口）｜"
                                       "群 <群号> <0~5>｜好友 <QQ> <0~5>｜默认 群|好友|主人 <n>")
                return self.stop()
            if n and not self._adult_on():
                await self._reply(ctx, "成人模块未开（先 /mood 成人 on）")
                return self.stop()
            if m0.get("is_group"):
                msg = self._set_level("group", str(m0.get("group_id")), n)
            else:
                msg = self._set_level("user", str(m0.get("user_id")), n)
            await self._reply(ctx, msg + f"（当前窗口生效：L{n}）")
            if n >= 2 and not m0.get("is_group"):
                await self._reply(ctx, f"这是 L{n} 的嗓子，你听——")
                await self._demo_voice(ctx, n)
            return self.stop()

        if head in ("详情", "log"):
            rows = self._conn.execute(
                "SELECT ts, kind, user_id, tag FROM events ORDER BY id DESC LIMIT 12"
            ).fetchall()
            lines = ["【最近状态事件】（只记标签，不记推理）"]
            for r in rows:
                lines.append(f"{time.strftime('%H:%M', time.localtime(r['ts']))} "
                             f"{r['kind']} u{r['user_id']} {r['tag']}")
            await self._reply(ctx, "\n".join(lines))
            return self.stop()

        if head == "设置" and rest:
            parts = rest.split()
            if len(parts) >= 2 and parts[0] in emotions.NAMES.values():
                zh = parts[0]
                key = [k for k, v in emotions.NAMES.items() if v == zh][0]
                try:
                    v = max(0.0, min(100.0, float(parts[1])))
                except ValueError:
                    v = None
                if v is not None:
                    self._states[f"emotion.{key}"] = v
                    self._flush()
                    await self._reply(ctx, f"{zh} 已设为 {v:.0f}")
                    return self.stop()
            await self._reply(ctx, "用法：/mood 设置 <喜/怒/哀/惧/爱/恶/欲> <0~100>")
            return self.stop()

        if head == "重置":
            for k, v in DERIVED_DEFAULTS.items():
                self._states[k] = v
            self._flush()
            await self._reply(ctx, "情绪与动机已重置到基线。")
            return self.stop()

        await self._reply(ctx, "用法：/mood｜关系 <QQ>｜人格 [设置 <维度> <值>]｜"
                               "成人 on|off｜等级 0~5｜详情｜设置 <情绪> <值>｜重置")
        return self.stop()

    def _status_text(self) -> str:
        desc = emotions.describe(self._states, 3)
        emo_line = " ".join(f"{n}{('·' + s) if s and s != n else ''}{int(v)}"
                            for n, s, v in desc) or "平静"
        mot = " ".join(f"{motives.NAMES[k]}{int(self._states.get('mot.' + k, 0))}"
                       for k in motives.BASE)
        persona_line = self._persona.summary() if self._persona else "默认"
        lines = [
            f"【心情】{emotions.mood_label(self._states)}（{emo_line}）",
            f"【六欲】{mot}",
            f"【人格】{persona_line}",
        ]
        conflict = emotions.conflict_note(self._states)
        if conflict:
            lines.append(f"【并存】{conflict}")
        lines.append("【成人】" + (
            f"开（上限 {min(5, int(self.cfg_get('adult_max_level', 3)))} 层）"
            if self._adult_on() else "关（需角色成年 + /mood 成人 on）"))
        return "\n".join(lines)

    # ---------------- 工具 ----------------

    def _is_master(self, uid: int) -> bool:
        try:
            return uid in [int(a) for a in (self.bot.config.bot.admins or [])]
        except Exception:
            return False

    async def _reply(self, ctx, message: str) -> None:
        try:
            await ctx.reply(message)
        except Exception as exc:  # noqa: BLE001
            self.log.warning("回复失败: %s", exc)

    def _norm(self, ctx) -> dict[str, Any]:
        event = getattr(ctx, "event", ctx)
        sender = getattr(event, "sender", None) or {}
        try:
            uid = int(getattr(event, "user_id", 0) or 0)
        except (TypeError, ValueError):
            uid = 0
        gid = getattr(event, "group_id", None)
        try:
            gid = int(gid) if gid else None
        except (TypeError, ValueError):
            gid = None
        raw = str(getattr(event, "raw_message", "") or "")
        self_id = getattr(self.bot, "self_id", 0)
        at_me = (f"[CQ:at,qq={self_id}]" in raw) or \
            any(getattr(t, "qq", None) == self_id
                for t in (getattr(ctx, "at_targets", None) or []))
        return {
            "user_id": uid,
            "group_id": gid,
            "is_group": gid is not None,
            "text": str(getattr(event, "text", "") or "").strip(),
            "nickname": str(sender.get("card") or sender.get("nickname")
                            or uid or ""),
            "at_me": at_me,
            "is_reply": "[CQ:reply" in raw,
            "has_image": "[CQ:image" in raw,
        }
