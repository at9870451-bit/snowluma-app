"""relationship — 关系认知：熟悉/信任/默契（分成员隔离，情绪分离）。

规则（规范八）：
  - 关系只随持续互动逐渐变化，单条消息影响极小（每步上限 2 分）
  - 熟悉 0~100（越高越自然），信任 0~100（越高越开放），默契 0~100（共同话题/接梗）
  - 辱骂/越界 → 信任下降更明显；道歉 + 后续友好 → 信任缓慢回升
  - 与情绪完全分离：熟悉高 ≠ 喜欢 ≠ 接受暧昧
"""

from __future__ import annotations

from . import store

# 单次互动对关系的影响（非常保守，规范八-关系变化规则）
STEP = {
    "chat": (0.3, 0.05, 0.05),
    "joke": (0.5, 0.2, 0.6),
    "tease": (0.6, 0.1, 0.4),
    "praise": (0.4, 0.5, 0.2),
    "question": (0.3, 0.1, 0.1),
    "invite": (0.8, 0.4, 0.4),
    "confide": (1.0, 1.2, 0.4),
    "apology": (0.4, 1.0, 0.2),
    "insult": (-0.6, -2.0, -1.0),
    "reject": (0.0, -0.8, -0.4),
    "argument": (0.2, -0.6, -0.2),
    "poke": (0.5, 0.1, 0.1),
    "sticker": (0.2, 0.05, 0.3),
}
MAX_STEP = 2.0


def apply(conn, user_id: int, main_intent: str, *,
          is_group: bool = True) -> dict:
    """按意图更新关系（单条消息增量极小），返回更新后的档案。"""
    m = store.get_member(conn, user_id)
    fam = float(m.get("familiarity", 0) or 0)
    trust = float(m.get("trust", 0) or 0)
    rapport = float(m.get("rapport", 0) or 0)
    dfam, dtrust, drap = STEP.get(main_intent, (0.3, 0.05, 0.05))

    def cap(v: float) -> float:
        return max(0.0, min(100.0, v))

    fam = cap(fam + max(-MAX_STEP, min(MAX_STEP, dfam)))
    trust = cap(trust + max(-MAX_STEP, min(MAX_STEP, dtrust)))
    rap = cap(rapport + max(-MAX_STEP, min(MAX_STEP, drap)))
    conf = min(0.95, float(m.get("confidence", 0.3) or 0.3) + 0.02)
    store.upsert_member(conn, user_id, familiarity=round(fam, 2),
                        trust=round(trust, 2), rapport=round(rap, 2),
                        confidence=round(conf, 2))
    return store.get_member(conn, user_id)


def tone_for(m: dict) -> str:
    """关系 → 语气提示（注入用）。"""
    fam = float(m.get("familiarity", 0) or 0)
    trust = float(m.get("trust", 0) or 0)
    if fam >= 60 and trust >= 50:
        return "老熟人，可以随意调侃"
    if fam >= 35:
        return "聊过几次，轻松点"
    if fam >= 12:
        return "不熟，正常客气"
    if trust <= 5 and fam <= 5:
        return "陌生，先收着点"
    return "一般群友"


def relation_summary(m: dict) -> str:
    """一行关系摘要（注入用，≤28 字）。"""
    if not m:
        return "陌生"
    fam = int(m.get("familiarity", 0) or 0)
    trust = int(m.get("trust", 0) or 0)
    rap = int(m.get("rapport", 0) or 0)
    tone = tone_for(m)
    return f"{tone}(熟{fam}/信{trust}/默{rap})"
