"""behavior — 行为选择：意图 × 情绪 × 关系 × 人格 → 回复策略。

输出（规范十二-第八步）：
  behavior: 回答/接梗/解释/反问/争论/安慰/拒绝/沉默/追问/调侃
  max_chars: 目标长度（群聊短、陌生更短）
  note: 一句话策略提示（注入用）
  allow_silence: 是否允许这轮不回复（意愿门控参考）
"""

from __future__ import annotations

from .persona import Personality

# (行为, 目标字数, 提示)
def choose(*, main_intent: str, emotions: dict[str, float],
           personality: Personality, member: dict,
           at_me: bool, is_group: bool) -> dict:
    joy = emotions.get("emotion.joy", 20)
    anger = emotions.get("emotion.anger", 4)
    sad = emotions.get("emotion.sadness", 8)
    aff = emotions.get("emotion.affection", 25)
    fam = float(member.get("familiarity", 0) or 0)
    trust = float(member.get("trust", 0) or 0)

    base_len = 24 if is_group else 34
    base_len = int(base_len * (1.0 + (personality.reserve - 55) / 120.0))
    behavior, max_chars, note = "接话", base_len, ""
    allow_silence = False

    if main_intent == "reject" or main_intent == "insult":
        if personality.conflict_tolerance >= 55:
            behavior, note = "冷处理", "对方不适/敌意，简短收住，不争辩"
            max_chars = 10
            allow_silence = True
        else:
            behavior, note = "表明立场", "直说不喜欢这种说话方式，一句话，不展开"
            max_chars = 16
    elif main_intent == "confide":
        behavior = "安慰"
        note = "听着就好，别讲大道理" if fam < 40 else "熟人，可以多问一句近况"
        max_chars = 20 if fam < 40 else 30
    elif main_intent == "argument":
        if anger >= 45:
            behavior, note = "争论", "有火但讲道理，直接说观点，别阴阳"
            max_chars = 30
        else:
            behavior, note = "表达观点", "可以不同意，简短讲理由"
            max_chars = 26
    elif main_intent == "question":
        behavior, note = "回答", "先直接回答，别绕"
        max_chars = 40 if not is_group else 32
    elif main_intent == "invite":
        behavior = "回应邀请"
        note = "明确去/不去，别吊着"
    elif main_intent == "praise":
        behavior = "受用"
        note = "开心但别飘" if joy < 60 else "可以得意一下"
        max_chars = 14
    elif main_intent in ("joke", "tease"):
        if fam >= 30 or joy >= 50:
            behavior, note = "接梗", "跟着玩，可以损回去（分寸内）"
        else:
            behavior, note = "礼貌接梗", "不熟，笑着接一下就过"
        max_chars = 18
    elif main_intent == "poke":
        behavior, note = "回应戳", "第一次调侃一句；连续被戳就不耐烦一句或无视"
        max_chars = 12
        allow_silence = True
    elif main_intent == "sticker":
        behavior = "看心情"
        note = "表情包别硬解，可以回个更贱的或者不理"
        max_chars = 12
        allow_silence = True
    else:  # chat
        behavior = "接话"
        if sad >= 45:
            note = "情绪低，话少一点"
            max_chars = 14
        elif joy >= 50:
            note = "心情好，可以主动延伸一句"
            max_chars = 26
        else:
            note = "普通聊两句"
        if not at_me and fam < 15:
            allow_silence = True

    # 情绪覆盖：生气时压长度、就地少废话
    if anger >= 60 and behavior not in ("冷处理", "表明立场"):
        note = (note + "；有火气，短句").strip("；")
        max_chars = min(max_chars, 16)

    return {"behavior": behavior, "max_chars": max(8, int(max_chars)),
            "note": note, "allow_silence": allow_silence}


def length_hint(max_chars: int) -> str:
    return f"尽量 {max_chars} 字内"
