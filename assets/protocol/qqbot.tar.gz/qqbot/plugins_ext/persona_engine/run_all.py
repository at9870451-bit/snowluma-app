"""persona_engine 测试套件 —— 对应规范十五的 A~J 验收场景。

运行：cd /opt/qqbot && python3 plugins_ext/persona_engine/tests/run_all.py
本地：python3 run_all.py（自动打桩）
"""
from __future__ import annotations

import asyncio
import sys
import tempfile
import time
from pathlib import Path
from types import SimpleNamespace

try:
    from qqbot.plugins.base import Plugin  # noqa: F401
except ImportError:
    import types as _t
    _qqbot = _t.ModuleType("qqbot")
    _core = _t.ModuleType("qqbot.core")
    _bus = _t.ModuleType("qqbot.core.bus")
    _bus.STOP = "STOP"
    _plugins = _t.ModuleType("qqbot.plugins")
    _base = _t.ModuleType("qqbot.plugins.base")

    class _Plugin:
        priority = 50

        def __init__(self, bot=None):
            import logging
            self.bot = bot
            self.cfg = dict(getattr(self, "default_config", {}) or {})
            self._cmds = {}
            self.log = logging.getLogger("stub")

        @property
        def data_dir(self):
            return self.bot.config.paths.plugin_data_dir / self.name

        def cfg_get(self, key, default=None):
            return self.cfg.get(key, default)

        def save_config(self):
            pass

        def add_command(self, name, handler, **kw):
            self._cmds[name] = (handler, kw)

        @staticmethod
        def stop():
            return _bus.STOP

    _base.Plugin = _Plugin
    _qqbot.core = _core
    _core.bus = _bus
    _qqbot.plugins = _plugins
    _plugins.base = _base
    for _n, _m in {"qqbot": _qqbot, "qqbot.core": _core, "qqbot.core.bus": _bus,
                   "qqbot.plugins": _plugins, "qqbot.plugins.base": _base}.items():
        sys.modules[_n] = _m

_PKG = Path(__file__).resolve().parent.parent
for _p in ("/opt/qqbot/plugins_ext", "/opt/qqbot", str(_PKG.parent)):
    if _p not in sys.path:
        sys.path.insert(0, _p)

try:
    import persona_engine  # noqa: F401
except ImportError:
    import persona_dev as persona_engine  # noqa: F401
    sys.modules.setdefault("persona_engine", persona_engine)

PASS = FAIL = 0


def check(name, cond, detail=""):
    global PASS, FAIL
    if cond:
        PASS += 1
        print(f"  ✓ {name}")
    else:
        FAIL += 1
        print(f"  ✗ {name} {detail}")


def _make(cfg_extra=None, card="你是菲比，一个活泼可爱的女孩。"):
    from persona_engine import PersonaEnginePlugin

    class FakePaths:
        plugin_data_dir = Path(tempfile.mkdtemp())

    class FakeAI:
        system_prompt = card

    class FakeCfg:
        paths = FakePaths()
        ai = FakeAI()

        class bot:  # noqa: N801
            admins = [3227868908]

        def save(self):
            pass

    class FakeBot:
        config = FakeCfg()
        self_id = 1780685132
        sent = []

        async def send_group_msg(self, gid, message, *a, **k):
            FakeBot.sent.append(("g", gid))
            return {}

        async def send_private_msg(self, uid, message, *a, **k):
            FakeBot.sent.append(("p", uid))
            return {}

    bot = FakeBot()
    p = PersonaEnginePlugin(bot)
    p.cfg.update(cfg_extra or {})
    return bot, p


def _ctx(uid=5, text="", gid=111, at_me=False, raw=None, image=False):
    raw = raw if raw is not None else (text or "")
    if at_me:
        raw = f"[CQ:at,qq=1780685132] {raw}"
    if image:
        raw = "[CQ:image,file=x.jpg] " + raw
    ev = SimpleNamespace(user_id=uid, group_id=gid, text=text,
                         sender={"card": f"u{uid}", "nickname": f"u{uid}"},
                         message_id=1, message=[], raw_message=raw)
    c = SimpleNamespace(event=ev, user_id=uid, group_id=gid, text=text,
                        is_group=gid is not None, is_admin=False,
                        at_targets=[], message=[], replies=[])
    box = c.replies

    async def _reply(msg, **kw):
        box.append(msg)

    c.reply = _reply
    return c


def t_a_greeting():
    print("[A] 普通招呼：自然回应，不输出情绪报告")
    bot, p = _make()
    asyncio.run(p.on_load())
    inj = asyncio.run(p.mood_injection(_ctx(5, "在吗"), ""))
    check("注入含策略行", "策略" in inj)
    check("注入无情绪分析报告", "情绪分析" not in inj and "置信度" not in inj)
    check("注入长度受控", len(inj) <= 300, f"{len(inj)}")


def t_b_tease():
    print("[B] 熟人接梗：识别默契，不误判恶意")
    bot, p = _make()
    asyncio.run(p.on_load())
    import persona_engine.relationship as rel
    # 先积累熟悉度
    for _ in range(6):
        asyncio.run(p.on_message(_ctx(7, "哈哈你这家伙真逗")))
    m = rel.store.get_member(p._conn, 7)
    check("熟悉度上升", m["familiarity"] > 0, f"{m['familiarity']}")
    before = p._states["emotion.anger"]
    asyncio.run(p.on_message(_ctx(7, "菜狗哈哈哈哈")))
    check("调侃不涨怒", p._states["emotion.anger"] <= before + 3.5,
          f"anger {before}->{p._states['emotion.anger']}")


def t_c_multi():
    print("[C] 多人交叉：意图识别区分对象")
    from persona_engine import intent
    a = intent.analyze("你们聊啥呢", is_at_me=False)
    b = intent.analyze("在吗", is_at_me=True)
    check("非@为普通聊天", a["main"] == "chat", a["main"])
    check("@我提高置信度", b["confidence"] > a["confidence"] or b["main"] == "chat")
    poke = intent.analyze("", is_poke=True)
    check("戳一戳单独意图", poke["main"] == "poke")


def t_d_poke():
    print("[D] 连续戳一戳：反应变化")
    bot, p = _make()
    asyncio.run(p.on_load())

    def poke_event():
        return SimpleNamespace(notice_type="notify", user_id=9, group_id=111,
                               get=lambda k, d=None: {"sub_type": "poke"}.get(k, d))

    for _ in range(3):
        asyncio.run(p.on_notice(poke_event()))
    check("被连戳开始烦", p._states["emotion.anger"] > 6,
          f"anger={p._states['emotion.anger']}")
    inj = asyncio.run(p.mood_injection(_ctx(9, ""), ""))
    check("注入提示不耐烦", "不耐烦" in inj, inj[:80])


def t_e_recover():
    print("[E] 争论后道歉：怒气回落")
    bot, p = _make()
    asyncio.run(p.on_load())
    asyncio.run(p.on_message(_ctx(11, "你就是错的，胡说八道")))
    anger_after_arg = p._states["emotion.anger"]
    check("争论涨怒", anger_after_arg > 8, f"{anger_after_arg}")
    time.sleep(0.2)
    p._last_hit.clear()
    asyncio.run(p.on_message(_ctx(11, "对不起，是我不好")))
    check("道歉降怒", p._states["emotion.anger"] < anger_after_arg,
          f"{anger_after_arg}->{p._states['emotion.anger']}")


def t_f_longterm():
    print("[F] 长期关系：逐步形成有限记忆")
    bot, p = _make()
    asyncio.run(p.on_load())
    import persona_engine.relationship as rel
    for i in range(10):
        asyncio.run(p.on_message(_ctx(13, "今天也来陪你聊聊天")))
        p._last_hit.clear()
    m = rel.store.get_member(p._conn, 13)
    check("熟悉度累积但保守", 0 < m["familiarity"] <= 10,
          f"{m['familiarity']}")
    inj = asyncio.run(p.mood_injection(_ctx(13, "在吗"), ""))
    check("注入含关系行", "对TA" in inj)


def t_g_adult_gate():
    print("[G] 成人模块：默认关闭，不把友善当暗示")
    bot, p = _make()
    asyncio.run(p.on_load())
    check("默认关闭", not p._adult_on())
    asyncio.run(p.on_message(_ctx(15, "你今天好漂亮，喜欢你")))
    check("友善不产生性吸引", p._states.get("adult.sexual_attraction", 0) == 0)
    inj = asyncio.run(p.mood_injection(_ctx(15, "你真好看"), ""))
    check("关闭时无成人提示", "关系层次" not in inj)


def t_h_refuse():
    print("[H] 明确拒绝：立即停止并记录边界")
    bot, p = _make({"persona_adult": True, "adult_enabled": True})
    asyncio.run(p.on_load())
    p._states["adult.enabled"] = 1.0
    check("开启前提满足", p._adult_on())
    asyncio.run(p.on_message(_ctx(17, "别这样，我不舒服")))
    import persona_engine.relationship as rel
    m = rel.store.get_member(p._conn, 17)
    check("边界记为 refused", m.get("adult_boundary") == "refused",
          str(m.get("adult_boundary")))
    check("暧昧倾向清零", p._states.get("adult.flirtation_tendency", 0) == 0)


def t_i_sticker():
    print("[I] 低置信度表情包：不强行判断")
    from persona_engine import intent
    r = intent.analyze("", has_image=True)
    check("表情包低置信度", r["confidence"] <= 0.5, str(r["confidence"]))
    bot, p = _make()
    asyncio.run(p.on_load())
    before = dict(p._states)
    asyncio.run(p.on_message(_ctx(19, "", image=True)))
    delta = abs(p._states.get("emotion.joy", 20) - before.get("emotion.joy", 20)) \
        + abs(p._states.get("emotion.anger", 4) - before.get("emotion.anger", 4))
    check("表情包不引发大情绪", delta < 6, f"delta={delta:.1f}")


def t_j_burst():
    print("[J] 高频消息：状态有界、防刷")
    bot, p = _make()
    asyncio.run(p.on_load())
    for _ in range(40):
        asyncio.run(p.on_message(_ctx(21, "垃圾垃圾滚")))
        # 同意图冷却内不重复计
    check("怒气有上限", p._states["emotion.anger"] <= 100)
    check("单次爆发贡献有限", p._states["emotion.anger"] < 60,
          f"{p._states['emotion.anger']:.1f}")
    bot.sent.clear()


def t_commands():
    print("[K] 指令与状态卡")
    bot, p = _make()
    asyncio.run(p.on_load())

    class C:
        def __init__(self):
            self.replies = []

        async def reply(self, msg):
            self.replies.append(msg)

    c = C()
    asyncio.run(p._cmd(c, ""))
    out = c.replies[0]
    check("状态卡含心情/六欲/人格", "【心情】" in out and "【六欲】" in out and "【人格】" in out)
    c = C()
    asyncio.run(p._cmd(c, "成人 on"))
    check("未声明成年不能开", "不能开启" in c.replies[0])
    c = C()
    asyncio.run(p._cmd(c, "人格"))
    check("人格卡含维度", "幽默程度" in c.replies[0])
    c = C()
    asyncio.run(p._cmd(c, "设置 喜 80"))
    check("设置生效", p._states["emotion.joy"] == 80)
    c = C()
    asyncio.run(p._cmd(c, "重置"))
    check("重置回基线", p._states["emotion.joy"] == 20)


def t_behavior():
    print("[L] 行为选择：不同场景不同策略")
    from persona_engine import behavior, persona
    P = persona.Personality()
    st = {"emotion.anger": 10, "emotion.joy": 30, "emotion.sadness": 5,
          "emotion.affection": 30}
    r1 = behavior.choose(main_intent="question", emotions=st, personality=P,
                         member={}, at_me=True, is_group=True)
    check("提问→回答", r1["behavior"] == "回答")
    r2 = behavior.choose(main_intent="insult", emotions=st, personality=P,
                         member={}, at_me=True, is_group=True)
    check("辱骂→冷处理/表明立场",
          r2["behavior"] in ("冷处理", "表明立场") and r2["max_chars"] <= 16,
          str(r2))
    r3 = behavior.choose(main_intent="poke", emotions=st, personality=P,
                         member={}, at_me=False, is_group=True)
    check("戳→可沉默", r3["allow_silence"])
    ang = dict(st, **{"emotion.anger": 70})
    r4 = behavior.choose(main_intent="chat", emotions=ang, personality=P,
                         member={}, at_me=True, is_group=True)
    check("高怒压长度", r4["max_chars"] <= 16, str(r4["max_chars"]))


if __name__ == "__main__":
    t_a_greeting()
    t_b_tease()
    t_c_multi()
    t_d_poke()
    t_e_recover()
    t_f_longterm()
    t_g_adult_gate()
    t_h_refuse()
    t_i_sticker()
    t_j_burst()
    t_commands()
    t_behavior()
    print(f"\n结果：{PASS} 通过 / {FAIL} 失败")
    sys.exit(1 if FAIL else 0)
