"""intent — 消息结构与意图识别（规则式，多意图 + 置信度）。

识别：提问/玩笑/调侃/争论/倾诉/邀请/拒绝/夸奖/辱骂/道歉/戳一戳/纯表情。
返回英文 key（供情绪/策略表使用）+ 中文 label（供日志/指令显示）。
"""

from __future__ import annotations

import re
from typing import Any

# key -> (中文名, 模式)
INTENTS: dict[str, tuple[str, tuple[str, ...]]] = {
    "question": ("提问", (r"[?？]", r"吗$|吗[，,。！!]?$",
                         r"什么|怎么|为什么|如何|哪个|多少|是不是|能不能",)),
    "joke": ("玩笑", (r"哈哈|hhh|笑死|233|草|离谱|绷不住|乐",)),
    "tease": ("调侃", (r"菜|笨|傻|就这|不行啊|啧|哟|哦豁",)),
    "argument": ("争论", (r"不对|你错|明明|凭什么|胡说|瞎说|才不是|根本不是",)),
    "confide": ("倾诉", (r"难受|累|烦|emo|崩溃|委屈|失眠|压力",)),
    "invite": ("邀请", (r"一起|来不|约|开黑|带我|要不要|来玩",)),
    "reject": ("拒绝", (r"不要|别这样|不想|算了|不聊|到此为止|停止|别再说",)),
    "praise": ("夸奖", (r"厉害|牛|棒|可爱|喜欢|真好|聪明|优秀",)),
    "insult": ("辱骂", (r"滚|傻[逼比]|sb|垃圾|闭嘴|废物|白痴|脑残|智障",)),
    "apology": ("道歉", (r"对不起|抱歉|我错|是我不好|别生气",)),
}

PRIORITY = ["reject", "insult", "argument", "confide", "question",
            "tease", "joke", "praise", "invite", "apology", "poke",
            "sticker", "chat"]

LABELS = {k: v[0] for k, v in INTENTS.items()}
LABELS.update({"poke": "戳一戳", "sticker": "表情包", "chat": "普通聊天"})


def analyze(text: str, *, is_at_me: bool = False, is_reply_me: bool = False,
            is_poke: bool = False, has_image: bool = False) -> dict[str, Any]:
    t = (text or "").strip()
    hits: list[tuple[str, float]] = []
    if is_poke:
        hits.append(("poke", 0.95))
    if not t and has_image:
        return {"intents": [("sticker", 0.4)], "main": "sticker",
                "main_label": "表情包", "confidence": 0.4,
                "at_me": is_at_me, "reply_me": is_reply_me,
                "poke": is_poke, "image_only": True}
    for key, (_label, patterns) in INTENTS.items():
        if isinstance(patterns, str):
            patterns = (patterns,)
        for pat in patterns:
            if re.search(pat, t, re.IGNORECASE):
                hits.append((key, 0.75 if (is_at_me or is_reply_me) else 0.55))
                break
    if not hits:
        hits.append(("chat", 0.6 if (is_at_me or is_reply_me) else 0.35))
    seen, uniq = set(), []
    for key, c in hits:
        if key in seen:
            continue
        seen.add(key)
        uniq.append((key, round(c, 2)))
    names = [k for k, _ in uniq]
    main = uniq[0][0]
    for p in PRIORITY:
        if p in names:
            main = p
            break
    conf = max(c for _, c in uniq)
    return {"intents": uniq, "main": main,
            "main_label": LABELS.get(main, main), "confidence": conf,
            "at_me": is_at_me, "reply_me": is_reply_me,
            "poke": is_poke, "image_only": False}


# 意图 → 情绪增量
INTENT_EMOTION = {
    "praise": {"joy": 12, "affection": 4},
    "insult": {"anger": 18, "disgust": 10, "joy": -6},
    "joke": {"joy": 8, "anticipation": 4},
    "tease": {"joy": 4, "anger": 3},
    "argument": {"anger": 10, "anticipation": 6},
    "confide": {"sadness": 10, "affection": 5},
    "apology": {"anger": -25, "sadness": -8, "affection": 4},
    "invite": {"joy": 8, "anticipation": 10},
    "reject": {"sadness": 12, "anger": 6, "anticipation": -10},
    "question": {"anticipation": 5},
    "poke": {"anticipation": 4, "anger": 2},
}
