"""llm_adapter — 大模型接口适配（薄封装）。

复用 QQBot 共享的 chat_client()（与内置插件同一实例、同一上下文记忆），
提供超时与异常包装；不引入第二个模型客户端，避免配置分裂。
"""

from __future__ import annotations

import asyncio
from typing import Any


class LLMAdapter:
    def __init__(self, bot, timeout: float = 60.0) -> None:
        self.bot = bot
        self.timeout = timeout

    def client(self):
        return self.bot.chat_client()

    async def chat(self, session: str, prompt: str, *, context: str = "",
                   memory: str = "", summary: str = "") -> str:
        client = self.client()
        try:
            return await asyncio.wait_for(
                client.chat(session, prompt, context,
                            memory=memory, summary=summary),
                timeout=self.timeout)
        except asyncio.TimeoutError:
            raise RuntimeError("模型响应超时，请稍后再试")
