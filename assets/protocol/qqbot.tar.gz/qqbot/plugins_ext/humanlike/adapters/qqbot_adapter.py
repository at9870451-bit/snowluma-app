"""qqbot_adapter — QQBot 消息适配（ctx → 统一结构，供本插件内部使用）。"""

from __future__ import annotations

from typing import Any


def normalize(ctx) -> dict[str, Any]:
    """把 QQBot Context/Event 转为统一 dict。"""
    event = getattr(ctx, "event", ctx)
    sender = getattr(event, "sender", None) or {}
    try:
        uid = int(getattr(event, "user_id", 0) or 0)
    except (TypeError, ValueError):
        uid = 0
    gid = getattr(event, "group_id", None)
    try:
        gid = int(gid) if gid else None
    except (TypeError, ValueError):
        gid = None
    return {
        "user_id": uid,
        "group_id": gid,
        "is_group": gid is not None,
        "nickname": str(sender.get("card") or sender.get("nickname")
                        or uid or ""),
        "text": str(getattr(event, "text", "") or "").strip(),
        "msg_id": getattr(event, "message_id", None),
        "is_admin": bool(getattr(ctx, "is_admin", False)),
        "raw_message": str(getattr(event, "raw_message", "") or ""),
    }


def session_of(m: dict[str, Any]) -> str:
    return f"group_{m['group_id']}" if m["is_group"] else f"user_{m['user_id']}"


def reply_session_of(m: dict[str, Any]) -> str:
    """bot 发消息时使用的会话键（与 _ai_reply.session_key 一致）。"""
    return session_of(m)
