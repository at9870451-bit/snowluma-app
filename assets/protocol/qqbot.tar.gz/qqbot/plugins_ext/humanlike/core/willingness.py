"""willingness — 回复意愿系统（移植自 MaiBot/MaiSaka turn_trigger 模块设计）。

三层机制（与 MaiBot 对应）：
  1. reply_likelihood —— 逻辑回归估计「这批消息值得回复的概率」
     （权重取自 MaiBot 用 Planner 首轮记录拟合的结果，见其 reply_likelihood.py）
  2. dynamic_gate —— 按小时滑窗对齐「实际回复数 ≈ 目标回复数」：
     目标 = 意愿频率 × 预计回复数；窗口内按概率从高到低放行，只收紧不放宽
  3. idle_backoff —— 连续多轮「看到消息但决定不回」后指数退避，
     防止机器人悬在对话边上一条条评估；被强制触发或真的回复了就复位

本模块不依赖 qqbot 运行时，可独立离线测试。
"""

from __future__ import annotations

import time
from collections import deque
from dataclasses import dataclass
from math import exp, log1p
from typing import Deque, List, Sequence, Set, Tuple

# ---------------------------------------------------------------- 常量

MAX_PENDING_COUNT = 20
DEFAULT_SECONDS_SINCE_BOT_MESSAGE = 3600.0

# QQ 场景的媒体占位前缀（CQ 码 / QQBot 文本占位）
MEDIA_PLACEHOLDER_PREFIXES = (
    "[CQ:image", "[CQ:face", "[CQ:record", "[CQ:video", "[CQ:xml",
    "[表情包", "[图片", "[语音", "[视频", "[文件]", "[卡片",
)

REPLY_WINDOW_SECONDS = 3600.0
FORCED_TURN_EXPECTED_REPLIES = 0.91
MIN_WINDOW_SCORE_COUNT = 20
VIRTUAL_ROUND_SECONDS = 40.0
MAX_COUNTED_MESSAGE_IDS = 2000

# 拟合权重（来源：MaiBot scripts/explore_reply_necessity.py）
_INTERCEPT = -1.2005
_WEIGHT_MENTION_BOT = 1.5852
_WEIGHT_AT_OTHER = -1.1157
_WEIGHT_QUESTION_MARK = 0.4807
_WEIGHT_PLACEHOLDER_ONLY = -1.0281
_WEIGHT_RECENT_SELF_RATIO = 2.6525
_WEIGHT_RECENT_MESSAGE_COUNT = -0.0367
_WEIGHT_LOG_SECONDS_SINCE_BOT = 0.0571
_WEIGHT_PENDING_COUNT = 0.1012

# 离线统计：保留比例 → 概率阈值（窗口样本不足时用）
_STATIC_KEEP_RATIO_THRESHOLDS: Tuple[Tuple[float, float], ...] = (
    (0.0, 1.0), (0.1, 0.605), (0.2, 0.482), (0.3, 0.430), (0.4, 0.376),
    (0.5, 0.336), (0.6, 0.313), (0.7, 0.290), (0.8, 0.250), (0.9, 0.206),
    (1.0, 0.0),
)


def _static_threshold(keep_ratio: float) -> float:
    thresholds = _STATIC_KEEP_RATIO_THRESHOLDS
    for (low_ratio, low_t), (high_ratio, high_t) in zip(thresholds, thresholds[1:]):
        if keep_ratio <= high_ratio:
            progress = (keep_ratio - low_ratio) / max(1e-9, high_ratio - low_ratio)
            return low_t + (high_t - low_t) * progress
    return 0.0


# ---------------------------------------------------------------- 概率估计

@dataclass(frozen=True, slots=True)
class ReplyLikelihoodInput:
    mention_bot: bool          # 消息里提到机器人名字
    at_other: bool             # @ 了别人（不是机器人）
    has_question_mark: bool    # 带问号
    placeholder_only: bool     # 全是表情/图片占位
    recent_self_ratio: float   # 最近 5 分钟消息里机器人占比
    recent_message_count: int  # 最近 5 分钟消息条数
    seconds_since_bot_message: float  # 距机器人上次发言秒数
    pending_count: int         # 本批待处理消息条数


def summarize_texts(texts: Sequence[str], *, has_at_bot: bool) -> Tuple[bool, bool, bool]:
    """从一批消息文本得到 (at_other, has_question_mark, placeholder_only)。"""
    stripped = [t.strip() for t in texts if t and t.strip()]
    at_other = not has_at_bot and any("@" in t for t in stripped)
    has_question = any(("?" in t or "？" in t) for t in stripped)
    placeholder_only = bool(stripped) and all(
        t.startswith(MEDIA_PLACEHOLDER_PREFIXES) for t in stripped)
    return at_other, has_question, placeholder_only


def estimate_reply_probability(inp: ReplyLikelihoodInput) -> float:
    """估计这批消息进入回复决策后会真的回复的概率（0~1）。"""
    logit = (
        _INTERCEPT
        + _WEIGHT_MENTION_BOT * float(inp.mention_bot)
        + _WEIGHT_AT_OTHER * float(inp.at_other)
        + _WEIGHT_QUESTION_MARK * float(inp.has_question_mark)
        + _WEIGHT_PLACEHOLDER_ONLY * float(inp.placeholder_only)
        + _WEIGHT_RECENT_SELF_RATIO * min(1.0, max(0.0, inp.recent_self_ratio))
        + _WEIGHT_RECENT_MESSAGE_COUNT * max(0, inp.recent_message_count)
        + _WEIGHT_LOG_SECONDS_SINCE_BOT * log1p(max(0.0, inp.seconds_since_bot_message))
        + _WEIGHT_PENDING_COUNT * min(MAX_PENDING_COUNT, max(0, inp.pending_count))
    )
    return 1.0 / (1.0 + exp(-logit))


# ---------------------------------------------------------------- 动态门控

@dataclass(frozen=True, slots=True)
class GateDecision:
    should_trigger: bool
    probability: float
    threshold: float
    expected_replies: float   # 窗口内不设门控时的预计回复数
    target_replies: float     # 频率折算后的目标回复数
    actual_replies: int       # 窗口内实际回复数
    keep_ratio: float         # 当前保留比例

    @property
    def detail(self) -> str:
        return (f"概率={self.probability:.2f} 阈值={self.threshold:.2f} "
                f"预计={self.expected_replies:.1f} 目标={self.target_replies:.1f} "
                f"已回={self.actual_replies} 保留={self.keep_ratio:.2f}")


class DynamicReplyGate:
    """单个会话的动态回复门控。

    - 消息到达 → record_proactive_demand（40s 虚拟轮次内只计一次，覆盖更新）
    - @/关键词强制触发 → record_forced_turn（按实测均值 0.91 计预计回复）
    - 机器人真的回复 → record_reply
    - evaluate(probability, frequency) → 本次是否放行
    """

    def __init__(self, window_seconds: float = REPLY_WINDOW_SECONDS) -> None:
        self._window = window_seconds
        self._proactive: Deque[Tuple[float, float]] = deque()
        self._forced: Deque[Tuple[float, float]] = deque()
        self._replies: Deque[float] = deque()
        self._open_round_at: float | None = None

    # ---- 记录 ----

    def is_round_open(self, now: float) -> bool:
        return (self._open_round_at is not None
                and now - self._open_round_at < VIRTUAL_ROUND_SECONDS)

    def record_proactive_demand(self, probability: float, now: float) -> None:
        if self.is_round_open(now) and self._proactive:
            start, _ = self._proactive[-1]
            self._proactive[-1] = (start, probability)
            return
        self._open_round_at = now
        self._proactive.append((now, probability))

    def record_forced_turn(self, now: float) -> None:
        self._open_round_at = None
        self._forced.append((now, FORCED_TURN_EXPECTED_REPLIES))

    def record_reply(self, now: float) -> None:
        self._replies.append(now)

    # ---- 判定 ----

    def _prune(self, now: float) -> None:
        expire = now - self._window
        for dq in (self._proactive, self._forced):
            while dq and dq[0][0] < expire:
                dq.popleft()
        while self._replies and self._replies[0] < expire:
            self._replies.popleft()

    def evaluate(self, probability: float, frequency: float,
                 now: float) -> GateDecision:
        self._prune(now)
        scores = [s for _, s in self._proactive]
        expected_proactive = sum(scores)
        expected_forced = sum(v for _, v in self._forced)
        expected_total = expected_proactive + expected_forced
        actual = len(self._replies)
        freq = min(1.0, max(0.0, frequency))
        target = freq * expected_total

        if freq >= 1.0:
            keep = 1.0
        elif expected_proactive <= 0:
            keep = freq
        else:
            feedforward = (target - expected_forced) / expected_proactive
            # 反馈只收紧不放宽：一波消息刚到时预计数先涨，若放宽会系统性偏多
            feedback = min(1.0, max(0.0, 1.0 + (target - actual) / max(1.0, target)))
            keep = min(1.0, max(0.0, feedforward * feedback))

        threshold = self._resolve_threshold(scores, expected_proactive, keep)
        return GateDecision(
            should_trigger=probability >= threshold,
            probability=probability,
            threshold=threshold,
            expected_replies=expected_total,
            target_replies=target,
            actual_replies=actual,
            keep_ratio=keep,
        )

    @staticmethod
    def _resolve_threshold(scores: Sequence[float], expected_proactive: float,
                           keep: float) -> float:
        if keep >= 1.0:
            return 0.0
        if keep <= 0.0:
            return 1.0
        if len(scores) < MIN_WINDOW_SCORE_COUNT:
            return _static_threshold(keep)
        budget = keep * expected_proactive
        acc = 0.0
        for s in sorted(scores, reverse=True):
            acc += s
            if acc >= budget:
                return s
        return 0.0

    def stats(self, now: float) -> dict:
        self._prune(now)
        scores = [s for _, s in self._proactive]
        return {
            "window_scores": len(scores),
            "expected_proactive": round(sum(scores), 2),
            "expected_forced": round(sum(v for _, v in self._forced), 2),
            "actual_replies": len(self._replies),
        }


# ---------------------------------------------------------------- 空闲退避

class IdleBackoff:
    """连续「决定不回」后的指数退避（仅群聊）。"""

    def __init__(self, base_seconds: float = 90.0, cap_seconds: float = 1800.0,
                 start_count: int = 2) -> None:
        self.base = max(0.0, base_seconds)
        self.cap = max(0.0, cap_seconds)
        self.start = max(1, start_count)
        self._count = 0
        self._until = 0.0

    def record_idle(self, now: float | None = None) -> None:
        now = now or time.time()
        self._count += 1
        if self._count < self.start or self.base <= 0 or self.cap <= 0:
            return
        delay = min(self.cap, self.base * (2 ** (self._count - self.start)))
        self._until = now + delay

    def reset(self) -> None:
        self._count = 0
        self._until = 0.0

    def delay_seconds(self, now: float | None = None,
                      pending_count: int = 0,
                      bypass_pending: int = 5) -> float:
        """当前还需退避的秒数；待处理消息堆积超过 bypass_pending 时直接放行。"""
        now = now or time.time()
        if self._until <= 0:
            return 0.0
        remaining = self._until - now
        if remaining <= 0:
            self._until = 0.0
            return 0.0
        if bypass_pending > 0 and pending_count >= bypass_pending:
            return 0.0
        return remaining

    def stats(self) -> dict:
        return {"idle_streak": self._count,
                "backoff_until": self._until,
                "backoff_remaining": max(0.0, self._until - time.time())}
