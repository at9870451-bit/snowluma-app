"""response_engine — 真人化回复引擎（决策层）。

在调用模型前综合：意图、上下文、场景、关系与偏好、当前情绪，
产出一组「回复约束」注入提示词。生成仍由 QQBot 的 client.chat 完成
（复用现有模型调用链），本模块不直接发请求。
"""

from __future__ import annotations

from typing import Any

from . import style_analyzer
from .context_manager import ContextManager


def decide(ctx_items: list[dict[str, Any]], text: str, *,
           mood: float | None = None,
           user_avg_len: float | None = None,
           insult_count: int = 0,
           is_group: bool = True) -> dict[str, Any]:
    """综合决策：返回注入提示词的约束片段（scenario 由 prompt_builder 渲染）。"""
    cm = ContextManager()
    inter = style_analyzer.analyze_interaction(text)
    topic_shift = cm.topic_shifted(ctx_items)
    answered = cm.already_answered(ctx_items, text)
    ref_hint = cm.resolve_reference(ctx_items, text)

    notes: list[str] = []
    # 意图
    if inter.get("ask"):
        notes.append("对方在提问：直接回答问题本身，别绕弯")
    if inter.get("ending"):
        notes.append("对方要收尾了：简短回应即可，别抛新话题")
    if inter.get("followup"):
        notes.append("对方想听后续：有料就多说一句（仍单行）")
    # 关系与偏好
    if insult_count >= 2:
        notes.append(f"这人之前怼过你 {insult_count} 次：语气可以差一点")
    # 情绪
    if mood is not None and mood <= -40:
        notes.append("你很生气：回复带明显不满，可以冷嘲，不失态")
    elif mood is not None and mood >= 40:
        notes.append("你现在心情好：回复可以更热络")
    # 指代
    if ref_hint:
        notes.append(ref_hint)
    # 长度
    if user_avg_len and user_avg_len < 8:
        notes.append("对方句子短，你也短句")
    if inter.get("long_msg") and not is_group:
        notes.append("对方发长文，可以详细一点")

    return {
        "interaction_tags": style_analyzer.summarize_interaction(inter),
        "mood_label": style_analyzer.dominant_mood(inter),
        "topic_shift": topic_shift,
        "already_answered": answered,
        "notes": "；".join(notes),
    }
