"""feedback_engine — 反馈与持续优化。

指标（启发式、可量化，每条回复入库）：
  relevance   相关性：回复与当前消息/上下文的关键词重叠
  naturalness 自然度：机械表达词典命中（越少越好）
  consistency 一致性：与该用户平均句长的偏差
  coherence   连贯性：与最近上下文的 bigram 重叠
  repetition  重复率：与最近 10 条回复的最大 bigram 相似度
  length_fit  适度性：长度与场景匹配（群聊 5~40 字为宜）

支持：用户评价指令（good/bad）、提示词版本标记、A/B 变体记录与统计。
不自动改生产配置；微调数据导出由管理员指令完成。
"""

from __future__ import annotations

import re
import sqlite3
import time
from typing import Any

SCHEMA = """
CREATE TABLE IF NOT EXISTS feedback (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    session TEXT, user_id INTEGER, group_id INTEGER,
    prompt TEXT, reply TEXT,
    variant TEXT DEFAULT '',
    prompt_version TEXT DEFAULT '',
    relevance REAL, naturalness REAL, consistency REAL,
    coherence REAL, repetition REAL, length_fit REAL,
    score REAL, rating TEXT DEFAULT '',
    note TEXT DEFAULT '',
    created_at REAL
);
CREATE INDEX IF NOT EXISTS idx_fb_session ON feedback(session, id DESC);
"""

MECHANICAL = [
    "作为一个AI", "希望对你有帮助", "总而言之", "综上所述", "首先", "其次",
    "很高兴为您服务", "我理解你的感受", "让我们", "请问有什么", "总的来说",
    "与此同时", "值得注意的是", "不得不说", "亲爱的用户", "祝您", "您好",
]


def _bigrams(text: str) -> set[str]:
    t = re.sub(r"\s+", "", text or "")
    return {t[i:i+2] for i in range(len(t)-1)}


class FeedbackEngine:
    def __init__(self, conn: sqlite3.Connection, prompt_version: str = "v1") -> None:
        self.conn = conn
        self.prompt_version = prompt_version
        with self.conn:
            self.conn.executescript(SCHEMA)

    # ---------- 记录 ----------

    def record(self, session: str, user_id: int, group_id: int | None,
               prompt: str, reply: str, recent_replies: list[str],
               recent_context: list[str], user_avg_len: float | None = None,
               variant: str = "", is_group: bool = True) -> dict[str, float]:
        reply = reply or ""
        r_grams = _bigrams(reply)
        # relevance：与当前消息+上下文的重叠
        cur_grams = _bigrams((prompt or "")[-80:])
        ctx_grams = set().union(*[_bigrams(c) for c in recent_context[-4:]]) \
            if recent_context else set()
        rel = (len(r_grams & cur_grams) / max(1, len(r_grams))) * 0.6 \
            + (len(r_grams & ctx_grams) / max(1, len(r_grams))) * 0.4
        # naturalness：机械词（0=好，1=差）
        bad = sum(1 for w in MECHANICAL if w in reply)
        nat = max(0.0, 1.0 - bad * 0.4)
        # consistency：句长偏差
        rlen = len(reply)
        cons = 1.0
        if user_avg_len:
            diff = abs(rlen - user_avg_len) / max(8.0, user_avg_len)
            cons = max(0.0, 1.0 - diff * 0.5)
        # coherence：与上下文 bigram 重叠
        coh = len(r_grams & ctx_grams) / max(1, len(r_grams)) if ctx_grams else 0.5
        # repetition：与最近回复的最大相似度
        rep = 0.0
        for prev in recent_replies[-10:]:
            p = _bigrams(prev)
            if p:
                rep = max(rep, len(r_grams & p) / max(1, len(r_grams | p)))
        # length_fit
        target = (5, 40) if is_group else (5, 80)
        fit = 1.0 if target[0] <= rlen <= target[1] else \
            max(0.0, 1.0 - min(abs(rlen - target[0]), abs(rlen - target[1])) / 60)
        score = round(
            rel * 0.25 + nat * 0.25 + cons * 0.1 + coh * 0.2 +
            (1 - rep) * 0.1 + fit * 0.1, 3)
        with self.conn:
            self.conn.execute(
                """INSERT INTO feedback(session,user_id,group_id,prompt,reply,variant,
                   prompt_version,relevance,naturalness,consistency,coherence,
                   repetition,length_fit,score,created_at)
                   VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (session, user_id, group_id, (prompt or "")[-200:], reply[:300],
                 variant, self.prompt_version, round(rel, 3), round(nat, 3),
                 round(cons, 3), round(coh, 3), round(rep, 3), round(fit, 3),
                 score, time.time()))
        return {"relevance": round(rel, 2), "naturalness": round(nat, 2),
                "consistency": round(cons, 2), "coherence": round(coh, 2),
                "repetition": round(rep, 2), "length_fit": round(fit, 2),
                "score": score}

    def rate_last(self, session: str, rating: str, note: str = "") -> bool:
        with self.conn:
            row = self.conn.execute(
                "SELECT id FROM feedback WHERE session=? ORDER BY id DESC LIMIT 1",
                (session,)).fetchone()
            if not row:
                return False
            self.conn.execute(
                "UPDATE feedback SET rating=?, note=? WHERE id=?",
                (rating, note[:120], row["id"]))
        return True

    # ---------- 统计 ----------

    def summary(self, variant: str | None = None, limit: int = 200) -> dict[str, Any]:
        where = "WHERE variant=?" if variant else ""
        args = (variant, ) if variant else ()
        rows = self.conn.execute(
            f"""SELECT AVG(relevance) relevance, AVG(naturalness) naturalness,
                       AVG(consistency) consistency, AVG(coherence) coherence,
                       AVG(repetition) repetition, AVG(length_fit) length_fit,
                       AVG(score) score, COUNT(*) n, 
                       SUM(rating='good') good, SUM(rating='bad') bad
                FROM feedback {where}""", args).fetchone()
        d = dict(rows) if rows else {}
        return {k: (round(v, 3) if isinstance(v, float) else v) for k, v in d.items()}

    def purge_old(self, days: int = 30) -> int:
        with self.conn:
            cur = self.conn.execute(
                "DELETE FROM feedback WHERE created_at<=?",
                (time.time() - days * 86400,))
            return cur.rowcount

    def recent_replies(self, session: str, n: int = 10) -> list[str]:
        rows = self.conn.execute(
            "SELECT reply FROM feedback WHERE session=? ORDER BY id DESC LIMIT ?",
            (session, n)).fetchall()
        return [r["reply"] for r in rows]
