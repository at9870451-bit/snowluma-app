"""prompt_builder — 动态提示词组装。

按需求书顺序组织（每次调用动态生成，不注入全部历史）：
  1. 系统规则与安全边界     → 由 QQBot ai.system_prompt / persona 承担（client.chat 内部）
  2. 当前对话场景与回复目标  → response_engine 的场景决策
  3. 相关短期聊天记录       → context_manager.render（Token 预算截取）
  4. 检索到的长期记忆       → fact_memory.recall（事实）+ lang_memory 锚点（旧账）
  5. 语言风格参数           → style_memory.get_style_summary + 互动标签
  6. 当前消息及具体任务     → client.chat 的 prompt 参数

本模块产出一个「注入片段」，通过 bot.style_hooks 挂载点拼进 system，
与 lang_memory / emotion 的注入互不冲突。
"""

from __future__ import annotations

import random
from typing import Any


def build_sections(
    *,
    scenario: str = "",
    context_block: str = "",
    fact_block: str = "",
    style_block: str = "",
    interaction_block: str = "",
    mood_note: str = "",
    max_chars: int = 1400,
) -> str:
    parts: list[str] = []
    if scenario:
        parts.append("[场景决策] " + scenario)
    if context_block:
        parts.append(context_block)
    if fact_block:
        parts.append(fact_block)
    if style_block:
        parts.append(style_block)
    if interaction_block:
        parts.append(interaction_block)
    if mood_note:
        parts.append(mood_note)
    text = "\n".join(p for p in parts if p)
    if len(text) > max_chars:
        text = text[:max_chars]
    return text


def fact_block_from(facts: list[dict[str, Any]]) -> str:
    if not facts:
        return ""
    lines = ["[已知事实·可直接使用，未确认的别当事实说]"]
    for f in facts[:5]:
        conf = float(f.get("confidence") or 0.8)
        mark = "" if conf >= 0.75 else "（低置信，用『好像是』的口吻）"
        lines.append(f"- {f['content']}{mark}")
    return "\n".join(lines)


def interaction_block_from(tags: list[dict[str, Any]]) -> str:
    if not tags:
        return ""
    top = [t for t in tags if t.get("confidence", 0) >= 0.4][:3]
    if not top:
        return ""
    lines = ["[互动风格·按对方习惯回应]"]
    for t in top:
        lines.append(f"- {t['tag']}（{t['confidence']:.0%}）：{t['scenario']}")
    return "\n".join(lines)


def scenario_note(*, is_group: bool, trigger_reason: str,
                  topic_shift: bool, already_answered: bool) -> str:
    bits: list[str] = []
    bits.append("群聊场景，回复大家都能看到，别只顾自说自话" if is_group
                else "私聊场景，一对一，可以更放松")
    if trigger_reason == "at_self":
        bits.append("对方在 @ 你，优先直接回应他的问题")
    elif trigger_reason == "keyword":
        bits.append("命中了关键词，围绕这个词接话")
    elif trigger_reason == "follow":
        bits.append("继续刚才的话题（短应答模式）")
    if already_answered:
        bits.append("这个话题你刚回答过，换个说法或补充新信息，别重复")
    elif topic_shift:
        bits.append("话题刚切换，先接住新话题")
    return "；".join(bits)


def style_decision(avg_len: float | None, mood: float | None,
                   rng: random.Random | None = None) -> str:
    """回复长度与语气微决策（不制造刻意波动，只做自然约束）。"""
    rng = rng or random.Random()
    bits = []
    if avg_len and avg_len < 8:
        bits.append("对方句子很短，你也用短句（5~15 字）")
    elif avg_len and avg_len > 25:
        bits.append("对方爱说长句，你可以稍微展开，但仍然单行")
    if mood is not None and mood < -30:
        bits.append("你现在心情差，语气可以冷一点或不耐烦一点，但不骂人不失态")
    if rng.random() < 0.12:
        bits.append("这次可以只回一两个字（嗯/哦/6），别每句都用力")
    return "；".join(bits)
