"""deep_thinking — 群聊思维画像引擎（规则式，零成本，增量更新）。

对每个群成员建立思维画像：
  信息处理（细节/整体/情绪/联系）、推理方式（演绎/归纳/溯因/假设/反事实）、
  认知深度（表层/机制/系统）、偏差信号（绝对化/过度自信）、讨论角色
  （观点提出/信息补充/逻辑检验/情绪调节/话题推动）。

设计原则（对齐需求书）：
  - 不贴固定标签：所有画像 = 计数 + 置信度，样本少自动打折
  - 列证据不给结论：每个画像保留 representative 样例
  - 随话题变化：画像分「全局稳定」与「近期（本次会话）」两层
"""

from __future__ import annotations

import re
import sqlite3
import threading
import time
from pathlib import Path
from typing import Any

SCHEMA = """
CREATE TABLE IF NOT EXISTS thinking (
    user_id    INTEGER PRIMARY KEY,
    group_id   INTEGER,
    msg_count  INTEGER DEFAULT 0,
    counters   TEXT DEFAULT '{}',
    samples    TEXT DEFAULT '{}',
    updated_at REAL
);
"""

# ---------- 规则词典 ----------

PATTERNS = {
    # 推理方式
    "deductive": re.compile(r"(肯定|一定|必然|所以|因此|那么就|肯定是)"),
    "inductive": re.compile(r"(好几次|每次|都这样|总是|一般|通常|反正)"),
    "abductive": re.compile(r"(为什么|为啥|咋回事|怎么回事|估计|可能是|大概是因为)"),
    "hypothetical": re.compile(r"(如果|假如|要是|假设|万一|要不)"),
    "counterfactual": re.compile(r"(要是当初|不然就|早知道|如果当时|不然的话)"),
    # 认知深度
    "mechanism": re.compile(r"(为什么|啥原理|怎么运作|什么原因|机制|逻辑是)"),
    "system": re.compile(r"(而且|同时|另外|再加上|一方面|不光|还牵扯|连锁)"),
    "meta": re.compile(r"(我想错了|重新想|我改口|是我记错|纠正一下|我说漏)"),
    # 偏差信号（出现 ≠ 偏差成立，只是标记供人工核）
    "absolute": re.compile(r"(都|所有|全部|绝对|肯定|百分之百|没人|人人)"),
    "overconfident": re.compile(r"(我确定|绝对是|肯定没错|不用想|铁定)"),
    # 情绪 vs 事实导向
    "emotion_lead": re.compile(r"(烦|气|乐|爱|爽|难顶|绝了|无语|笑死|绷不住|破防)"),
    "fact_lead": re.compile(r"(\d{2,}|昨天|今天|刚才|我试过|实测|数据|新闻|官方)"),
    # 讨论角色
    "idea_starter": re.compile(r"(要不|我想到|你们说|有没有可能|提个|问一下)"),
    "info_provider": re.compile(r"(我看过|我查了|据说|新闻说|之前我|我有个|举例)"),
    "logic_checker": re.compile(r"(不对吧|有毛病|证据呢|你确定|哪里看的|胡说|存疑)"),
    "soother": re.compile(r"(别急|没事|算了算了|都别吵|冷静|消消气|正常)"),
    "driver": re.compile(r"(所以说|结论是|那就|干脆|我去|就这么定|来来来)"),
}

# 画像维度 → 输出标签
LABELS = {
    "deductive": "演绎型（从规则推结论）",
    "inductive": "归纳型（从案例找规律）",
    "abductive": "溯因型（爱问为什么）",
    "hypothetical": "假设型（爱说如果）",
    "counterfactual": "反事实（会复盘如果当初）",
    "mechanism": "追问机制（想知道为什么）",
    "system": "系统视角（会连多个因素）",
    "meta": "元认知（会自我修正）",
    "absolute": "绝对化措辞（过度概括风险信号）",
    "overconfident": "高确定性措辞（过度自信信号）",
    "emotion_lead": "情绪先行（先接情绪再说事）",
    "fact_lead": "事实先行（给依据更有说服力）",
    "idea_starter": "观点提出者",
    "info_provider": "信息补充者",
    "logic_checker": "逻辑检验者",
    "soother": "情绪调节者",
    "driver": "话题推动者",
}


def analyze_text(text: str) -> dict[str, int]:
    """单条消息 → 特征计数。"""
    t = (text or "").strip()
    if len(t) < 2:
        return {}
    out: dict[str, int] = {}
    for key, pat in PATTERNS.items():
        m = pat.findall(t)
        if m:
            out[key] = out.get(key, 0) + len(m)
    if len(t) >= 30:
        out["long_msg"] = out.get("long_msg", 0) + 1
    return out


class ThinkingStore:
    def __init__(self, db_path: Path) -> None:
        self.path = Path(db_path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        conn = self._c()
        try:
            with conn:
                conn.executescript(SCHEMA)
        finally:
            conn.close()

    def _c(self) -> sqlite3.Connection:
        conn = sqlite3.connect(str(self.path), timeout=8.0, check_same_thread=False)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA journal_mode=WAL")
        return conn

    def update(self, user_id: int, group_id: int | None, text: str) -> None:
        hits = analyze_text(text)
        if not hits:
            return
        now = time.time()

        def fn(conn):
            row = conn.execute(
                "SELECT counters, samples, msg_count FROM thinking WHERE user_id=?",
                (user_id,)).fetchone()
            counters: dict[str, int] = {}
            samples: dict[str, str] = {}
            n = 0
            if row:
                try:
                    counters = json_loads(row["counters"])
                    samples = json_loads(row["samples"])
                    n = int(row["msg_count"] or 0)
                except Exception:
                    pass
            for k, v in hits.items():
                counters[k] = counters.get(k, 0) + v
                if k not in samples and len(text) <= 60:
                    samples[k] = text[:60]
            conn.execute(
                """INSERT INTO thinking(user_id,group_id,msg_count,counters,samples,updated_at)
                   VALUES(?,?,?,?,?,?)
                   ON CONFLICT(user_id) DO UPDATE SET msg_count=excluded.msg_count,
                     counters=excluded.counters, samples=excluded.samples,
                     group_id=excluded.group_id, updated_at=excluded.updated_at""",
                (user_id, group_id, n + 1,
                 json_dumps(counters), json_dumps(samples), now))

        with self._LOCK:
            conn = self._c()
            try:
                with conn:
                    fn(conn)
            finally:
                conn.close()

    _LOCK = threading.Lock()

    def profile(self, user_id: int) -> dict[str, Any] | None:
        conn = self._c()
        try:
            row = conn.execute("SELECT * FROM thinking WHERE user_id=?",
                               (user_id,)).fetchone()
        finally:
            conn.close()
        if not row:
            return None
        return {
            "user_id": user_id,
            "msg_count": int(row["msg_count"] or 0),
            "counters": json_loads(row["counters"]),
            "samples": json_loads(row["samples"]),
        }

    def delete(self, user_id: int) -> int:
        with self._LOCK:
            conn = self._c()
            try:
                with conn:
                    return conn.execute(
                        "DELETE FROM thinking WHERE user_id=?", (user_id,)).rowcount
            finally:
                conn.close()


def json_loads(s: str) -> dict:
    import json
    try:
        return json.loads(s or "{}")
    except Exception:
        return {}


def json_dumps(d: dict) -> str:
    import json
    return json.dumps(d, ensure_ascii=False)


def build_profile_summary(profile: dict[str, Any],
                          min_samples: int = 3) -> tuple[str, list[dict]]:
    """画像 → (注入摘要, 结构化标签)。样本少置信度减半。"""
    counters = profile.get("counters") or {}
    n = max(1, profile.get("msg_count") or 1)
    samples = profile.get("samples") or {}
    tags = []
    for key, cnt in sorted(counters.items(), key=lambda kv: -kv[1]):
        label = LABELS.get(key)
        if not label:
            continue
        conf = min(0.95, cnt / max(6, n * 0.25))
        if cnt < min_samples:
            conf *= 0.5
        if conf < 0.15:
            continue
        tags.append({"tag": label, "count": cnt, "confidence": round(conf, 2),
                     "sample": samples.get(key, ""), "kind":
                     "stable" if cnt >= min_samples else "tentative"})
        if len(tags) >= 6:
            break
    if not tags:
        return "", []
    lines = [f"[思维画像·{profile.get('msg_count')}条样本·按他的方式回应]"]
    for t in tags[:5]:
        lines.append(f"- {t['tag']}（{t['confidence']:.0%}）"
                     + (f" 例：「{t['sample'][:26]}」" if t["sample"] else ""))
    return "\n".join(lines), tags
