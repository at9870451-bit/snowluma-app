"""context_manager — 上下文理解系统。

职责：
  - 按会话保留最近 N 条消息（去重、时间戳排序、过期）
  - 按 Token 预算动态截取（中文按 ~1.6 字/token 估算）
  - 区分发言者（昵称+QQ），防张冠李戴
  - 引用消息解析、话题切换检测、已答问题识别
"""

from __future__ import annotations

import time
from collections import deque
from typing import Any

MAX_PER_SESSION = 60
DEFAULT_BUDGET_CHARS = 1200   # ≈ 750 token
_TTL_SECONDS = 30 * 60


def estimate_tokens(text: str) -> int:
    """粗略 token 估算：CJK ~1.6 字/token，ASCII ~4 字符/token。"""
    if not text:
        return 0
    cjk = sum(1 for ch in text if "\u4e00" <= ch <= "\u9fff")
    other = len(text) - cjk
    return int(cjk / 1.6 + other / 4) + 1


class ContextManager:
    def __init__(self) -> None:
        self._buf: dict[str, deque] = {}

    # ---------- 记录 ----------

    def add(self, session: str, user_id: int, name: str, text: str,
            msg_id: Any = None, reply_to: Any = None, ts: float | None = None) -> None:
        if not session:
            return
        buf = self._buf.setdefault(session, deque(maxlen=MAX_PER_SESSION))
        now = ts or time.time()
        # 去重：同 user + 同文本 60 秒内只记一次
        for item in reversed(buf):
            if now - item["ts"] > 60:
                break
            if item["user_id"] == user_id and item["text"] == text:
                item["ts"] = now
                return
        buf.append({
            "user_id": int(user_id or 0), "name": name or str(user_id),
            "text": text, "msg_id": msg_id, "reply_to": reply_to,
            "ts": now,
        })
        self._expire(buf)

    def _expire(self, buf: deque) -> None:
        now = time.time()
        while buf and now - buf[0]["ts"] > _TTL_SECONDS:
            buf.popleft()

    # ---------- 检索 ----------

    def recent(self, session: str, n: int = 6) -> list[dict[str, Any]]:
        buf = self._buf.get(session)
        if not buf:
            return []
        items = list(buf)
        self._expire(buf)
        return items[-n:]

    def render(self, session: str, n: int = 6,
               budget_chars: int = DEFAULT_BUDGET_CHARS) -> str:
        """渲染为提示词片段：带发言者名，按 Token 预算从最新往前截取。"""
        items = self.recent(session, n)
        if not items:
            return ""
        lines: list[str] = []
        used = 0
        for it in reversed(items):
            line = f"{it['name']}：{it['text']}"
            cost = estimate_tokens(line) * 2  # 中文×2字保守估算
            if used + cost > budget_chars and lines:
                break
            lines.append(line)
            used += cost
        lines.reverse()
        return (
            "【最近群聊记录（按时间顺序，供你理解上下文与指代）】\n"
            + "\n".join(lines)
            + "\n回复前先读：指代（他/这个/那）必须在上面找答案；接不上就问，绝不瞎猜。"
        )

    # ---------- 理解辅助 ----------

    @staticmethod
    def resolve_reference(session_items: list[dict[str, Any]], text: str) -> str:
        """识别指代词并尝试从上下文给出解释（供注入说明）。"""
        import re
        hints = []
        if re.search(r"他|她|它|那人|这个人", text):
            others = [i for i in session_items if i["user_id"] != 0][-5:]
            if others:
                hints.append("「他/她」可能指：" + "、".join(
                    f"{i['name']}(说过:{i['text'][:14]})" for i in others[-3:]))
        return "；".join(hints)

    @staticmethod
    def topic_shifted(items: list[dict[str, Any]]) -> bool:
        """简单话题切换检测：最近 2 条与之前 3 条的字符 bigram 重叠极低。"""
        if len(items) < 4:
            return False
        def grams(s: str) -> set[str]:
            t = "".join(s.split())
            return {t[i:i+2] for i in range(len(t)-1)}
        recent = grams("".join(i["text"] for i in items[-2:]))
        older = grams("".join(i["text"] for i in items[-5:-2]))
        if not recent or not older:
            return False
        inter = len(recent & older) / max(1, len(recent | older))
        return inter < 0.12

    @staticmethod
    def already_answered(items: list[dict[str, Any]], text: str) -> bool:
        """同一话题是否已被回答：bot 侧消息与该问题 bigram 重叠 ≥0.25 视为已覆盖。"""
        def grams(s: str) -> set[str]:
            t = "".join((s or "").split())
            return {t[i:i+2] for i in range(len(t)-1)}
        q = grams(text)
        if len(q) < 2:
            return False
        for it in items[-6:]:
            if it.get("user_id") == 0:
                r = grams(it["text"])
                if r and len(q & r) / max(1, len(q | r)) >= 0.25:
                    return True
        return False
