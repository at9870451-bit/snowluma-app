"""style_analyzer — 语言风格分析引擎（增强层）。

在 lang_memory.analyzer（词汇/语气/方言/流行语/节奏）基础上补充需求书要求：
  - 社交技巧：接梗、反问、吐槽、话题延续、委婉表达
  - 互动方式：主动提问、顺着回应、表达认同、提出异议、结束对话
  - 情绪特征：开心/疑惑/无奈/调侃/认真/冷淡
  - 结构化标签 + 置信度 + 适用场景，区分长期习惯与临时情绪
全部规则式、零成本、可增量累加。
"""

from __future__ import annotations

import re
from typing import Any

QUESTION_RE = re.compile(r"[?？]\s*$|^(为什么|怎么|啥|什么|哪|几|多少|能不能|要不要|是不是)")
AGREE_RE = re.compile(r"^(对|对对|是的|没错|确实|同意|行|好|可以|嗯+)")
DISAGREE_RE = re.compile(r"(不觉得|不对|不是吧|不同意|我不信|不至于|扯)")
ENDING_RE = re.compile(r"(先这样|我去忙|回聊|晚安|拜拜|下了|886)")
FOLLOWUP_RE = re.compile(r"(然后呢|后来|接着|所以呢|再说说|讲讲)")
TEASE_RE = re.compile(r"(哈哈哈|笑死|6|牛|绝了|可以啊|有点东西|整活)")
HELPFUL_RE = re.compile(r"(我帮你|我看看|我查下|我之前|我试过)")

HUMOR_MARKERS = ["哈哈哈", "笑死", "乐死", "给我整", "绷不住", "6", "典", "急了"]
COLD_MARKERS = ["哦", "嗯", "行吧", "随便", "无所谓", "就这"]

# 适用场景建议（按主导特征给回复策略提示）
SCENARIO_HINTS = {
    "humor": "对方爱开玩笑，可适度接梗、调侃，但别硬凹",
    "question": "对方在提问，直接回答；不确定就说不确定",
    "cold": "对方兴致不高，回复要短，别追着聊",
    "chatty": "对方话多，可稍展开，但仍保持单行",
}


def analyze_interaction(text: str) -> dict[str, Any]:
    """互动方式与社交技巧特征（计数式，可跨消息累加）。"""
    t = (text or "").strip()
    if not t:
        return {}
    hits: dict[str, int] = {}

    def bump(k: str, v: int = 1) -> None:
        hits[k] = hits.get(k, 0) + v

    if QUESTION_RE.search(t):
        bump("ask")
    if AGREE_RE.search(t):
        bump("agree")
    if DISAGREE_RE.search(t):
        bump("disagree")
    if ENDING_RE.search(t):
        bump("ending")
    if FOLLOWUP_RE.search(t):
        bump("followup")
    if TEASE_RE.search(t):
        bump("tease")
    if any(m in t for m in HUMOR_MARKERS):
        bump("humor")
    if any(m in t for m in COLD_MARKERS) and len(t) <= 6:
        bump("cold")
    if HELPFUL_RE.search(t):
        bump("helpful")
    if len(t) >= 25:
        bump("long_msg")
    return hits


def summarize_interaction(hits: dict[str, int], min_samples: int = 3) -> list[dict[str, Any]]:
    """结构化标签：标签 + 置信度 + 说明。样本少于阈值时置信度打折。"""
    total = sum(hits.values()) or 1
    defs = [
        ("ask", "主动提问", "常向别人提问，回复可准备被追问"),
        ("agree", "表达认同", "常顺话头认同，可多用『对/是』开场"),
        ("disagree", "提出异议", "会直接反驳，可接受争辩式聊天"),
        ("tease", "接梗吐槽", "吃调侃，回复可带梗"),
        ("humor", "幽默倾向", "气氛轻松，可适度玩梗"),
        ("cold", "冷淡/敷衍", "常给短句，回复宜更短更随性"),
        ("helpful", "乐于帮忙", "爱给建议，可交换经验口吻"),
        ("followup", "话题延续", "爱追问细节，回复留话头"),
        ("ending", "干净收尾", "说完就停，不强行延续话题"),
        ("long_msg", "长文型", "偶尔能接受长回复"),
    ]
    out = []
    for key, label, scenario in defs:
        n = hits.get(key, 0)
        if n <= 0:
            continue
        conf = min(0.95, n / max(total, 5))
        if n < min_samples:
            conf *= 0.5  # 样本不足，置信度减半（避免少量样本误判）
        out.append({
            "tag": label, "count": n,
            "confidence": round(conf, 2),
            "scenario": SCENARIO_HINTS.get(key, scenario),
            "kind": "stable" if n >= min_samples else "tentative",
        })
    out.sort(key=lambda x: -x["confidence"])
    return out


def dominant_mood(hits: dict[str, int]) -> str:
    """主导情绪特征（粗粒度）。"""
    if hits.get("humor") or hits.get("tease"):
        return "开心/调侃"
    if hits.get("cold"):
        return "冷淡"
    if hits.get("disagree"):
        return "较真"
    if hits.get("ask"):
        return "好奇"
    return "日常"
