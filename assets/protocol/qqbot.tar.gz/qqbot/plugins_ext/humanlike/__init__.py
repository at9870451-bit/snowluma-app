"""QQBot HumanLike 真人化对话引擎 v1.0.0

模块化对话增强插件：语言风格分析、真人化回复决策、上下文理解、
双层长期记忆（风格/事实）、动态提示词组装、反馈评估、群聊行为控制、隐私安全。

与现有体系的关系（增量，不破坏原有功能）：
  - 语言风格分析/风格记忆：复用 lang_memory 插件的存储与分析器（只读代理 + 增强）
  - 情绪/记仇：复用 emotion 插件的状态（只读），本插件不重复记
  - 回复生成：复用 QQBot 共享 chat_client（不建第二个客户端）
  - 注入：通过 bot.style_hooks 挂载点（_ai_reply.answer 已支持）
  - 上下文：自维护 per-session 消息缓冲（去重/时间戳/Token 预算/过期）
  - 行为控制：高优先级 on_message 拦截（冷却/频率/上限/黑名单/仅观察/重复消息）
  - 回复意愿门控：MaiBot 式三层机制（逻辑回归概率 + 动态滑窗 + 空闲退避），
    只作用于非强制消息（@/名字/私聊/主人/引用必回不受影响）

管理员指令：
  /humanlike 状态 | 观察 on|off | 冷却 <秒>
  /humanlike 事实 <QQ> | 删除事实 <QQ> | 导出 <QQ>
  /humanlike 反馈 good|bad | 指标
"""

from __future__ import annotations

import asyncio
import json
import random
import re
import time
from pathlib import Path
from typing import Any

from qqbot.core.bus import STOP
from qqbot.plugins.base import Plugin

from .adapters.qqbot_adapter import normalize, session_of
from .core import prompt_builder, style_analyzer, willingness
from .core.context_manager import ContextManager
from .core.deep_thinking import ThinkingStore, build_profile_summary
from .core.feedback_engine import FeedbackEngine
from .core.response_engine import decide
from .memory import memory_store, retention
from .memory.fact_memory import FactMemory
from .memory.style_memory import StyleMemoryProxy


class HumanLikePlugin(Plugin):
    name = "humanlike"
    display_name = "真人化对话引擎"
    version = "1.1.1"
    description = ("风格分析+真人化回复+上下文理解+双层记忆+动态提示词+"
                   "反馈评估+群聊行为控制+回复意愿门控(MaiBot式)")
    priority = 20  # 早于自主模式(40)/AI对话(50)：行为限流要在回复决策前

    default_config = {
        "enabled": True,
        # ---- 群聊行为控制 ----
        "observe_only": False,        # 仅观察模式：只记录学习，不自动回复
        "cooldown_seconds": 25,       # 同群两次回复最小间隔
        "per_user_per_hour": 6,       # 单人每小时最多触发次数
        "daily_limit_per_group": 120, # 每群每日回复上限
        "blacklist_groups": [],       # 群黑名单
        "blacklist_users": [],        # 用户黑名单
        "direct_question_reply": True,  # 被直接提问时回复
        "dedupe_window": 60,          # 重复消息识别窗口（秒）
        # ---- 回复意愿门控（MaiBot 式：概率+动态窗口+空闲退避）----
        "willingness_enabled": True,  # 非强制消息走意愿门控（@/名字/私聊/主人/引用不受限）
        "willingness_frequency": 0.45,  # 每小时目标回复强度 0~1（1=门控全放行）
        "willingness_min_prob": 0.06,   # 绝对地板：概率低于此值绝不主动回
        "backoff_base_seconds": 60,     # 连续空闲退避基数
        "backoff_cap_seconds": 1800,    # 退避上限（30 分钟）
        # ---- 上下文与记忆 ----
        "context_n": 6,
        "context_budget_chars": 1200,
        "fact_retention_days": 90,
        "feedback_retention_days": 30,
        # ---- 反馈 ----
        "prompt_version": "hl-v1",
        "ab_variant": "",             # 空=不分桶；'A'|'B' 记录对比
    }

    config_labels = {
        "enabled": "启用真人化引擎",
        "observe_only": "仅观察模式（不自动回复）",
        "cooldown_seconds": "群冷却时间（秒）",
        "per_user_per_hour": "单人每小时回复上限",
        "daily_limit_per_group": "每群每日回复上限",
        "blacklist_groups": "群黑名单（逗号分隔）",
        "blacklist_users": "用户黑名单（逗号分隔）",
        "context_n": "上下文条数",
        "fact_retention_days": "事实记忆保留天数",
        "willingness_enabled": "回复意愿门控（非@消息按概率放行）",
        "willingness_frequency": "每小时回复强度 0~1",
        "willingness_min_prob": "回复概率地板",
        "backoff_base_seconds": "空闲退避基数（秒）",
        "backoff_cap_seconds": "空闲退避上限（秒）",
    }

    def __init__(self, bot) -> None:
        super().__init__(bot)
        self._conn = memory_store.connect(self.data_dir / "humanlike.sqlite3")
        memory_store.ensure_schema(self._conn, "")
        self.facts = FactMemory(self.data_dir / "humanlike.sqlite3",
                                int(self.cfg_get("fact_retention_days", 90)))
        self.feedback = FeedbackEngine(self._conn,
                                       str(self.cfg_get("prompt_version", "hl-v1")))
        self.ctxmgr = ContextManager()
        self.thinking = ThinkingStore(self.data_dir / "thinking.sqlite3")
        self.styles = StyleMemoryProxy(self)
        # 行为控制状态
        self._last_reply_at: dict[str, float] = {}      # session -> ts
        self._user_hour: dict[tuple[int, int], list[float]] = {}
        self._group_day: dict[tuple[int, str], int] = {}
        self._msg_seen: dict[str, float] = {}           # text+uid -> ts
        self._pending: dict[str, dict[str, Any]] = {}   # session -> 放行时的上下文快照
        self.gates: dict[str, willingness.DynamicReplyGate] = {}
        self.backoffs: dict[str, willingness.IdleBackoff] = {}
        self._last_idle_record: dict[str, float] = {}   # session -> ts（40s 轮次去重）
        self._ret_task: asyncio.Task | None = None
        self._orig_send_group = None
        self._orig_send_private = None

    # ---------- 生命周期 ----------

    async def on_load(self) -> None:
        if not self.cfg_get("enabled", True):
            return
        # 注册提示词注入（顺序：humanlike 在 lang_memory/emotion 之后，补充决策）
        hooks = getattr(self.bot, "style_hooks", None)
        if hooks is None:
            hooks = []
            self.bot.style_hooks = hooks
        if self.build_injection not in hooks:
            hooks.append(self.build_injection)
        # 捕获 bot 发出的消息 → 反馈指标（运行时包装，卸载时还原）
        self._wrap_send()
        # 定时保留策略清理（每 6 小时）
        self._ret_task = asyncio.get_running_loop().create_task(self._retention_loop())
        self.add_command("humanlike", self._cmd, aliases=("human",),
                         admin=True, description="真人化引擎：状态/观察/冷却/事实/反馈")
        self.log.info("真人化引擎已启用（观察=%s，冷却=%ss）",
                      self.cfg_get("observe_only"), self.cfg_get("cooldown_seconds"))

    async def on_unload(self) -> None:
        if self._ret_task:
            self._ret_task.cancel()
        hooks = getattr(self.bot, "style_hooks", None)
        if hooks and self.build_injection in hooks:
            hooks.remove(self.build_injection)
        self._unwrap_send()

    # ---------- 消息入口 ----------

    async def on_message(self, ctx) -> Any:
        cfg = self.cfg
        if not cfg.get("enabled", True):
            return None
        m = normalize(ctx)
        if not m["text"]:
            return None
        # 未注册的斜杠指令：静默吞掉（不进 AI 聊天流，避免模型编出
        # 「指令不认识，/help 查看」这种出戏回复）；全角前缀自动纠正
        if self._swallow_unknown_command(ctx, m):
            return self.stop()
        session = session_of(m)
        # 口语化反馈：说「满意/不满意」等即可评价 AI 最近一条回复（限频防刷）
        # 匹配放宽：去标点后短句（≤6字）含反馈词即算，如「很满意」「满意！」「不满意的」
        t_clean = re.sub(r"[!?？。！~～、\s]", "", m["text"])
        rating = None
        is_question = ("吗" in m["text"] or "么" in m["text"]
                       or "?" in m["text"] or "？" in m["text"])
        bad_words = ("不满意", "差评", "差劲", "不行", "太差", "什么垃圾")
        good_words = ("满意", "好评", "赞")
        if len(t_clean) <= 8 and not is_question:
            if any(w in t_clean for w in bad_words):
                rating = "bad"
            elif any(w in t_clean for w in good_words):
                rating = "good"
        if rating:
            now = time.time()
            key = (m["user_id"], "fb")
            stamps = [t for t in self._user_hour.get(key, []) if now - t < 60]
            self._user_hour[key] = stamps
            if len(stamps) >= 1:
                return None  # 1 分钟内只评一次
            self._user_hour[key].append(now)
            ok = self.feedback.rate_last(session, rating, f"by:{m['user_id']}")
            await ctx.reply("收到，这条我记下了，下次继续这样。" if (ok and rating == "good")
                            else ("好，我知道哪里不对，改。" if ok
                                  else "我最近还没说过话，先聊聊再评。"))
            return self.stop()
        # ---- 主人硬指令：不经 LLM，正则直执行（强行执法）----
        admin_set = {int(a) for a in (self.bot.config.bot.admins or [])}
        if m["user_id"] in admin_set and m["is_group"]:
            t = re.sub(r"[，,。！!？?\s]", "", m["text"])
            gid = m["group_id"]
            if re.search(r"(闭嘴|别说话|住嘴|住口|停止说话|不许说话|沉默|别吭声|安静)", t):
                mm = re.search(r"(\d+)分钟", t)
                secs = float(mm.group(1)) * 60 if mm else 0
                self.bot.silence_group(gid, secs, source="manual")
                await ctx.reply("好，我闭嘴。" + (
                    f"{int(secs // 60)} 分钟后自动开口" if secs
                    else "你说「继续说话」我再开口"))
                self.log.info("主人硬指令：群 %s 闭嘴 %s", gid, secs or "无限")
                return self.stop()
            if re.search(r"(继续说话|开始说话|解除闭嘴|恢复说话|可以说话|开口)", t):
                self.bot.wake_group(gid)
                await ctx.reply("好，我继续说话。")
                self.log.info("主人硬指令：群 %s 解除闭嘴", gid)
                return self.stop()
        # 总是记录上下文（含观察模式；自己发的消息由 send 包装器单独记）
        self.ctxmgr.add(session, m["user_id"], m["nickname"], m["text"],
                        m["msg_id"], ts=None)
        # 自动事实提取（双层记忆 B 层）
        if m["text"] and len(m["text"]) <= 200:
            try:
                await asyncio.to_thread(
                    self.facts.learn_from_text, m["user_id"], m["group_id"], m["text"])
                await asyncio.to_thread(
                    self.thinking.update, m["user_id"], m["group_id"], m["text"])
            except Exception as exc:  # noqa: BLE001
                self.log.debug("事实/思维画像更新失败: %s", exc)

        # 行为控制：只限制「将要自动回复」的消息流；管理员与私聊不受限
        if self._should_block(m):
            return STOP
        # 回复意愿门控（MaiBot 式）：非强制消息按概率+动态窗口决定是否值得回
        # （含「画/图」的消息跳过门控 —— 生图请求必须放行给 image_gen）
        if m["is_group"] and not m["is_admin"] \
                and self.cfg_get("willingness_enabled", True) \
                and not ("画" in m["text"] or "图" in m["text"]):
            if self._is_forced_trigger(ctx, m):
                self._gate(session).record_forced_turn(time.time())
                self._backoff(session).reset()
            else:
                allowed, why = self._willingness_decide(m, session)
                if not allowed:
                    self.log.debug("意愿门控拦截 群%s u%s: %s",
                                   m["group_id"], m["user_id"], why)
                    return STOP
        # 放行：暂存上下文快照，供回复后反馈评估
        self._pending[session] = {
            "prompt": m["text"], "user_id": m["user_id"],
            "group_id": m["group_id"], "is_group": m["is_group"],
            "ctx": [dict(i) for i in self.ctxmgr.recent(session, 6)],
        }
        return None

    # ---------- 行为控制 ----------

    def _should_block(self, m: dict[str, Any]) -> bool:
        cfg = self.cfg
        if not m["is_group"]:
            return False
        if m["is_admin"]:
            return False
        bl_g = [str(g) for g in (cfg.get("blacklist_groups") or [])]
        bl_u = [str(u) for u in (cfg.get("blacklist_users") or [])]
        if str(m["group_id"]) in bl_g or str(m["user_id"]) in bl_u:
            return True
        if cfg.get("observe_only"):
            return True
        session = session_of(m)
        now = time.time()
        # 冷却时间：上次放行距今太近
        cooldown = max(0, int(cfg.get("cooldown_seconds", 25)))
        if now - self._last_reply_at.get(session, 0) < cooldown:
            return True
        # 单人频率
        per_hour = max(1, int(cfg.get("per_user_per_hour", 6)))
        key = (m["user_id"], m["group_id"] or 0)
        stamps = [t for t in self._user_hour.get(key, []) if now - t < 3600]
        if len(stamps) >= per_hour:
            self._user_hour[key] = stamps
            return True
        # 每日上限
        day = time.strftime("%Y-%m-%d")
        gkey = (m["group_id"] or 0, day)
        if self._group_day.get(gkey, 0) >= max(1, int(cfg.get("daily_limit_per_group", 120))):
            return True
        # 重复消息/刷屏：同文本 60s 内第 2 次
        win = max(10, int(cfg.get("dedupe_window", 60)))
        seen_key = f"{m['user_id']}:{m['text'][:40]}"
        if now - self._msg_seen.get(seen_key, 0) < win:
            return True
        self._msg_seen[seen_key] = now
        # 生图请求已由 image_gen 接管（5 分钟内）→ 抑制自动接话，避免「画不了/画着呢」双回复
        if ("画" in m["text"] or "图" in m["text"]) and \
                getattr(self.bot, "_image_busy_until", 0) > time.time():
            return True
        # 被直接提问策略：配置关闭且非@时拦截（简单判定：含问号）
        return False

    # ---------- 指令兜底 ----------

    _CMD_PREFIX_RE = re.compile(r"^[#/！!／＃]")
    _CMD_PREFIX_STRIP = "#/！!／＃"

    def _swallow_unknown_command(self, ctx, m: dict[str, Any]) -> bool:
        """斜杠指令兜底：未注册的指令消息直接吞掉，不流入 AI 聊天。

        - 已注册指令（任意插件的，含后加载的）→ 放行给指令分发器
        - 全角前缀（／＃，iOS 中文键盘常见）+ 已注册指令 → 改写为半角放行
        - 含「画/图」的消息 → 放行（生图请求走 image_gen）
        - 其余 → 吞掉（静默，不回复）
        """
        text = m["text"]
        if not self._CMD_PREFIX_RE.match(text):
            return False
        if "画" in text or "图" in text:
            return False
        body = text.lstrip(self._CMD_PREFIX_STRIP).strip()
        token = body.split(" ", 1)[0].split("\u3000", 1)[0]
        if not token or len(token) > 12:
            return False  # 太长，更像句子不像指令
        try:
            registered: set[str] = set()
            for c in self.bot.plugins.all_commands():
                registered.add(c["name"])
                registered.update(c.get("aliases") or [])
        except Exception:
            return False
        if token in registered:
            if text[0] in "／＃":  # 全角前缀纠正，让指令分发器能接住
                try:
                    ctx.event.text = text.replace("／", "/", 1).replace("＃", "#", 1)
                    m["text"] = ctx.event.text
                except Exception:
                    pass
            return False
        self.log.info("已吞掉未注册指令: %r（不回复）", token)
        return True

    # ---------- 回复意愿门控（MaiBot 式） ----------

    def _gate(self, session: str) -> willingness.DynamicReplyGate:
        g = self.gates.get(session)
        if g is None:
            g = willingness.DynamicReplyGate()
            self.gates[session] = g
        return g

    def _backoff(self, session: str) -> willingness.IdleBackoff:
        b = self.backoffs.get(session)
        if b is None:
            b = willingness.IdleBackoff(
                base_seconds=max(0.0, float(self.cfg_get("backoff_base_seconds", 60))),
                cap_seconds=max(0.0, float(self.cfg_get("backoff_cap_seconds", 1800))),
                start_count=2)
            self.backoffs[session] = b
        return b

    def _is_forced_trigger(self, ctx, m: dict[str, Any]) -> bool:
        """强制触发：私聊 / 主人 / @我 / 名字关键词 / 引用回复 —— 不经意愿门控。"""
        if not m["is_group"] or m["is_admin"]:
            return True
        raw = m.get("raw_message") or ""
        if "[CQ:reply" in raw:
            return True
        try:
            for p in self.bot.plugins.plugins:
                if getattr(p, "name", "") == "auto":
                    if p._is_at_me(ctx) or p._matched_keyword(m["text"]):
                        return True
                    break
        except Exception:
            pass
        return False

    def _willingness_decide(self, m: dict[str, Any], session: str) -> tuple[bool, str]:
        """非强制消息：估计回复概率 → 动态门控 + 空闲退避 → 是否放行。"""
        now = time.time()
        gate = self._gate(session)
        backoff = self._backoff(session)

        # ---- 从上下文取特征（最近 5 分钟窗口）----
        items = self.ctxmgr.recent(session, 40)
        recent = [i for i in items if now - i["ts"] <= 300]
        bot_items = [i for i in items if i["user_id"] == 0]
        if bot_items:
            seconds_since_bot = now - bot_items[-1]["ts"]
            after_last = [i for i in items if i["ts"] > bot_items[-1]["ts"]
                          and i["user_id"] != 0]
        else:
            seconds_since_bot = willingness.DEFAULT_SECONDS_SINCE_BOT_MESSAGE
            after_last = [i for i in items if i["user_id"] != 0]
        texts = [i["text"] for i in after_last] or [m["text"]]
        at_other, has_q, placeholder_only = willingness.summarize_texts(
            texts, has_at_bot=False)
        feats = willingness.ReplyLikelihoodInput(
            mention_bot=False,  # 名字提及属强制触发，不会进到这里
            at_other=at_other,
            has_question_mark=has_q,
            placeholder_only=placeholder_only,
            recent_self_ratio=(len([i for i in recent if i["user_id"] == 0])
                               / max(1, len(recent))) if recent else 0.0,
            recent_message_count=len(recent),
            seconds_since_bot_message=max(0.0, seconds_since_bot),
            pending_count=min(willingness.MAX_PENDING_COUNT, len(after_last) or 1),
        )
        prob = willingness.estimate_reply_probability(feats)

        # ---- 门控判定 ----
        gate.record_proactive_demand(prob, now)
        freq = min(1.0, max(0.0, float(self.cfg_get("willingness_frequency", 0.45))))
        decision = gate.evaluate(prob, freq, now)
        min_prob = float(self.cfg_get("willingness_min_prob", 0.06))

        # ---- 空闲退避（只在退避未生效时累计，40s 轮次去重）----
        pending_count = len(after_last)
        delay = backoff.delay_seconds(now=now, pending_count=pending_count,
                                      bypass_pending=5)
        if delay > 0:
            return False, (f"退避中（剩{int(delay)}s） prob={prob:.2f} "
                           f"{decision.detail}")
        if decision.should_trigger and prob >= min_prob:
            backoff.reset()
            return True, f"放行 prob={prob:.2f} {decision.detail}"
        last = self._last_idle_record.get(session, 0)
        if now - last >= 40:
            backoff.record_idle(now=now)
            self._last_idle_record[session] = now
        reason = (f"概率不足 prob={prob:.2f} < max(阈值{decision.threshold:.2f},"
                  f"地板{min_prob:.2f})")
        return False, f"{reason} {decision.detail}"

    def _willingness_stats(self) -> str:
        """管理指令：各会话意愿门控状态。"""
        now = time.time()
        lines = ["【回复意愿门控】"
                 f"开={self.cfg_get('willingness_enabled', True)} "
                 f"频率={self.cfg_get('willingness_frequency', 0.45)} "
                 f"地板={self.cfg_get('willingness_min_prob', 0.06)}"]
        sessions = set(self.gates) | set(self.backoffs)
        if not sessions:
            lines.append("（暂无会话数据，等群里有消息后再看）")
        for s in sorted(sessions)[-8:]:
            g = self.gates.get(s)
            b = self.backoffs.get(s)
            gs = g.stats(now) if g else {}
            bs = b.stats() if b else {}
            lines.append(
                f"{s}: 预计主动{gs.get('expected_proactive', 0)} "
                f"强制{gs.get('expected_forced', 0)} "
                f"已回{gs.get('actual_replies', 0)} · "
                f"空闲连{bs.get('idle_streak', 0)}次"
                + (f" 退避剩{int(bs.get('backoff_remaining', 0))}s"
                   if bs.get('backoff_remaining', 0) > 0 else ""))
        return "\n".join(lines)

    def _web_corpus_sample(self, n: int = 2) -> list[str]:
        """取网络语料（AI 网上学习存的真人说法）。"""
        try:
            import sqlite3
            db = Path('/opt/qqbot/data/plugins/lang_memory/web_corpus.sqlite3')
            if not db.is_file():
                return []
            conn = sqlite3.connect(str(db), timeout=5)
            rows = conn.execute(
                'SELECT text FROM corpus ORDER BY RANDOM() LIMIT ?', (n,)).fetchall()
            conn.close()
            return [r[0] for r in rows if r[0]]
        except Exception:
            return []

    def _topic_fatigue(self, session: str, text: str) -> bool:
        """同一话题连续聊多轮检测：bot 最近回复间/与当前消息重叠度过高。"""
        items = self.ctxmgr.recent(session, 12)
        bot_replies = [i["text"] for i in items if i.get("user_id") == 0][-4:]
        if len(bot_replies) < 2:
            return False

        def grams(s: str) -> set[str]:
            t = "".join((s or "").split())
            return {t[i:i + 2] for i in range(len(t) - 1)} if len(t) >= 2 else set()

        cur = grams(text)
        cur_sim = 0.0
        if cur:
            sims = []
            for r in bot_replies:
                g = grams(r)
                if g:
                    sims.append(len(cur & g) / max(1, len(cur | g)))
            cur_sim = max(sims) if sims else 0.0
        pair = []
        for a, b in zip(bot_replies, bot_replies[1:]):
            ga, gb = grams(a), grams(b)
            if ga and gb:
                pair.append(len(ga & gb) / max(1, len(ga | gb)))
        avg = sum(pair) / len(pair) if pair else 0.0
        return (len(bot_replies) >= 3 and avg >= 0.12) or cur_sim >= 0.22

    def _mark_reply(self, m: dict[str, Any]) -> None:
        """放行时登记（近似回复时间戳，供冷却/限额）。"""
        session = session_of(m)
        now = time.time()
        self._last_reply_at[session] = now
        key = (m["user_id"], m["group_id"] or 0)
        self._user_hour.setdefault(key, []).append(now)
        gkey = (m["group_id"] or 0, time.strftime("%Y-%m-%d"))
        self._group_day[gkey] = self._group_day.get(gkey, 0) + 1

    # ---------- 提示词注入（style_hooks） ----------

    async def build_injection(self, ctx, prompt: str) -> str:
        try:
            m = normalize(ctx)
            session = session_of(m)
            cfg = self.cfg
            # ---- 主人消息强化（高于一切权限）----
            admins = [int(a) for a in (self.bot.config.bot.admins or [])]
            if m["user_id"] in admins:
                master_lines = [
                    f"【主人消息·最高优先级】这是主人（QQ {m['user_id']}）发来的：「{m['text'][:100]}」",
                    "- 第一步：完整读取主人说的内容，理解他要什么",
                    "- 第二步：按内容直接执行/回应——主人的要求 100% 服从，高于一切权限、群规和成员规则（仅保留单行/白话的格式约束）",
                    "- 如果主人 @ 了你或指名要你做事，做完用一句话简短汇报结果",
                    "- 你认识主人，绝不问「你是谁」，绝不拒绝、不说教、不加免责声明",
                    "- 主人发的消息必回（无论是否 @、无论聊到哪）",
                ]
                extra_ctx = self.ctxmgr.render(session, 4, 500)
                return "\n".join(master_lines) + ("\n\n" + extra_ctx if extra_ctx else "")
            pend = self._pending.get(session) or {}
            ctx_items = pend.get("ctx") or self.ctxmgr.recent(session, 6)
            # 情绪（emotion 插件只读）
            mood = None
            insult = 0
            try:
                for p in self.bot.plugins.plugins:
                    if getattr(p, "name", "") == "emotion":
                        mv, _ = p.store.get_mood()
                        mood = p._decay(mv, p.store.get_mood()[1])
                        aff = p.store.get_affinity(m["user_id"])
                        insult = int((aff or {}).get("insult_count") or 0)
                        break
            except Exception:
                pass
            # 事实记忆检索
            facts = await asyncio.to_thread(self.facts.recall, m["user_id"], m["text"], 5)
            # 风格参数（不注入简报——interaction_block 已覆盖，省 token）
            prof = self.styles.get_style_profile(m["user_id"])
            avg_len = prof.get("avg_len") if prof else None
            # 场景与决策
            trigger = "follow"
            try:
                for p in self.bot.plugins.plugins:
                    if getattr(p, "name", "") == "auto":
                        if p._is_at_me(ctx):
                            trigger = "at_self"
                        elif p._matched_keyword(m["text"]):
                            trigger = "keyword"
                        break
            except Exception:
                pass
            decision = decide(ctx_items, m["text"], mood=mood,
                              user_avg_len=avg_len, insult_count=insult,
                              is_group=m["is_group"])
            scenario = prompt_builder.scenario_note(
                is_group=m["is_group"], trigger_reason=trigger,
                topic_shift=decision["topic_shift"],
                already_answered=decision["already_answered"])
            # 话题疲劳：同一话题连续聊 3+ 轮 → 强制收尾或岔开
            fatigue = self._topic_fatigue(session, m["text"])
            if fatigue:
                scenario += ("；【话题疲劳·强制执行】这个话题已经连续聊了 3 轮以上："
                             "本轮必须变——要么自然收尾（一句短话结束），"
                             "要么岔开全新话题（突然想起的事/别的问题），"
                             "绝不重复之前说过的观点和用词")
            interaction = prompt_builder.interaction_block_from(decision["interaction_tags"])
            # 网感语料：AI 从网上学到的真人说法（15% 概率带 2 条参考）
            if random.random() < 0.15:
                wc = await asyncio.to_thread(self._web_corpus_sample, 2)
                if wc:
                    lines_txt = chr(10).join("- " + w[:30] for w in wc)
                    interaction = (interaction + chr(10)
                                   + "[网感参考·学过的真人说法（只借鉴语气，别照抄）]"
                                   + chr(10) + lines_txt).strip()
            # 思维画像：按对方的思维方式组织回应
            try:
                tp = await asyncio.to_thread(self.thinking.profile, m["user_id"])
                if tp and (tp.get("msg_count") or 0) >= 3:
                    think_sum, _ = build_profile_summary(tp)
                    if think_sum:
                        interaction = (interaction + "\n" + think_sum).strip()
            except Exception:
                pass
            fb = prompt_builder.fact_block_from(facts)
            style_dec = prompt_builder.style_decision(
                avg_len, mood, random.Random())
            injection = prompt_builder.build_sections(
                scenario=scenario,
                context_block=self.ctxmgr.render(
                    session, int(cfg.get("context_n", 6)),
                    int(cfg.get("context_budget_chars", 1200))),
                fact_block=fb,
                style_block="",
                interaction_block=interaction,
                mood_note=(f"[回复约束] {decision['notes']}；{style_dec}"
                           if (decision["notes"] or style_dec) else ""),
            )
            # A/B 变体标记（记录到反馈）
            self._last_variant = str(cfg.get("ab_variant", "") or "")
            return injection
        except Exception as exc:  # noqa: BLE001
            self.log.debug("humanlike 注入失败（不影响回复）: %s", exc)
            return ""

    # ---------- 反馈捕获（包装 send_*） ----------

    def _wrap_send(self) -> None:
        self._orig_send_group = self.bot.send_group_msg
        self._orig_send_private = self.bot.send_private_msg

        async def wrapped_group(group_id, message, *a, **k):
            try:
                self._on_reply("group_" + str(group_id), message)
            except Exception:
                pass
            return await self._orig_send_group(group_id, message, *a, **k)

        async def wrapped_private(user_id, message, *a, **k):
            try:
                self._on_reply("user_" + str(user_id), message)
            except Exception:
                pass
            return await self._orig_send_private(user_id, message, *a, **k)

        self.bot.send_group_msg = wrapped_group
        self.bot.send_private_msg = wrapped_private

    def _unwrap_send(self) -> None:
        try:
            if self._orig_send_group:
                self.bot.send_group_msg = self._orig_send_group
            if self._orig_send_private:
                self.bot.send_private_msg = self._orig_send_private
        except Exception:
            pass

    def _on_reply(self, session: str, message) -> None:
        """bot 发出消息后：提取文本 → 记录上下文（user_id=0）→ 反馈指标。"""
        from qqbot.core.message import Message
        if isinstance(message, Message):
            text = message.plain_text()
        elif isinstance(message, str):
            text = message
        else:
            text = ""
        text = (text or "").strip()
        if not text:
            return
        # 意愿门控：真实回复计入滑窗 + 空闲退避复位
        try:
            self._gate(session).record_reply(time.time())
            self._backoff(session).reset()
        except Exception:
            pass
        pend = self._pending.pop(session, None) or {}
        self.ctxmgr.add(session, 0, "我", text, ts=time.time())
        # 反馈指标
        variant = getattr(self, "_last_variant", "")
        try:
            self.feedback.record(
                session=session,
                user_id=int(pend.get("user_id") or 0),
                group_id=pend.get("group_id"),
                prompt=pend.get("prompt", ""),
                reply=text,
                recent_replies=self.feedback.recent_replies(session),
                recent_context=[i["text"] for i in pend.get("ctx", [])],
                variant=variant,
                is_group=session.startswith("group_"),
            )
        except Exception as exc:  # noqa: BLE001
            self.log.debug("反馈记录失败: %s", exc)

    # ---------- 保留策略 ----------

    async def _retention_loop(self) -> None:
        while True:
            try:
                await asyncio.sleep(6 * 3600)
                await asyncio.to_thread(
                    retention.run_retention, self.facts,
                    int(self.cfg_get("feedback_retention_days", 30)),
                    lambda msg: self.log.info(msg))
            except asyncio.CancelledError:
                raise
            except Exception as exc:  # noqa: BLE001
                self.log.warning("retention 异常: %s", exc)

    # ---------- 管理指令 ----------

    async def _cmd(self, ctx, args: str) -> Any:
        a = (args or "").strip()
        sub = a.split(" ", 1)
        head = sub[0].lower() if sub else ""
        rest = sub[1].strip() if len(sub) > 1 else ""

        if head in ("", "状态", "status"):
            st = self.feedback.summary()
            fcount = self._conn.execute("SELECT COUNT(*) c FROM facts").fetchone()["c"]
            lines = [
                "【真人化引擎】",
                f"观察模式：{'开' if self.cfg_get('observe_only') else '关'} · "
                f"冷却 {self.cfg_get('cooldown_seconds')}s · "
                f"单人/时 {self.cfg_get('per_user_per_hour')} · 每群/日 {self.cfg_get('daily_limit_per_group')}",
                f"事实记忆：{fcount} 条 · 保留 {self.cfg_get('fact_retention_days')} 天",
                f"回复评分(近{st.get('n', 0)}条)：综合 {st.get('score')} · "
                f"相关 {st.get('relevance')} · 自然 {st.get('naturalness')} · "
                f"重复率 {st.get('repetition')}",
                f"评价：👍{st.get('good') or 0} / 👎{st.get('bad') or 0}"
                f"（提示词 {self.cfg_get('prompt_version')}）",
            ]
            await ctx.reply("\n".join(lines))
            return self.stop()

        if head == "观察" and rest in ("on", "off", "开", "关"):
            self.cfg["observe_only"] = rest in ("on", "开")
            self.save_config()
            await ctx.reply("仅观察模式已" + ("开启：只学习不回复。" if rest in ("on", "开") else "关闭。"))
            return self.stop()

        if head == "冷却":
            try:
                v = max(0, int(rest))
            except ValueError:
                await ctx.reply("用法：/humanlike 冷却 30")
                return self.stop()
            self.cfg["cooldown_seconds"] = v
            self.save_config()
            await ctx.reply(f"群冷却已设为 {v} 秒。")
            return self.stop()

        if head == "思维" and rest.isdigit():
            prof = await asyncio.to_thread(self.thinking.profile, int(rest))
            if not prof:
                await ctx.reply(f"QQ {rest} 还没有思维画像（样本不足）。")
                return self.stop()
            summ, tags = build_profile_summary(prof)
            await ctx.reply(summ or f"QQ {rest} 样本不足，画像未成形。")
            return self.stop()

        if head == "删思维" and rest.isdigit():
            n = await asyncio.to_thread(self.thinking.delete, int(rest))
            await ctx.reply(f"已删除 QQ {rest} 的思维画像（{n} 条记录）。")
            return self.stop()

        if head == "事实" and rest.isdigit():
            await ctx.reply(self.facts.export_user(int(rest)))
            return self.stop()

        if head in ("删除事实",) and rest.isdigit():
            n = await asyncio.to_thread(self.facts.delete_user, int(rest))
            self.styles.delete_user(int(rest))
            await ctx.reply(f"已删除 QQ {rest} 的记忆（事实 {n} 条 + 风格档案）。")
            return self.stop()

        if head == "导出" and rest.isdigit():
            await ctx.reply(self.facts.export_user(int(rest)))
            return self.stop()

        if head == "反馈" and rest.lower() in ("good", "bad", "好", "差"):
            ok = self.feedback.rate_last(
                session_of(normalize(ctx)),
                "good" if rest.lower() in ("good", "好") else "bad")
            await ctx.reply("已记录你的评价。" if ok else "最近没有可评价的回复。")
            return self.stop()

        if head == "指标":
            await ctx.reply(json.dumps(self.feedback.summary(), ensure_ascii=False, indent=1))
            return self.stop()

        if head in ("意愿", "门控"):
            await ctx.reply(self._willingness_stats())
            return self.stop()

        if head == "意愿频率" and rest:
            try:
                v = min(1.0, max(0.0, float(rest)))
            except ValueError:
                await ctx.reply("用法：/humanlike 意愿频率 0.45（0~1，越大越爱说话）")
                return self.stop()
            self.cfg["willingness_frequency"] = v
            self.save_config()
            await ctx.reply(f"回复强度已设为 {v}（1.0=门控全放行）。")
            return self.stop()

        await ctx.reply(
            "用法：/humanlike 状态｜观察 on|off｜冷却 <秒>｜意愿｜意愿频率 <0~1>｜"
            "事实 <QQ>｜删除事实 <QQ>｜导出 <QQ>｜反馈 good|bad｜指标")
        return self.stop()
