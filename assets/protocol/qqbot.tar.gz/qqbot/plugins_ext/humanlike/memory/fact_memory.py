"""fact_memory — 对话事实记忆（双层记忆的 B 层）。

只保存允许保留的、可核实的对话事实：
  昵称/称呼、话题背景、已确认偏好、用户主动要求记住的信息。
每条记录：来源、时间、置信度、过期时间；检索按 (user_id) 隔离，绝不跨用户混合。
低置信度信息标注 uncertainty，调用方决定是否作为确定事实使用。

线程模型：短连接 + check_same_thread=False + 全局锁串行化（asyncio.to_thread 安全）。
"""

from __future__ import annotations

import hashlib
import re
import sqlite3
import threading
import time
from pathlib import Path
from typing import Any

from . import memory_store

SCHEMA = """
CREATE TABLE IF NOT EXISTS facts (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id    INTEGER NOT NULL,
    group_id   INTEGER,
    kind       TEXT NOT NULL,          -- profile|preference|background|instruction|topic
    content    TEXT NOT NULL,
    source     TEXT DEFAULT 'chat',    -- chat|instruction|derived
    confidence REAL DEFAULT 0.8,
    fingerprint TEXT UNIQUE,
    created_at REAL,
    updated_at REAL,
    expires_at REAL
);
CREATE INDEX IF NOT EXISTS idx_fact_user ON facts(user_id, kind);
"""

_LOCK = threading.Lock()

# 事实提取句式（规则式，零成本；置信度 0.8）
_PATTERNS = [
    ("profile", re.compile(r"[^。！？\n]{0,6}(我叫|我的名字是|叫我)[\s]*([^\s，。！？]{1,12})")),
    ("profile", re.compile(r"[^。！？\n]{0,6}(我是|本人在)[\s]*([^，。！？\n]{1,16})(上学|上班|工作|学生|程序员|老师|医生)?")),
    ("preference", re.compile(r"[^。！？\n]{0,4}我(喜欢|爱|超爱|最喜欢)[\s]*([^，。！？\n]{1,20})")),
    ("preference", re.compile(r"[^。！？\n]{0,4}我(不喜欢|讨厌|烦)[\s]*([^，。！？\n]{1,20})")),
    ("background", re.compile(r"[^。！？\n]{0,4}我在([\u4e00-\u9fff]{2,8})(上学|上班|工作|住|生活)")),
    ("instruction", re.compile(r"记住[\s*：:]?([^\n]{1,60})")),
]

_SENSITIVE = (
    re.compile(r"1[3-9]\d{9}"),                    # 手机号
    re.compile(r"\d{17}[\dXx]"),                   # 身份证
    re.compile(r"(密码|验证码|银行卡)\s*[:：]?\s*\S+"),
    re.compile(r"[\w.+-]+@[\w-]+\.[\w.]+"),        # 邮箱
)


def fingerprint(kind: str, content: str) -> str:
    base = (kind + "|" + re.sub(r"\s+", "", content))[:120]
    return hashlib.sha1(base.encode()).hexdigest()[:20]


def is_sensitive(text: str) -> bool:
    return any(p.search(text or "") for p in _SENSITIVE)


def extract_facts(text: str) -> list[tuple[str, str, float]]:
    """规则式事实提取：返回 [(kind, content, confidence)]。"""
    out: list[tuple[str, str, float]] = []
    t = (text or "").strip()
    if not t or len(t) > 200:
        return out
    if is_sensitive(t):
        return out
    seen: set[str] = set()
    for kind, pat in _PATTERNS:
        m = pat.search(t)
        if not m:
            continue
        content = m.group(0).strip()
        if content in seen or len(content) < 3:
            continue
        seen.add(content)
        out.append((kind, content, 0.8))
    return out


def _bigrams(text: str) -> set[str]:
    t = re.sub(r"\s+", "", text or "")
    return {t[i:i + 2] for i in range(len(t) - 1)}


class FactMemory:
    def __init__(self, db_path, retention_days: int = 90) -> None:
        self.path = Path(db_path)
        self.retention_days = max(7, int(retention_days))
        with _LOCK:
            conn = self._connect()
            try:
                with conn:
                    conn.executescript(SCHEMA)
            finally:
                conn.close()

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(str(self.path), timeout=8.0,
                               check_same_thread=False)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA synchronous=NORMAL")
        return conn

    def _run(self, fn):
        """短连接 + 锁串行 + 显式关闭（跨线程安全）。"""
        with _LOCK:
            conn = self._connect()
            try:
                with conn:
                    return fn(conn)
            finally:
                conn.close()

    # ---------- 写 ----------

    def upsert(self, user_id: int, group_id: int | None, kind: str,
               content: str, source: str = "chat", confidence: float = 0.8) -> str:
        """去重合并：同指纹→置信度+0.05（上限 0.95）。返回 added|merged"""
        now = time.time()
        fp = fingerprint(kind, content)

        def fn(conn: sqlite3.Connection) -> str:
            dup = conn.execute(
                "SELECT id, confidence FROM facts WHERE fingerprint=?", (fp,)).fetchone()
            if dup:
                nc = min(0.95, float(dup["confidence"]) + 0.05)
                conn.execute(
                    "UPDATE facts SET confidence=?, updated_at=?, expires_at=? WHERE id=?",
                    (nc, now, now + self.retention_days * 86400, dup["id"]))
                return "merged"
            conn.execute(
                """INSERT INTO facts(user_id,group_id,kind,content,source,confidence,
                   fingerprint,created_at,updated_at,expires_at)
                   VALUES(?,?,?,?,?,?,?,?,?,?)""",
                (user_id, group_id, kind, content[:200], source, float(confidence),
                 fp, now, now, now + self.retention_days * 86400))
            return "added"

        return self._run(fn)

    def learn_from_text(self, user_id: int, group_id: int | None,
                        text: str) -> list[str]:
        results = []
        for kind, content, conf in extract_facts(text):
            results.append(self.upsert(user_id, group_id, kind, content, "chat", conf))
        return results

    # ---------- 读 ----------

    def recall(self, user_id: int, query: str = "", top_k: int = 5,
               min_confidence: float = 0.6) -> list[dict[str, Any]]:
        now = time.time()
        q = _bigrams(query) if query else set()

        def fn(conn: sqlite3.Connection) -> list[dict[str, Any]]:
            rows = conn.execute(
                "SELECT * FROM facts WHERE user_id=? AND expires_at>? AND confidence>=?",
                (user_id, now, min_confidence)).fetchall()
            scored = []
            for r in rows:
                d = dict(r)
                s = float(d.get("confidence") or 0.8)
                if q:
                    overlap = len(q & _bigrams(d["content"]))
                    s += min(0.4, overlap * 0.08)
                scored.append((s, d))
            scored.sort(key=lambda kv: -kv[0])
            return [d for _, d in scored[:top_k]]

        return self._run(fn)

    def list_user(self, user_id: int, limit: int = 50) -> list[dict[str, Any]]:
        def fn(conn):
            rows = conn.execute(
                "SELECT * FROM facts WHERE user_id=? ORDER BY updated_at DESC LIMIT ?",
                (user_id, limit)).fetchall()
            return [dict(r) for r in rows]
        return self._run(fn)

    # ---------- 删 ----------

    def delete_user(self, user_id: int) -> int:
        def fn(conn):
            return conn.execute(
                "DELETE FROM facts WHERE user_id=?", (user_id,)).rowcount
        return self._run(fn)

    def delete_id(self, fact_id: int) -> bool:
        def fn(conn):
            return conn.execute(
                "DELETE FROM facts WHERE id=?", (fact_id,)).rowcount > 0
        return self._run(fn)

    def purge_expired(self) -> int:
        def fn(conn):
            return conn.execute(
                "DELETE FROM facts WHERE expires_at<=?", (time.time(),)).rowcount
        return self._run(fn)

    # ---------- 导出 ----------

    def export_user(self, user_id: int) -> str:
        items = self.list_user(user_id)
        if not items:
            return f"（QQ {user_id} 无事实记忆）"
        lines = [f"【事实记忆 · QQ {user_id}】"]
        for it in items:
            exp = time.strftime("%Y-%m-%d", time.localtime(it["expires_at"]))
            lines.append(
                f"- [{it['kind']}] {it['content']}（置信度 {it['confidence']:.2f}，"
                f"来源 {it['source']}，{exp} 过期）")
        return "\n".join(lines)
