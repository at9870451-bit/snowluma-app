"""style_memory — 风格记忆代理（双层记忆的 A 层）。

实现策略：语言风格记忆与画像已由 lang_memory 插件维护（profiles/memories/samples，
含置信度、时间衰减、合并）。本模块做**只读代理 + 补充增强**，避免双写冲突：
  - get_style_profile(user_id) → 语言习惯/节奏/文化标签 + 置信度
  - get_style_summary(user_id) → 可注入提示词的风格参数文本
  - 转发「查看/删除」到 lang_memory 的存储（支持记忆管理需求）
若 lang_memory 未加载，自动降级为空结果（不报错、不阻塞聊天）。
"""

from __future__ import annotations

from typing import Any


class StyleMemoryProxy:
    def __init__(self, plugin) -> None:
        self.plugin = plugin  # HumanLikePlugin 实例（用 bot 找 lang_memory）

    def _lang_store(self):
        try:
            for p in self.plugin.bot.plugins.plugins:
                if getattr(p, "name", "") == "lang_memory":
                    return p.store, p.analyzer
        except Exception:
            pass
        return None, None

    def get_style_profile(self, user_id: int) -> dict[str, Any] | None:
        store, analyzer = self._lang_store()
        if not store:
            return None
        try:
            prof = store.get_profile(int(user_id))
            if not prof:
                return None
            traits = prof.get("traits") or {}
            stats = prof.get("stats") or {}
            conf = min(0.95, float(prof.get("importance") or 0.5))
            return {
                "user_id": user_id,
                "confidence": round(conf, 2),
                "msg_count": int(stats.get("msg_count") or 0),
                "avg_len": stats.get("avg_len"),
                "style_tags": analyzer.style_brief(traits, stats, limit=6),
                "traits": traits,
            }
        except Exception:
            return None

    def get_style_summary(self, user_id: int) -> str:
        prof = self.get_style_profile(user_id)
        if not prof or not prof.get("style_tags"):
            return ""
        n = prof.get("msg_count") or 0
        conf = prof.get("confidence") or 0
        return (
            f"[语言风格参数·置信度 {conf:.0%}（样本 {n} 条）] "
            f"{prof['style_tags']}。稳定习惯可沿用；样本不足时不要过度模仿。"
        )

    def delete_user(self, user_id: int) -> bool:
        store, _ = self._lang_store()
        if not store:
            return False
        try:
            store.delete_user(int(user_id))
            return True
        except Exception:
            return False
