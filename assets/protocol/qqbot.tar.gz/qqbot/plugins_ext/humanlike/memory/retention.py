"""retention — 记忆过期与清理（事实记忆过期清除 + 反馈日志保留窗口）。"""

from __future__ import annotations

import time
from typing import Callable

from . import memory_store


def run_retention(fact_memory, purge_feedback_older_than_days: int = 30,
                  log: Callable[[str], None] = print) -> dict[str, int]:
    """执行一次清理；返回各部分删除条数。由插件定时调用（每 6 小时）。"""
    expired = fact_memory.purge_expired()
    cutoff = time.time() - max(1, purge_feedback_older_than_days) * 86400
    purged_fb = 0
    try:
        conn = memory_store.connect(fact_memory.path)
        try:
            with conn:
                before = conn.total_changes
                conn.execute("DELETE FROM feedback WHERE created_at<=?", (cutoff,))
                purged_fb = conn.total_changes - before
        finally:
            conn.close()
    except Exception:
        pass  # feedback 表不在该库时由 feedback 引擎自行清理
    log(f"retention: 过期事实 {expired} 条，旧反馈 {purged_fb} 条")
    return {"expired_facts": expired, "feedback": purged_fb}
