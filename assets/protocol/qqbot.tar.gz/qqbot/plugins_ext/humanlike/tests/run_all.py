"""humanlike 测试套件：单元 + 上下文隔离 + 记忆删除 + 群聊压力模拟。

运行：cd /opt/qqbot && python3 humanlike/tests/run_all.py
全部离线（不调 LLM、不连 QQ），可在生产服务器安全执行。
"""

from __future__ import annotations

import asyncio
import sys
import tempfile
import time
from pathlib import Path

sys.path.insert(0, "/opt/qqbot")
sys.path.insert(0, "/opt/qqbot/plugins_ext")

PASS = 0
FAIL = 0


def check(name: str, cond: bool, detail: str = "") -> None:
    global PASS, FAIL
    if cond:
        PASS += 1
        print(f"  ✓ {name}")
    else:
        FAIL += 1
        print(f"  ✗ {name} {detail}")


def t_fact_memory():
    print("[1] 事实记忆：提取/去重/置信度/检索")
    from humanlike.memory.fact_memory import FactMemory, extract_facts, is_sensitive
    fm = FactMemory(Path(tempfile.mkdtemp()) / "t.db")

    facts = extract_facts("我叫小明 我喜欢打游戏 我在杭州上班")
    check("提取 3 条事实", len(facts) == 3, str(facts))
    check("敏感过滤（手机号）", is_sensitive("我手机 13812345678"))
    r1 = fm.learn_from_text(1, 100, "我叫小明")
    r2 = fm.learn_from_text(1, 100, "我叫小明")
    check("去重合并", r1 == ["added"] and r2 == ["merged"], f"{r1}/{r2}")
    got = fm.recall(1, "小明 喜欢什么")
    check("检索命中", len(got) >= 1)
    check("跨用户隔离", fm.recall(2, "小明") == [])
    n = fm.delete_user(1)
    check("删除用户", n >= 1 and fm.recall(1) == [])


def t_context():
    print("[2] 上下文管理：去重/预算/指代/话题切换")
    from humanlike.core.context_manager import ContextManager, estimate_tokens
    cm = ContextManager()
    s = "group_1"
    cm.add(s, 1, "小明", "昨晚那个游戏你们玩了吗", ts=time.time() - 50)
    cm.add(s, 1, "小明", "昨晚那个游戏你们玩了吗", ts=time.time() - 40)  # 重复应去重
    cm.add(s, 2, "小红", "玩了 到两点", ts=time.time() - 30)
    items = cm.recent(s, 6)
    check("去重", len(items) == 2, str(len(items)))
    rendered = cm.render(s, 6, budget_chars=60)
    check("Token 预算截断不空", "小红" in rendered or "小明" in rendered)
    check("token 估算", estimate_tokens("你好世界abc") > 0)
    # 指代
    hint = ContextManager.resolve_reference(items, "他刚才说什么")
    check("指代提示", "小明" in hint)
    # 话题切换
    cm.add(s, 3, "老王", "谁知道苹果美股代码多少", ts=time.time() - 5)
    cm.add(s, 2, "小红", "这个我还真不知道", ts=time.time() - 4)
    check("话题切换检测", ContextManager.topic_shifted(cm.recent(s, 5)))
    # 已答识别
    cm.add(s, 0, "我", "苹果股票代码是300750", ts=time.time() - 3)
    check("已答识别", ContextManager.already_answered(cm.recent(s, 6), "股票代码是啥"))


def t_feedback():
    print("[3] 反馈引擎：指标/评价/保留")
    from humanlike.core.feedback_engine import FeedbackEngine
    from humanlike.memory import memory_store
    conn = memory_store.connect(Path(tempfile.mkdtemp()) / "f.db")
    fe = FeedbackEngine(conn, "hl-v1")
    m = fe.record("group_1", 9, 1, "今天吃什么好",
                  "作为一个AI 建议您均衡饮食哦",
                  recent_replies=[], recent_context=["今天吃什么好"])
    check("机械词拉低自然度", m["naturalness"] < 0.9, str(m))
    m2 = fe.record("group_1", 9, 1, "今天吃什么好",
                   "点黄焖鸡吧 别折腾了",
                   recent_replies=[], recent_context=["今天吃什么好"])
    check("正常回复得分更高", m2["score"] > m["score"], f"{m2} vs {m}")
    check("评价 good", fe.rate_last("group_1", "good"))
    s = fe.summary()
    check("汇总可用", s["n"] == 2)
    check("旧记录清理", fe.purge_old(30) == 0)


def t_behavior():
    print("[4] 群聊压力/行为控制：冷却/单人频率/黑名单/刷屏")
    from humanlike import HumanLikePlugin
    bot, p = _make_plugin()
    # 构造消息
    def msg(uid, gid, text):
        from types import SimpleNamespace
        ev = SimpleNamespace(user_id=uid, group_id=gid, text=text,
                             sender={"nickname": f"u{uid}"}, message_id=uid,
                             message=[], raw_message=text)
        return SimpleNamespace(event=ev, user_id=uid, group_id=gid,
                               is_admin=False, is_group=True, text=text,
                               message=[], at_targets=[])
    # 黑名单群
    p.cfg["blacklist_groups"] = [999]
    check("群黑名单拦截", p._should_block(_norm(msg(1, 999, "hi"))))
    p.cfg["blacklist_groups"] = []
    # 刷屏：同文本 60s 内第 2 次
    check("首条放行", not p._should_block(_norm(msg(1, 1, "hello"))))
    check("重复刷屏拦截", p._should_block(_norm(msg(1, 1, "hello"))))
    # 冷却：模拟刚回复过
    p.cfg["cooldown_seconds"] = 300
    p._last_reply_at["group_1"] = time.time()
    check("冷却拦截", p._should_block(_norm(msg(2, 1, "另一句话"))))
    p.cfg["cooldown_seconds"] = 0
    # 单人频率：6 次/时
    p.cfg["per_user_per_hour"] = 2
    p.cfg["dedupe_window"] = 0
    p._msg_seen.clear()
    check("第1条放行", not p._should_block(_norm(msg(3, 1, "a一"))))
    p._mark_reply(_norm(msg(3, 1, "a一")))
    check("第2条放行", not p._should_block(_norm(msg(3, 1, "b二"))))
    p._mark_reply(_norm(msg(3, 1, "b二")))
    check("第3条被限频", p._should_block(_norm(msg(3, 1, "c三"))))
    # 每日上限
    p.cfg["daily_limit_per_group"] = 0
    p.cfg["per_user_per_hour"] = 99
    check("每日上限拦截", p._should_block(_norm(msg(4, 1, "d四"))))
    # 仅观察
    p.cfg.update({"daily_limit_per_group": 999, "observe_only": True})
    check("仅观察拦截", p._should_block(_norm(msg(5, 1, "e五"))))
    p.cfg["observe_only"] = False
    # 管理员不受限
    m = _norm(msg(6, 1, "f六"))
    m["is_admin"] = True
    check("管理员放行", not p._should_block(m))


def t_style():
    print("[5] 风格分析：互动标签/置信度/场景")
    from humanlike.core import style_analyzer
    hits = {}
    for t in ["你咋看这个", "哈哈哈笑死", "对对", "不对吧", "先这样我去忙"]:
        for k, v in style_analyzer.analyze_interaction(t).items():
            hits[k] = hits.get(k, 0) + v
    tags = style_analyzer.summarize_interaction(hits)
    check("标签非空", len(tags) > 0)
    check("置信度<1", all(t["confidence"] <= 0.95 for t in tags))
    check("场景提示", all("scenario" in t for t in tags))
    check("主导情绪", style_analyzer.dominant_mood(hits) != "")


def t_prompt():
    print("[6] 动态提示词组装：六层顺序/预算")
    from humanlike.core import prompt_builder
    text = prompt_builder.build_sections(
        scenario="群聊场景",
        context_block="【最近群聊记录】\n小明：hi",
        fact_block="[已知事实] - 我叫小明",
        style_block="[语言风格参数] 短句",
        interaction_block="[互动风格] - 接梗吐槽",
        mood_note="[回复约束] 单行",
        max_chars=200)
    check("预算截断", len(text) <= 200)
    check("顺序：场景在前", text.find("[场景决策]") < text.find("【最近群聊记录】"))


def t_lifecycle():
    print("[7] 插件生命周期 + 端到端（离线）")
    bot, p = _make_plugin()
    asyncio.run(p.on_load())
    hooks = getattr(bot, "style_hooks", [])
    check("注册注入钩子", p.build_injection in hooks)
    # 端到端：消息→放行→（模拟回复）→反馈入库
    # （频率设 1.0 让意愿门控全放行 —— 本段测的是生命周期链路，不是门控）
    p.cfg["willingness_frequency"] = 1.0
    ctx = _fake_ctx(77, 555, "我叫小红 我喜欢猫")
    r = asyncio.run(p.on_message(ctx))
    check("消息放行", r is None)
    # 模拟 bot 回复（触发 send 包装器）
    from qqbot.core.message import Message, text as text_seg
    msg = Message([text_seg("你好小红 猫可爱")])
    asyncio.run(bot.send_group_msg(555, msg))
    fb = p.feedback.summary()
    check("反馈已记录", fb.get("n", 0) >= 1, str(fb))
    fact = p.facts.recall(77, "喜欢猫")
    check("事实已自动学习", any("喜欢" in f["content"] for f in fact))
    # 注入片段
    inj = asyncio.run(p.build_injection(_fake_ctx(77, 555, "你还记得我吗"), "x"))
    check("注入含事实", "小红" in inj or "猫" in inj or "已知事实" in inj)
    # 删除记忆
    n = asyncio.run(asyncio.to_thread(p.facts.delete_user, 77))
    check("记忆删除", n >= 1 and p.facts.recall(77) == [])
    asyncio.run(p.on_unload())
    check("卸载还原 send", bot.send_group_msg.__name__ == "orig_send_group_msg_wrapper"
          or not getattr(bot.send_group_msg, "__wrapped__", None))


# ---------- 工具 ----------

def _make_plugin():
    from humanlike import HumanLikePlugin
    from types import SimpleNamespace

    class FakeBus:
        def on(self, t, h, p=None):
            class _S:
                def cancel(self): pass
            return _S()

    class FakePlugins:
        def __init__(self): self.plugins = []
        def __iter__(self): return iter(self.plugins)

    class FakeAI: enabled = True; triggers = []
    class FakeStickerCfg: enabled = False; reply_rate = 1.0
    class FakePaths:
        plugin_data_dir = Path(tempfile.mkdtemp())
        sticker_dir = Path(tempfile.mkdtemp()) / "stickers"
    class FakeCfg:
        paths = FakePaths(); custom = {}; ai = FakeAI()
        sticker = FakeStickerCfg(); memory = None

        class bot:  # noqa: N801  主人硬指令段需要 config.bot.admins
            admins = [3227868908]

        def save(self): pass
    sent = []

    async def send_group_msg(gid, message, *a, **k):
        sent.append(("g", gid)); return {}

    async def send_private_msg(uid, message, *a, **k):
        sent.append(("p", uid)); return {}

    class FakeBot:
        config = FakeCfg(); bus = FakeBus(); plugins = FakePlugins()
        self_id = 1780685132
        sent = []

        async def send_group_msg(self, gid, message, *a, **k):
            FakeBot.sent.append(("g", gid)); return {}

        async def send_private_msg(self, uid, message, *a, **k):
            FakeBot.sent.append(("p", uid)); return {}

        def chat_client(self): raise Exception("offline")
        def is_silenced(self, g): return False
        def group_ai_enabled(self, g): return True
        def memory_context(self, g, u): return ""
        def summary_context(self, s): return ""
    bot = FakeBot()
    p = HumanLikePlugin(bot)
    return bot, p


def _norm(m):
    """行为控制用 SimpleNamespace 消息 → normalize dict 形状近似。"""
    from humanlike.adapters.qqbot_adapter import normalize
    return normalize(m)


def _fake_ctx(uid, gid, text):
    from types import SimpleNamespace
    ev = SimpleNamespace(user_id=uid, group_id=gid, text=text,
                         sender={"card": "小红", "nickname": "小红"},
                         message_id=uid, message=[], raw_message=text)
    return SimpleNamespace(event=ev, user_id=uid, group_id=gid, text=text,
                           is_group=True, is_admin=False, at_targets=[],
                           message=[])


def t_willingness():
    print("[8] 回复意愿门控：概率/门控/退避/强制触发")
    from humanlike.core import willingness as W

    def P(**kw):
        base = dict(mention_bot=False, at_other=False, has_question_mark=False,
                    placeholder_only=False, recent_self_ratio=0.0,
                    recent_message_count=0, seconds_since_bot_message=3600.0,
                    pending_count=1)
        base.update(kw)
        return W.ReplyLikelihoodInput(**base)

    p_base = W.estimate_reply_probability(P())
    check("基线概率在 (0,1)", 0 < p_base < 1)
    check("问号提高概率",
          W.estimate_reply_probability(P(has_question_mark=True)) > p_base)
    check("纯表情降低概率",
          W.estimate_reply_probability(P(placeholder_only=True)) < p_base)
    check("续聊比例提高概率",
          W.estimate_reply_probability(P(recent_self_ratio=0.5)) > p_base * 1.5)

    g = W.DynamicReplyGate()
    d = g.evaluate(0.01, 1.0, time.time())
    check("频率=1 阈值0 全放行", d.should_trigger and d.threshold == 0.0)
    g2 = W.DynamicReplyGate()
    d2 = g2.evaluate(0.6, 0.2, time.time())
    d3 = g2.evaluate(0.2, 0.2, time.time())
    check("静态阈值：0.6 过 0.2 拦", d2.should_trigger and not d3.should_trigger)

    b = W.IdleBackoff(base_seconds=60, cap_seconds=1800, start_count=2)
    b.record_idle(now=1000)
    check("第1次空闲不退避", b.delay_seconds(now=1001) == 0)
    b.record_idle(now=1002)
    check("第2次空闲退避 60s", 59 <= b.delay_seconds(now=1003) <= 60)
    b.reset()
    check("复位清零", b.delay_seconds(now=1004) == 0)
    check("待处理堆积绕过", b.delay_seconds(now=1005, pending_count=9,
                                            bypass_pending=5) == 0)

    # 插件方法级：强制触发识别
    bot, p = _make_plugin()
    m = {"is_group": True, "is_admin": False, "text": "在吗", "raw_message": "",
         "user_id": 8}
    check("普通消息非强制", not p._is_forced_trigger(None, m))
    check("引用回复强制", p._is_forced_trigger(
        None, {**m, "raw_message": "[CQ:reply,id=1]在吗"}))
    check("主人强制", p._is_forced_trigger(None, {**m, "is_admin": True}))
    # 决策流（真实 ctxmgr）
    ok, why = p._willingness_decide({"text": "今天天气不错", "user_id": 2},
                                    "group_1")
    check("决策返回 (bool,str)", isinstance(ok, bool) and isinstance(why, str), why)
    ok2, why2 = p._willingness_decide({"text": "你们说是不是？", "user_id": 2},
                                      "group_1")
    check("问句概率高于基线消息",
          float(why2.split("prob=")[1].split(" ")[0]) >=
          float(why.split("prob=")[1].split(" ")[0]),
          f"{why} | {why2}")
    stats = p._willingness_stats()
    check("统计可生成", "回复意愿门控" in stats)


def t_command_swallow():
    print("[9] 指令兜底：未注册指令吞掉/全角纠正/画图放行")
    bot, p = _make_plugin()

    class FakeCmdPlugins:
        def all_commands(self):
            return [{"name": "help", "aliases": ["菜单"]},
                    {"name": "humanlike", "aliases": ["human"]}]

    bot.plugins = FakeCmdPlugins()

    class Ev:
        text = ""

    class Ctx:
        event = Ev()

    def M(t):
        return {"text": t, "user_id": 1}

    check("未注册指令吞掉", p._swallow_unknown_command(Ctx(), M("/foobar 123")))
    check("已注册指令放行", not p._swallow_unknown_command(Ctx(), M("/help")))
    check("别名放行", not p._swallow_unknown_command(Ctx(), M("/human 状态")))
    check("画图请求放行", not p._swallow_unknown_command(Ctx(), M("/画 一只猫")))
    check("普通聊天放行", not p._swallow_unknown_command(Ctx(), M("今天天气不错")))
    check("长句放行", not p._swallow_unknown_command(
        Ctx(), M("/这个是一个很长很长根本不是指令的句子")))
    # 全角前缀纠正
    c2 = Ctx()
    c2.event.text = "／humanlike 意愿"
    swallowed = p._swallow_unknown_command(c2, M("／humanlike 意愿"))
    check("全角+已注册：放行并纠正", not swallowed and c2.event.text == "/humanlike 意愿",
          f"text={c2.event.text!r}")
    c3 = Ctx()
    c3.event.text = "／foobar"
    check("全角+未注册：吞掉", p._swallow_unknown_command(c3, M("／foobar")))
    # 已吞掉的指令不应进意愿门控/上下文（on_message 早退）——验证 stop 路径存在
    from qqbot.core.bus import STOP as _STOP
    check("stop 返回 STOP", p.stop() is _STOP)


if __name__ == "__main__":
    t_fact_memory()
    t_context()
    t_feedback()
    t_behavior()
    t_style()
    t_prompt()
    t_lifecycle()
    t_willingness()
    t_command_swallow()
    print(f"\n结果：{PASS} 通过 / {FAIL} 失败")
    sys.exit(1 if FAIL else 0)
