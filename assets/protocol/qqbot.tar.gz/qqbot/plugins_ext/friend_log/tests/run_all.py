"""friend_log 测试（离线：事件记录/去重/通知/指令）。"""
from __future__ import annotations

import asyncio
import sys
from pathlib import Path
from types import SimpleNamespace

try:
    from qqbot.core.bus import STOP  # noqa: F401
except ImportError:
    import types as _t
    _qqbot = _t.ModuleType("qqbot")
    _core = _t.ModuleType("qqbot.core")
    _bus = _t.ModuleType("qqbot.core.bus")
    _bus.STOP = "STOP"
    _msg = _t.ModuleType("qqbot.core.message")

    class _Msg:
        def __init__(self, segs):
            self.segs = segs

    _msg.Message = _Msg

    def _text(t):
        return t

    _msg.text = _text
    _plugins = _t.ModuleType("qqbot.plugins")
    _base = _t.ModuleType("qqbot.plugins.base")

    class _Plugin:
        priority = 50

        def __init__(self, bot=None):
            import logging
            self.bot = bot
            self.cfg = dict(getattr(self, "default_config", {}) or {})
            self._cmds = {}
            self.log = logging.getLogger("stub")

        @property
        def data_dir(self):
            return self.bot.config.paths.plugin_data_dir / self.name

        def cfg_get(self, key, default=None):
            return self.cfg.get(key, default)

        def add_command(self, name, handler, **kw):
            self._cmds[name] = (handler, kw)

        @staticmethod
        def stop():
            return _bus.STOP

    _base.Plugin = _Plugin
    _qqbot.core = _core
    _core.bus = _bus
    _core.message = _msg
    _qqbot.plugins = _plugins
    _plugins.base = _base
    for _n, _m in {"qqbot": _qqbot, "qqbot.core": _core, "qqbot.core.bus": _bus,
                   "qqbot.core.message": _msg, "qqbot.plugins": _plugins,
                   "qqbot.plugins.base": _base}.items():
        sys.modules[_n] = _m
    from qqbot.core.bus import STOP  # noqa: F401

_PKG = Path(__file__).resolve().parent.parent
for _p in ("/opt/qqbot/plugins_ext", "/opt/qqbot", str(_PKG.parent)):
    if _p not in sys.path:
        sys.path.insert(0, _p)

try:
    import friend_log  # noqa: F401
except ImportError:
    import fl_dev as friend_log  # noqa: F401
    sys.modules.setdefault("friend_log", friend_log)

PASS = FAIL = 0


def check(name, cond, detail=""):
    global PASS, FAIL
    if cond:
        PASS += 1
        print(f"  ✓ {name}")
    else:
        FAIL += 1
        print(f"  ✗ {name} {detail}")


def _make(cfg_extra=None):
    import tempfile
    from friend_log import FriendLogPlugin

    class FakePaths:
        plugin_data_dir = Path(tempfile.mkdtemp())

    class FakeCfg:
        paths = FakePaths()

        class bot:  # noqa: N801
            admins = [3227868908]

        def save(self):
            pass

    class FakeBot:
        config = FakeCfg()
        sent = []

        def call_api_sync(self, action, params=None, **kw):
            return {"data": {"nickname": f"用户{params['user_id']}"}}

        async def call_api(self, action, params=None, **kw):
            return {"data": {}}

        async def send_private_msg(self, uid, message, *a, **k):
            FakeBot.sent.append((uid, str(message.segs)))

    bot = FakeBot()
    p = FriendLogPlugin(bot)
    p.cfg.update(cfg_extra or {})
    return bot, p


def _req(uid, comment="你好"):
    return SimpleNamespace(request_type="friend", user_id=uid, group_id=None,
                           comment=comment, flag="flag123",
                           get=lambda k, d=None: {"sub_type": ""}.get(k, d))


def _added_notice(uid):
    return SimpleNamespace(notice_type="friend_add", user_id=uid, group_id=None,
                           get=lambda k, d=None: {}.get(k, d))


def _ctx():
    c = SimpleNamespace(replies=[])
    box = c.replies

    async def _reply(msg, **kw):
        box.append(msg)

    c.reply = _reply
    return c


def t_request():
    print("[1] 好友申请：记录入库")
    bot, p = _make()
    asyncio.run(p.on_request(_req(111, "我是小明")))
    rows = p._recent(5)
    check("申请已记录", len(rows) == 1 and rows[0]["kind"] == "request")
    check("验证消息入库", rows[0]["comment"] == "我是小明")
    check("昵称已取", rows[0]["nickname"] == "用户111")
    # 非好友请求不记
    ev = SimpleNamespace(request_type="group", user_id=5, group_id=1,
                         comment="", flag="f",
                         get=lambda k, d=None: {}.get(k, d))
    asyncio.run(p.on_request(ev))
    check("加群请求不记", len(p._recent(5)) == 1)
    import os
    check("jsonl 已写", os.path.exists(p._jsonl) and
          os.path.getsize(p._jsonl) > 0)


def t_added():
    print("[2] 成功添加：记录+通知主人+去重")
    bot, p = _make()
    asyncio.run(p.on_notice(_added_notice(222)))
    rows = p._recent(5)
    check("已添加入库", rows[0]["kind"] == "added" and rows[0]["user_id"] == 222)
    check("主人收到通知", any(u == 3227868908 for u, _ in bot.sent))
    # 10 分钟内同一人不重复记
    asyncio.run(p.on_notice(_added_notice(222)))
    added = [r for r in p._recent(5) if r["kind"] == "added" and r["user_id"] == 222]
    check("同人不重复", len(added) == 1)
    # 通知可关
    bot2, p2 = _make({"notify_master": False})
    asyncio.run(p2.on_notice(_added_notice(333)))
    check("关闭通知生效", not bot2.sent)


def t_cmd():
    print("[3] 指令：状态/清空")
    bot, p = _make()
    asyncio.run(p.on_request(_req(444, "加个好友")))
    asyncio.run(p.on_notice(_added_notice(444)))
    c = _ctx()
    asyncio.run(p._cmd(c, ""))
    out = "\n".join(c.replies)
    check("状态含统计", "已添加 1 人" in out, out[:80])
    check("状态含明细", "QQ 444" in out)
    c = _ctx()
    asyncio.run(p._cmd(c, "清空"))
    check("清空成功", "已清空" in c.replies[0])
    c = _ctx()
    asyncio.run(p._cmd(c, ""))
    check("清空后为 0", "共 0 条" in c.replies[0])


if __name__ == "__main__":
    t_request()
    t_added()
    t_cmd()
    print(f"\n结果：{PASS} 通过 / {FAIL} 失败")
    sys.exit(1 if FAIL else 0)
