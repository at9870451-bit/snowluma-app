"""QQBot FriendLog 好友添加日志插件 v1.0.0

记录机器人账号的好友变动：
  - 收到好友申请（含验证消息）→ 记一条「申请」
  - 成功添加好友（任何来源：管理指令通过 / 自动同意 / QQ 里手动同意）→
    记一条「已添加」，并私聊通知主人
  - /好友日志 查看全部记录

数据：sqlite（friend_events 表）+ friends.jsonl 逐行追加（好 grep）。
"""

from __future__ import annotations

import asyncio
import json
import sqlite3
import time
from pathlib import Path
from typing import Any

from qqbot.plugins.base import Plugin


def _now() -> float:
    return time.time()


def _day(ts: float | None = None) -> str:
    return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(ts or _now()))


class FriendLogPlugin(Plugin):
    name = "friend_log"
    display_name = "好友添加日志"
    version = "1.0.0"
    description = "记录机器人添加/通过的好友：申请+成功入库，私聊通知主人，/好友日志 查看"
    priority = 13  # 纯记录插件，尽早拿到事件

    default_config = {
        "enabled": True,
        "notify_master": True,     # 新好友时私聊通知主人
        "keep_days": 365,          # 日志保留天数
    }

    config_labels = {
        "enabled": "启用好友日志",
        "notify_master": "新好友私聊通知主人",
    }

    SCHEMA = """
    CREATE TABLE IF NOT EXISTS friend_events(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      ts REAL NOT NULL,
      kind TEXT NOT NULL,          -- request / added
      user_id INTEGER NOT NULL,
      nickname TEXT DEFAULT '',
      comment TEXT DEFAULT '',
      detail TEXT DEFAULT ''
    );
    """

    def __init__(self, bot) -> None:
        super().__init__(bot)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self._db = self.data_dir / "friends.sqlite3"
        self._conn = sqlite3.connect(str(self._db), check_same_thread=False,
                                     timeout=10)
        self._conn.row_factory = sqlite3.Row
        self._conn.executescript(self.SCHEMA)
        self._conn.commit()
        self._jsonl = self.data_dir / "friends.jsonl"

    async def on_load(self) -> None:
        if not self.cfg_get("enabled", True):
            return
        self.add_command("好友日志", self._cmd, aliases=("friendlog",),
                         admin=True, description="好友添加日志：状态/清空")
        n = self._conn.execute("SELECT COUNT(*) c FROM friend_events").fetchone()["c"]
        self.log.info("好友日志已启用（历史记录 %d 条）", n)

    # ---------- 存储 ----------

    def _record(self, kind: str, user_id: int, nickname: str = "",
                comment: str = "", detail: str = "") -> None:
        self._conn.execute(
            "INSERT INTO friend_events(ts, kind, user_id, nickname, comment, detail)"
            " VALUES(?,?,?,?,?,?)",
            (_now(), kind, int(user_id), nickname, comment, detail))
        self._conn.commit()
        try:
            with open(self._jsonl, "a", encoding="utf-8") as f:
                f.write(json.dumps({
                    "time": _day(), "kind": kind, "user_id": int(user_id),
                    "nickname": nickname, "comment": comment, "detail": detail,
                }, ensure_ascii=False) + "\n")
        except Exception:
            pass
        self.log.info("好友日志[%s] %s(%s) %s", kind, nickname or user_id,
                      user_id, detail)

    def _recent(self, n: int = 15) -> list[dict[str, Any]]:
        rows = self._conn.execute(
            "SELECT * FROM friend_events ORDER BY id DESC LIMIT ?", (n,)).fetchall()
        return [dict(r) for r in rows]

    # ---------- 事件 ----------

    async def on_request(self, event) -> Any:
        if not self.cfg_get("enabled", True):
            return None
        try:
            if str(getattr(event, "request_type", "")) != "friend":
                return None
            uid = int(getattr(event, "user_id", 0) or 0)
            if not uid:
                return None
            comment = str(getattr(event, "comment", "") or "")
            sub = str(event.get("sub_type") or "")
            self._record("request", uid, self._nick(uid), comment,
                         detail=f"好友申请（{sub or '单方向'}）")
        except Exception as exc:  # noqa: BLE001
            self.log.debug("记录好友申请失败: %s", exc)
        return None

    async def on_notice(self, event) -> Any:
        if not self.cfg_get("enabled", True):
            return None
        try:
            if str(getattr(event, "notice_type", "")) != "friend_add":
                return None
            uid = int(getattr(event, "user_id", 0) or 0)
            if not uid:
                return None
            nick = self._nick(uid)
            # 同一用户 10 分钟内不重复记「已添加」
            row = self._conn.execute(
                "SELECT ts FROM friend_events WHERE kind='added' AND user_id=?"
                " ORDER BY id DESC LIMIT 1", (uid,)).fetchone()
            if row and _now() - float(row["ts"]) < 600:
                return None
            self._record("added", uid, nick, detail="已添加为好友")
            if self.cfg_get("notify_master", True):
                await self._notify_master(uid, nick)
        except Exception as exc:  # noqa: BLE001
            self.log.debug("记录新好友失败: %s", exc)
        return None

    def _nick(self, uid: int) -> str:
        """尽量拿到昵称（失败返回空串）。"""
        try:
            resp = self.bot.call_api_sync("get_stranger_info",
                                          {"user_id": int(uid)})
            info = resp.get("data") if isinstance(resp, dict) else {}
            return str((info or {}).get("nickname") or "")
        except Exception:
            return ""

    async def _notify_master(self, uid: int, nick: str) -> None:
        try:
            admins = [int(a) for a in (self.bot.config.bot.admins or [])]
            if not admins:
                return
            from qqbot.core.message import Message, text as text_seg
            text = f"🤝 机器人新增好友：{nick or uid}（QQ {uid}）"
            for _a in admins:
                try:
                    await self.bot.send_private_msg(_a, Message([text_seg(text)]))
                except Exception:  # noqa: BLE001
                    continue
        except Exception as exc:  # noqa: BLE001
            self.log.debug("通知主人失败: %s", exc)

    # ---------- 指令 ----------

    async def _cmd(self, ctx, args: str) -> Any:
        a = (args or "").strip()
        head = a.split(" ", 1)[0] if a else ""

        total = self._conn.execute(
            "SELECT COUNT(*) c FROM friend_events").fetchone()["c"]
        added = self._conn.execute(
            "SELECT COUNT(*) c FROM friend_events WHERE kind='added'"
        ).fetchone()["c"]

        if head in ("", "状态", "list"):
            lines = [f"【好友日志】共 {total} 条（其中已添加 {added} 人）"]
            for e in self._recent(12):
                icon = "🤝" if e["kind"] == "added" else "📨"
                lines.append(
                    f"{_day(e['ts'])} {icon} {e['nickname'] or e['user_id']}"
                    f"(QQ {e['user_id']}) {e['detail']}"
                    + (f"｜验证：{e['comment'][:20]}" if e["comment"] else ""))
            await self._safe_reply(ctx, "\n".join(lines))
            return self.stop()

        if head == "清空":
            self._conn.execute("DELETE FROM friend_events")
            self._conn.commit()
            await self._safe_reply(ctx, "好友日志已清空。")
            return self.stop()

        await self._safe_reply(ctx, "用法：/好友日志（看记录）｜清空")
        return self.stop()

    async def _safe_reply(self, ctx, message: str) -> None:
        try:
            await ctx.reply(message)
        except Exception as exc:  # noqa: BLE001
            self.log.warning("回复失败: %s", exc)
