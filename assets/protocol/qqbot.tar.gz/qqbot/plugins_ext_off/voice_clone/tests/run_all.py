"""voice_clone 测试（离线：指令/网关桩）。"""
from __future__ import annotations

import asyncio
import sys
from pathlib import Path

try:
    from qqbot.core.bus import STOP  # noqa: F401
except ImportError:
    import types as _t
    _qqbot = _t.ModuleType("qqbot")
    _core = _t.ModuleType("qqbot.core")
    _bus = _t.ModuleType("qqbot.core.bus")
    _bus.STOP = "STOP"
    _plugins = _t.ModuleType("qqbot.plugins")
    _base = _t.ModuleType("qqbot.plugins.base")

    class _Plugin:
        priority = 50

        def __init__(self, bot=None):
            import logging
            self.bot = bot
            self.cfg = dict(getattr(self, "default_config", {}) or {})
            self._cmds = {}
            self.log = logging.getLogger("stub")

        @property
        def data_dir(self):
            return self.bot.config.paths.plugin_data_dir / self.name

        def cfg_get(self, key, default=None):
            return self.cfg.get(key, default)

        def add_command(self, name, handler, **kw):
            self._cmds[name] = (handler, kw)

        @staticmethod
        def stop():
            return _bus.STOP

    _base.Plugin = _Plugin
    _qqbot.core = _core
    _core.bus = _bus
    _qqbot.plugins = _plugins
    _plugins.base = _base
    for _n, _m in {"qqbot": _qqbot, "qqbot.core": _core, "qqbot.core.bus": _bus,
                   "qqbot.plugins": _plugins, "qqbot.plugins.base": _base}.items():
        sys.modules[_n] = _m
    from qqbot.core.bus import STOP  # noqa: F401

_PKG = Path(__file__).resolve().parent.parent
for _p in ("/opt/qqbot/plugins_ext", "/opt/qqbot", str(_PKG.parent)):
    if _p not in sys.path:
        sys.path.insert(0, _p)

try:
    import voice_clone  # noqa: F401
except ImportError:
    import vclone_dev as voice_clone  # noqa: F401
    sys.modules.setdefault("voice_clone", voice_clone)

PASS = FAIL = 0


def check(name, cond, detail=""):
    global PASS, FAIL
    if cond:
        PASS += 1
        print(f"  ✓ {name}")
    else:
        FAIL += 1
        print(f"  ✗ {name} {detail}")


def _make(gw=None):
    from voice_clone import VoiceClonePlugin

    class FakePaths:
        plugin_data_dir = Path("/tmp")

    class FakeCfg:
        paths = FakePaths()

        class bot:  # noqa: N801
            admins = [3227868908]

        def save(self):
            pass

    class FakeBot:
        config = FakeCfg()

    bot = FakeBot()
    p = VoiceClonePlugin(bot)
    calls = []

    def fake_gw(path, method="GET", body=None, timeout=30):
        calls.append((path, method, body))
        return (gw or {}).get((path, method), {})

    p._gw = fake_gw
    p._calls = calls
    return p


class CmdCtx:
    def __init__(self):
        self.replies = []

    async def reply(self, msg):
        self.replies.append(msg)


def t_basic():
    print("[1] 指令：状态/列表/应用/删除")
    gw = {
        ("", "GET"): {"items": [
            {"id": "cl_1", "name": "测试音", "status": "ready",
             "analysis": {"pitch_hz": 179},
             "provider": {"voice_id": "abc"}},
            {"id": "cl_2", "name": "本地音", "status": "ready",
             "analysis": {"pitch_hz": 210},
             "provider": {"voice_id": ""}},
        ], "provider": {"type": "fish", "configured": True}},
        ("/apply", "POST"): {"ok": True, "mode": "provider"},
    }
    p = _make(gw)
    asyncio.run(p.on_load())
    check("指令已注册", "clone" in p._cmds)
    c = CmdCtx()
    asyncio.run(p._cmd(c, ""))
    check("状态显示服务商", "fish" in c.replies[0] and "已配置" in c.replies[0])
    check("状态含模式统计", "真克隆×1" in c.replies[0] and "本地对齐×1" in c.replies[0])
    c = CmdCtx()
    asyncio.run(p._cmd(c, "列表"))
    check("列表两行", "测试音" in c.replies[0] and "本地音" in c.replies[0])
    check("真克隆标记", "真克隆" in c.replies[0])
    c = CmdCtx()
    asyncio.run(p._cmd(c, "应用 cl_1"))
    check("应用成功提示", "真克隆音色" in c.replies[0])
    check("apply 调用网关", ("/apply", "POST", {"id": "cl_1"}) in p._calls)
    c = CmdCtx()
    asyncio.run(p._cmd(c, "删除 cl_2"))
    check("删除调用", ("?id=cl_2", "DELETE", None) in p._calls)
    # 网关返回错误 → 透传（用无 apply 映射的桩）
    p3 = _make({("", "GET"): {"items": [], "provider": {}}})
    c = CmdCtx()
    asyncio.run(p3._cmd(c, "应用 不存在"))
    check("网关报错透传", "失败" in c.replies[0], str(c.replies))


def t_empty():
    print("[2] 空列表与异常")
    p = _make({("", "GET"): {"items": [], "provider": {"type": "local"}}})
    c = CmdCtx()
    asyncio.run(p._cmd(c, "列表"))
    check("空列表提示", "还没有克隆" in c.replies[0])
    p2 = _make(None)

    def boom(path, method="GET", body=None, timeout=30):
        raise RuntimeError("connection refused")

    p2._gw = boom
    c = CmdCtx()
    asyncio.run(p2._cmd(c, ""))
    check("网关挂了不崩", "失败" in c.replies[0])


if __name__ == "__main__":
    t_basic()
    t_empty()
    print(f"\n结果：{PASS} 通过 / {FAIL} 失败")
    sys.exit(1 if FAIL else 0)
