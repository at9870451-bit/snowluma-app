"""QQBot VoiceClone 克隆声音插件 v1.0.0

克隆声音的管理指令面（实际克隆工作在 ai_gateway /clone 端点完成）：
  - 列出已建克隆（本地对齐 / 真克隆 provider 两种模式）
  - 应用某个克隆到 role_tts（写入配置并自动重启生效）
  - 删除克隆

克隆来源：App「克隆声音」卡片上传样本，或语音包直接克隆。
两种模式：
  - local（默认）：分析样本 → 匹配最接近音色 + 音高/音量参数对齐
  - fish（配置了 fish.audio Key）：真·声音克隆（训练 voice_id → TTS 用克隆音色）

指令：/clone 状态｜列表｜应用 <id>｜删除 <id>
"""

from __future__ import annotations

import json
import urllib.request
from typing import Any

from qqbot.plugins.base import Plugin

GW = "http://127.0.0.1:8090/clone"


class VoiceClonePlugin(Plugin):
    name = "voice_clone"
    display_name = "克隆声音"
    version = "1.0.0"
    description = "克隆声音管理：样本分析对齐 / fish.audio 真克隆，应用到 role_tts 说话"
    priority = 14  # 纯管理插件，不参与消息流

    default_config = {
        "enabled": True,
        "gateway": GW,
    }

    config_labels = {
        "enabled": "启用克隆声音指令",
    }

    def __init__(self, bot) -> None:
        super().__init__(bot)

    async def on_load(self) -> None:
        if not self.cfg_get("enabled", True):
            return
        self.add_command("clone", self._cmd, aliases=("克隆",),
                         admin=True, description="克隆声音：状态/列表/应用/删除")
        self.log.info("克隆声音指令已启用（gateway=%s）", self.cfg_get("gateway", GW))

    # ---------- 网关调用 ----------

    def _gw(self, path: str, method: str = "GET",
            body: dict | None = None, timeout: int = 30) -> dict[str, Any]:
        base = str(self.cfg_get("gateway", GW)).rstrip("/")
        url = f"{base}{path}"
        data = json.dumps(body).encode() if body is not None else None
        req = urllib.request.Request(
            url, data=data, method=method,
            headers={"Content-Type": "application/json"})
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return json.loads(r.read() or b"{}")

    # ---------- 指令 ----------

    async def _cmd(self, ctx, args: str) -> Any:
        a = (args or "").strip()
        head, _, rest = a.partition(" ")
        rest = rest.strip()

        if head in ("", "状态", "status"):
            try:
                r = self._gw("")
                items = r.get("items") or []
                prov = r.get("provider") or {}
                ready = sum(1 for i in items if i.get("status") == "ready")
                modes: dict[str, int] = {}
                for i in items:
                    m = "真克隆" if (i.get("provider") or {}).get("voice_id") else "本地对齐"
                    modes[m] = modes.get(m, 0) + 1
                lines = ["【克隆声音】",
                         f"服务商：{prov.get('type', 'local')}"
                         f"{'（已配置 Key）' if prov.get('configured') else '（本地对齐模式）'}",
                         f"克隆：{len(items)} 个（可用 {ready}）",
                         "模式分布：" + ("、".join(f"{k}×{v}" for k, v in modes.items())
                                        if modes else "无"),
                         "App「克隆声音」卡片可上传样本，/clone 应用 <id> 生效"]
                await self._reply(ctx, "\n".join(lines))
            except Exception as exc:  # noqa: BLE001
                await self._reply(ctx, f"读取克隆状态失败：{exc}")
            return self.stop()

        if head in ("列表", "list"):
            try:
                r = self._gw("")
                items = r.get("items") or []
                if not items:
                    await self._reply(ctx, "还没有克隆。App 上传音频样本即可创建。")
                    return self.stop()
                lines = []
                for i in items[:12]:
                    prov = i.get("provider") or {}
                    mode = "真克隆" if prov.get("voice_id") else "对齐"
                    an = i.get("analysis") or {}
                    hz = an.get("pitch_hz") or "?"
                    lines.append(f"#{i['id']} {i.get('name','')} [{mode}]"
                                 f"{i.get('status','')} 基频{hz}Hz")
                await self._reply(ctx, "\n".join(lines))
            except Exception as exc:  # noqa: BLE001
                await self._reply(ctx, f"读取列表失败：{exc}")
            return self.stop()

        if head in ("应用", "apply") and rest:
            try:
                r = self._gw("/apply", "POST", {"id": rest}, timeout=60)
                if r.get("ok"):
                    mode = r.get("mode", "pitchmatch")
                    txt = ("已应用真克隆音色" if mode == "provider"
                           else "已应用对齐音色（最接近音色+音高对齐）")
                    await self._reply(ctx, f"{txt}，机器人重启后生效。")
                else:
                    await self._reply(ctx, f"应用失败：{r.get('msg', '未知错误')}")
            except Exception as exc:  # noqa: BLE001
                await self._reply(ctx, f"应用失败：{exc}")
            return self.stop()

        if head in ("删除", "del") and rest:
            try:
                self._gw(f"?id={rest}", "DELETE")
                await self._reply(ctx, f"已删除克隆 {rest}。")
            except Exception as exc:  # noqa: BLE001
                await self._reply(ctx, f"删除失败：{exc}")
            return self.stop()

        await self._reply(ctx, "用法：/clone 状态｜列表｜应用 <id>｜删除 <id>")
        return self.stop()

    async def _reply(self, ctx, message: str) -> None:
        try:
            await ctx.reply(message)
        except Exception as exc:  # noqa: BLE001
            self.log.warning("回复失败: %s", exc)
