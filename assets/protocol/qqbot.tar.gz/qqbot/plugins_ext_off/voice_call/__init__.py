"""QQBot VoiceCall 「语音来电」插件 v1.0.0

QQ 协议不支持机器人拨出真实语音通话（OneBot/NapCat 无此 API），
本插件用「语音来电」模拟通话体验：

  1. 主人 /call <QQ> [话题] → 向好友发出语音来电邀请
     「📞 语音来电 · 菲比（回复任意消息接听）」
  2. 对方回第一条消息 = 接听 → 菲比用语音打招呼
  3. 通话中：对方每说一句，菲比都用【语音】短句回应（像打电话，不刷文字）
  4. 挂断：对方说「挂了/拜拜/先这样/不聊了」→ 语音告别；
     或静默超时（默认 3 分钟）/ 通话超时（默认 10 分钟）→ 自动「我先挂啦」

指令：/call <QQ> [话题]｜/call 状态｜/call 挂断 <QQ>
"""

from __future__ import annotations

import asyncio
import time
from typing import Any

from qqbot.core.bus import STOP
from qqbot.core.message import Message, text as text_seg
from qqbot.plugins.base import Plugin

_HANGUP_WORDS = ("挂了", "拜拜", "再见", "先这样", "不聊了", "挂断", "886", "bye")

_TICK_SECONDS = 30


class VoiceCallPlugin(Plugin):
    name = "voice_call"
    display_name = "语音来电"
    version = "1.0.0"
    description = "模拟语音通话：来电邀请→对方接听→全程用语音对话，说「挂了」或静默自动挂断"
    priority = 12  # 早于其它消息处理：通话中的消息优先走语音回复

    default_config = {
        "enabled": True,
        "idle_timeout_seconds": 180,   # 静默多久自动挂断
        "max_call_seconds": 600,       # 单次通话最长时长
        "greeting": "喂？是我呀，听得见吗？",
        "farewell": "那先这样啦，挂了啊，回头再聊。",
        "timeout_farewell": "喂？好像没动静了，那我先挂啦。",
        "max_reply_chars": 40,
        "callback_enabled": True,      # 别人想打电话来时自动语音回拨
    }

    config_labels = {
        "enabled": "启用语音来电",
        "idle_timeout_seconds": "静默自动挂断（秒）",
        "max_call_seconds": "单次通话上限（秒）",
        "greeting": "接听开场白",
        "farewell": "挂断告别语",
    }

    def __init__(self, bot) -> None:
        super().__init__(bot)
        # uid -> {"started": ts, "last": ts, "topic": str, "greeted": bool}
        self._calls: dict[int, dict[str, Any]] = {}
        self._offers: dict[int, float] = {}  # uid -> 回拨邀请时间
        self._tick_task: asyncio.Task | None = None

    # ---------- 生命周期 ----------

    async def on_load(self) -> None:
        if not self.cfg_get("enabled", True):
            return
        self.add_command("call", self._cmd, aliases=("打电话", "语音来电"),
                         admin=True, description="语音来电：发起/状态/挂断")
        self._tick_task = asyncio.get_running_loop().create_task(self._tick_loop())
        self.log.info("语音来电已启用（静默挂断 %ss）",
                      self.cfg_get("idle_timeout_seconds", 180))

    async def on_unload(self) -> None:
        if self._tick_task:
            self._tick_task.cancel()

    # ---------- 消息入口 ----------

    async def on_message(self, ctx) -> Any:
        if not self.cfg_get("enabled", True):
            return None
        m = self._norm(ctx)
        if not m["text"] or m["is_group"]:
            return None  # 语音来电只在私聊
        uid = m["user_id"]
        call = self._calls.get(uid)
        if call is None:
            # 来电意图：别人想给机器人打电话 / 抱怨不接电话 → 语音回拨
            if self.cfg_get("callback_enabled", True) \
                    and self._is_call_intent(m["text"]):
                await self._handle_call_intent(uid, m["text"])
                return STOP
            # 已给出过回拨邀请 → 对方回复「接/好」即开始（10 分钟内有效）
            if uid in self._offers \
                    and time.time() - self._offers[uid] <= 600 \
                    and self._is_accept(m["text"]):
                self._offers.pop(uid, None)
                topic = ""
                ok = await self._start_call(uid, topic)
                if ok:
                    await self._safe_voice(
                        uid, "喂？通啦通啦，我在呢！")
                    call = self._calls.get(uid)
                    if call:
                        call["greeted"] = True
                return STOP
            return None
        now = time.time()
        # 超时检查
        if (now - call["last"] > self._idle_timeout()
                or now - call["started"] > self._max_call()):
            await self._hangup(uid, timeout=True)
            return STOP
        call["last"] = now
        # 接听：第一条消息 → 语音打招呼 + 回应
        text = m["text"]
        if any(w in text for w in _HANGUP_WORDS):
            await self._safe_voice(uid, str(self.cfg_get("farewell", "挂啦。")))
            self._calls.pop(uid, None)
            return STOP
        if not call["greeted"]:
            call["greeted"] = True
            await self._safe_voice(uid, str(self.cfg_get(
                "greeting", "喂？听得见吗？")))
        reply = await self._call_reply(uid, text, call.get("topic", ""))
        if reply:
            await self._safe_voice(uid, reply)
        return STOP  # 通话中的消息不再交给普通 AI 文本回复

    async def _call_reply(self, uid: int, text: str, topic: str) -> str:
        """打电话式短句回应（语音念出来自然）。"""
        try:
            client = self.bot.chat_client()
            prompt = (f"你正在和对方打电话。"
                      + (f"这通电话的话题是：{topic}。" if topic else "")
                      + f"对方刚说：「{text}」\n"
                      "用一句话回应，像打电话一样口语、简短（40 字以内），"
                      "不要书面语、不要列举、不要反问太多，只输出这句话。")
            out = (await asyncio.wait_for(
                client.chat(f"call_{uid}", prompt, ""), timeout=40)) or ""
            return out.strip().replace("\n", " ")[:int(
                self.cfg_get("max_reply_chars", 40))]
        except Exception as exc:  # noqa: BLE001
            self.log.debug("通话回复生成失败: %s", exc)
            return ""

    # ---------- 来电意图（别人打来的"电话"） ----------

    _INTENT_WORDS = ("不接电话", "怎么不接", "为什么不接", "没接电话", "打电话给",
                     "给我打", "打个电话", "打电话吗", "语音通话", "接个电话",
                     "接到电话", "打你电话", "你电话多少")
    _NEGATIVE_WORDS = ("别打", "不要打", "不用打", "别给我", "不想接", "别想打")
    _ACCEPT_WORDS = ("接", "好", "好呀", "好啊", "可以", "行", "打吧", "来吧",
                     "嗯", "要", "打")

    def _is_call_intent(self, text: str) -> bool:
        t = text.lower()
        if any(w in t for w in self._NEGATIVE_WORDS):
            return False
        return any(w in t for w in self._INTENT_WORDS)

    def _is_accept(self, text: str) -> bool:
        t = text.strip().lower()
        return any(t == w or t.startswith(w) for w in self._ACCEPT_WORDS) \
            and len(t) <= 6

    async def _handle_call_intent(self, uid: int, text: str) -> None:
        """别人打来"电话"：说明 + 直接语音回拨（模拟通话）。"""
        now = time.time()
        last = self._offers.get(uid, 0)
        if now - last < 60:  # 1 分钟内别反复推销
            return
        self._offers[uid] = now
        await self._safe_voice(
            uid, "呀，QQ 电话我这边收不到来电啦。这样，我现在直接给你拨一个"
                 "语音电话，你回我一个「接」字，咱们就通上啦！")

    # ---------- 通话控制 ----------

    async def _start_call(self, uid: int, topic: str) -> bool:
        if uid in self._calls:
            return False
        message = (f"📞 语音来电 · 菲比\n"
                   f"{('话题：' + topic) if topic else '（回复任意消息接听）'}")
        try:
            await self.bot.send_private_msg(uid, Message([text_seg(message)]))
        except Exception as exc:  # noqa: BLE001
            self.log.warning("来电邀请发送失败(%s): %s", uid, exc)
            return False
        now = time.time()
        self._calls[uid] = {"started": now, "last": now, "topic": topic,
                            "greeted": False}
        self.log.info("语音来电 → %s（话题：%s）", uid, topic or "无")
        return True

    async def _hangup(self, uid: int, *, timeout: bool = False,
                      farewell: str | None = None) -> None:
        if uid not in self._calls:
            return
        self._calls.pop(uid, None)
        text = farewell or (str(self.cfg_get("timeout_farewell", "我先挂啦。"))
                            if timeout else
                            str(self.cfg_get("farewell", "挂啦。")))
        await self._safe_voice(uid, text)
        self.log.info("语音来电结束 → %s（%s）", uid, "超时" if timeout else "对方挂断")

    async def _safe_voice(self, uid: int, text: str) -> None:
        """优先发语音；TTS 失败降级为文字。"""
        try:
            seg = await self.bot.voice_segment(text)
            await self.bot.send_private_msg(uid, seg)
        except Exception as exc:  # noqa: BLE001
            self.log.debug("语音发送失败，降级文字: %s", exc)
            try:
                await self.bot.send_private_msg(uid, Message([text_seg(text)]))
            except Exception:
                pass

    # ---------- 超时巡查 ----------

    async def _tick_loop(self) -> None:
        await asyncio.sleep(15)
        while True:
            try:
                now = time.time()
                for uid, call in list(self._calls.items()):
                    if (now - call["last"] > self._idle_timeout()
                            or now - call["started"] > self._max_call()):
                        await self._hangup(uid, timeout=True)
            except asyncio.CancelledError:
                raise
            except Exception as exc:  # noqa: BLE001
                self.log.warning("通话巡查异常: %s", exc)
            await asyncio.sleep(_TICK_SECONDS)

    def _idle_timeout(self) -> float:
        return max(30.0, float(self.cfg_get("idle_timeout_seconds", 180)))

    def _max_call(self) -> float:
        return max(60.0, float(self.cfg_get("max_call_seconds", 600)))

    # ---------- 指令 ----------

    async def _cmd(self, ctx, args: str) -> Any:
        a = (args or "").strip()
        head, _, rest = a.partition(" ")
        rest = rest.strip()

        if head in ("状态", "status"):
            if not self._calls:
                await self._reply(ctx, "当前没有进行中的通话。")
                return self.stop()
            now = time.time()
            lines = ["【进行中的通话】"]
            for uid, c in self._calls.items():
                lines.append(f"QQ {uid} · 已通 {int(now - c['started'])}s"
                             f" · 静默 {int(now - c['last'])}s"
                             + (f" · 话题：{c['topic']}" if c.get("topic") else ""))
            await self._reply(ctx, "\n".join(lines))
            return self.stop()

        if head in ("挂断", "hangup") and rest.isdigit():
            if int(rest) in self._calls:
                await self._hangup(int(rest))
                await self._reply(ctx, f"已挂断与 {rest} 的通话。")
            else:
                await self._reply(ctx, "当前没有和这个人的通话。")
            return self.stop()

        if head.isdigit():
            uid = int(head)
            topic = rest
            ok = await self._start_call(uid, topic)
            await self._reply(ctx, f"来电已拨给 {uid}，等对方回消息接听。"
                              if ok else f"发起失败（可能已在通话中或发送失败）。")
            return self.stop()

        await self._reply(ctx, "用法：/call <QQ> [话题]｜/call 状态｜/call 挂断 <QQ>")
        return self.stop()

    # ---------- 工具 ----------

    async def _reply(self, ctx, message: str) -> None:
        try:
            await ctx.reply(message)
        except Exception as exc:  # noqa: BLE001
            self.log.warning("回复失败: %s", exc)

    def _norm(self, ctx) -> dict[str, Any]:
        event = getattr(ctx, "event", ctx)
        try:
            uid = int(getattr(event, "user_id", 0) or 0)
        except (TypeError, ValueError):
            uid = 0
        gid = getattr(event, "group_id", None)
        try:
            gid = int(gid) if gid else None
        except (TypeError, ValueError):
            gid = None
        return {
            "user_id": uid,
            "group_id": gid,
            "is_group": gid is not None,
            "text": str(getattr(event, "text", "") or "").strip(),
            "is_admin": bool(getattr(ctx, "is_admin", False)),
        }
