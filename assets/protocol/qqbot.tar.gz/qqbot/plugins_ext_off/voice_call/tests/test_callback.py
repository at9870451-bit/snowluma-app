"""voice_call 回拨测试补充：来电意图/接受/拒绝。"""
from __future__ import annotations

import asyncio
import sys
import time
from pathlib import Path
from types import SimpleNamespace

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
try:
    from qqbot.core.bus import STOP  # noqa: F401
    from qqbot.core.message import Message, text as text_seg  # noqa: F401
except ImportError:
    import types as _t
    _qqbot = _t.ModuleType("qqbot")
    _core = _t.ModuleType("qqbot.core")
    _bus = _t.ModuleType("qqbot.core.bus")
    _bus.STOP = "STOP"
    _msg = _t.ModuleType("qqbot.core.message")

    class _Msg:
        def __init__(self, segs):
            self.segs = segs

        def __str__(self):
            return "|".join(str(s) for s in self.segs)

    _msg.Message = _Msg
    _msg.text = lambda t: t
    _plugins = _t.ModuleType("qqbot.plugins")
    _base = _t.ModuleType("qqbot.plugins.base")

    class _Plugin:
        priority = 50

        def __init__(self, bot=None):
            import logging
            self.bot = bot
            self.cfg = dict(getattr(self, "default_config", {}) or {})
            self._cmds = {}
            self.log = logging.getLogger("stub")

        @property
        def data_dir(self):
            return Path("/tmp")

        def cfg_get(self, key, default=None):
            return self.cfg.get(key, default)

        def add_command(self, name, handler, **kw):
            self._cmds[name] = (handler, kw)

        @staticmethod
        def stop():
            return _bus.STOP

    _base.Plugin = _Plugin
    _qqbot.core = _core
    _core.bus = _bus
    _core.message = _msg
    _qqbot.plugins = _plugins
    _plugins.base = _base
    for _n, _m in {"qqbot": _qqbot, "qqbot.core": _core, "qqbot.core.bus": _bus,
                   "qqbot.core.message": _msg, "qqbot.plugins": _plugins,
                   "qqbot.plugins.base": _base}.items():
        sys.modules[_n] = _m
    from qqbot.core.bus import STOP  # noqa: F401
    from qqbot.core.message import Message, text as text_seg  # noqa: F401

_PKG = Path(__file__).resolve().parent.parent
for _p in ("/opt/qqbot/plugins_ext", "/opt/qqbot", str(_PKG.parent)):
    if _p not in sys.path:
        sys.path.insert(0, _p)

try:
    import voice_call  # noqa: F401
except ImportError:
    import vcall_dev as voice_call  # noqa: F401
    sys.modules.setdefault("voice_call", voice_call)

PASS = FAIL = 0


def check(name, cond, detail=""):
    global PASS, FAIL
    if cond:
        PASS += 1
        print(f"  ✓ {name}")
    else:
        FAIL += 1
        print(f"  ✗ {name} {detail}")


def _make(cfg_extra=None):
    from voice_call import VoiceCallPlugin

    class FakeChat:
        async def chat(self, session, prompt, context, **kw):
            return "嗯嗯我在听"

    class FakeCfg:
        class bot:  # noqa: N801
            admins = [3227868908]

    class FakeBot:
        config = FakeCfg()
        voice = []
        texts = []

        async def voice_segment(self, text):
            FakeBot.voice.append(text)
            return Message([text_seg(f"[语音]{text}")])

        async def send_private_msg(self, uid, message, *a, **k):
            FakeBot.texts.append((uid, str(message)))
            return {}

        chat_client = lambda self: FakeChat()  # noqa: E731

    bot = FakeBot()
    p = VoiceCallPlugin(bot)
    p.cfg.update(cfg_extra or {})
    return bot, p


def _ctx(uid, text, gid=None):
    ev = SimpleNamespace(user_id=uid, group_id=gid, text=text,
                         sender={"card": "x", "nickname": "x"},
                         message_id=1, message=[], raw_message=text)
    return SimpleNamespace(event=ev, user_id=uid, group_id=gid, text=text,
                           is_group=gid is not None, is_admin=False, replies=[])


def t_intent():
    print("[1] 来电意图：抱怨不接 → 语音回拨邀请")
    bot, p = _make()
    r = asyncio.run(p.on_message(_ctx(555, "你怎么不接电话啊")))
    check("意图消息 STOP", r is STOP)
    check("语音解释+邀请", any("回我一个「接」" in t or "拨一个" in t
                              for t in bot.voice), str(bot.voice[:1]))
    check("已记回拨邀请", 555 in p._offers)
    # 拒绝语不触发
    bot2, p2 = _make()
    r2 = asyncio.run(p2.on_message(_ctx(555, "别打电话给我")))
    check("拒绝语放行", r2 is None)
    # 群里不触发
    bot3, p3 = _make()
    r3 = asyncio.run(p3.on_message(_ctx(555, "怎么不接电话", gid=9)))
    check("群消息放行", r3 is None)
    # 1 分钟内不重复推销
    bot4, p4 = _make()
    asyncio.run(p4.on_message(_ctx(555, "怎么不接电话")))
    n1 = len(bot4.voice)
    asyncio.run(p4.on_message(_ctx(555, "为什么不接电话")))
    check("冷却不重复", len(bot4.voice) == n1)


def t_accept():
    print("[2] 回复「接」→ 直接通话")
    bot, p = _make()
    asyncio.run(p.on_message(_ctx(555, "你怎么不接电话")))
    bot.voice.clear()
    r = asyncio.run(p.on_message(_ctx(555, "接")))
    check("接受返回 STOP", r is STOP)
    check("进入通话", 555 in p._calls)
    check("语音打招呼", any("通啦" in t for t in bot.voice), str(bot.voice))
    # 通话中消息照常语音回复
    bot.voice.clear()
    r2 = asyncio.run(p.on_message(_ctx(555, "在干嘛呢")))
    check("通话继续", r2 is STOP and any("我在听" in t for t in bot.voice))
    # 开关关闭 → 意图不触发
    bot5, p5 = _make({"callback_enabled": False})
    r5 = asyncio.run(p5.on_message(_ctx(555, "怎么不接电话")))
    check("回拨可关闭", r5 is None)


def t_offer_expiry():
    print("[3] 邀请过期：10 分钟后再说「接」不算")
    bot, p = _make()
    asyncio.run(p.on_message(_ctx(555, "怎么不接电话")))
    p._offers[555] = time.time() - 700  # 模拟 11 分钟前
    r = asyncio.run(p.on_message(_ctx(555, "接")))
    check("过期邀请不算", r is None and 555 not in p._calls)


if __name__ == "__main__":
    t_intent()
    t_accept()
    t_offer_expiry()
    print(f"\n结果：{PASS} 通过 / {FAIL} 失败")
    sys.exit(1 if FAIL else 0)
