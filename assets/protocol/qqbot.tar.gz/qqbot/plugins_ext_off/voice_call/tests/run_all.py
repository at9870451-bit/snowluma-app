"""voice_call 测试（离线：发起/接听/语音对话/挂断/超时/指令）。"""
from __future__ import annotations

import asyncio
import sys
import time
from pathlib import Path
from types import SimpleNamespace

try:
    from qqbot.core.bus import STOP  # noqa: F401
    from qqbot.core.message import Message, text as text_seg  # noqa: F401
except ImportError:
    import types as _t
    _qqbot = _t.ModuleType("qqbot")
    _core = _t.ModuleType("qqbot.core")
    _bus = _t.ModuleType("qqbot.core.bus")
    _bus.STOP = "STOP"
    _msg = _t.ModuleType("qqbot.core.message")

    class _Msg:
        def __init__(self, segs):
            self.segs = segs

        def __str__(self):
            return "|".join(str(s) for s in self.segs)

    _msg.Message = _Msg

    def _text(t):
        return t

    _msg.text = _text
    _plugins = _t.ModuleType("qqbot.plugins")
    _base = _t.ModuleType("qqbot.plugins.base")

    class _Plugin:
        priority = 50

        def __init__(self, bot=None):
            import logging
            self.bot = bot
            self.cfg = dict(getattr(self, "default_config", {}) or {})
            self._cmds = {}
            self.log = logging.getLogger("stub")

        @property
        def data_dir(self):
            return Path("/tmp")

        def cfg_get(self, key, default=None):
            return self.cfg.get(key, default)

        def add_command(self, name, handler, **kw):
            self._cmds[name] = (handler, kw)

        @staticmethod
        def stop():
            return _bus.STOP

    _base.Plugin = _Plugin
    _qqbot.core = _core
    _core.bus = _bus
    _core.message = _msg
    _qqbot.plugins = _plugins
    _plugins.base = _base
    for _n, _m in {"qqbot": _qqbot, "qqbot.core": _core, "qqbot.core.bus": _bus,
                   "qqbot.core.message": _msg, "qqbot.plugins": _plugins,
                   "qqbot.plugins.base": _base}.items():
        sys.modules[_n] = _m
    from qqbot.core.bus import STOP  # noqa: F401
    from qqbot.core.message import Message, text as text_seg  # noqa: F401

_PKG = Path(__file__).resolve().parent.parent
for _p in ("/opt/qqbot/plugins_ext", "/opt/qqbot", str(_PKG.parent)):
    if _p not in sys.path:
        sys.path.insert(0, _p)

try:
    import voice_call  # noqa: F401
except ImportError:
    import vcall_dev as voice_call  # noqa: F401
    sys.modules.setdefault("voice_call", voice_call)

PASS = FAIL = 0


def check(name, cond, detail=""):
    global PASS, FAIL
    if cond:
        PASS += 1
        print(f"  ✓ {name}")
    else:
        FAIL += 1
        print(f"  ✗ {name} {detail}")


def _make(cfg_extra=None):
    from voice_call import VoiceCallPlugin

    class FakeChat:
        async def chat(self, session, prompt, context, **kw):
            return "嗯嗯我在听，你继续说呀"

    class FakeCfg:
        class bot:  # noqa: N801
            admins = [3227868908]

    class FakeBot:
        config = FakeCfg()
        voice_calls = []
        text_calls = []

        async def voice_segment(self, text):
            FakeBot.text_calls.append(text)
            return Message([text_seg(f"[语音]{text}")])

        async def send_private_msg(self, uid, message, *a, **k):
            FakeBot.voice_calls.append((uid, str(message)))
            return {}

        chat_client = lambda self: FakeChat()  # noqa: E731

    bot = FakeBot()
    p = VoiceCallPlugin(bot)
    p.cfg.update(cfg_extra or {})
    return bot, p


def _ctx(uid, text, gid=None):
    ev = SimpleNamespace(user_id=uid, group_id=gid, text=text,
                         sender={"card": "x", "nickname": "x"},
                         message_id=1, message=[], raw_message=text)
    c = SimpleNamespace(event=ev, user_id=uid, group_id=gid, text=text,
                        is_group=gid is not None, is_admin=False, replies=[])
    box = c.replies

    async def _reply(msg, **kw):
        box.append(msg)

    c.reply = _reply
    return c


def t_start():
    print("[1] 发起来电：邀请消息 + 状态")
    bot, p = _make()
    ok = asyncio.run(p._start_call(555, "周末去哪玩"))
    check("发起成功", ok)
    check("邀请已发送", any(u == 555 and "语音来电" in s for u, s in bot.voice_calls))
    check("会话已建立", 555 in p._calls)
    check("重复发起拒绝", not asyncio.run(p._start_call(555, "")))


def t_in_call():
    print("[2] 通话中：接听语音打招呼 + 语音回应 + STOP")
    bot, p = _make()
    asyncio.run(p._start_call(555, ""))
    bot.voice_calls.clear()
    bot.text_calls.clear()
    r = asyncio.run(p.on_message(_ctx(555, "喂听得见")))
    check("通话消息返回 STOP", r is STOP)
    texts = bot.text_calls
    check("先打招呼", any("听得见吗" in t for t in texts), str(texts))
    check("再语音回应", any("继续说" in t for t in texts))
    # 群消息不触发通话
    r2 = asyncio.run(p.on_message(_ctx(555, "群里说话", gid=123)))
    check("群消息不拦截", r2 is None)
    # 非通话对象不受影响
    r3 = asyncio.run(p.on_message(_ctx(777, "我是别人")))
    check("非通话对象放行", r3 is None)


def t_hangup():
    print("[3] 挂断：关键词告别 + 会话清理")
    bot, p = _make()
    asyncio.run(p._start_call(555, ""))
    asyncio.run(p.on_message(_ctx(555, "你好呀")))
    bot.voice_calls.clear()
    r = asyncio.run(p.on_message(_ctx(555, "好啦我挂了拜拜")))
    check("挂断返回 STOP", r is STOP)
    check("告别语发出", any("先这样" in s for _, s in bot.voice_calls))
    check("会话已清除", 555 not in p._calls)


def t_timeout():
    print("[4] 超时：静默自动挂断")
    bot, p = _make({"idle_timeout_seconds": 60})
    asyncio.run(p._start_call(555, ""))
    p._calls[555]["last"] = time.time() - 120  # 模拟静默 2 分钟
    bot.voice_calls.clear()
    r = asyncio.run(p.on_message(_ctx(555, "在吗")))
    check("超时挂断 STOP", r is STOP)
    check("超时告别发出", any("先挂啦" in s for _, s in bot.voice_calls))
    check("会话已清除", 555 not in p._calls)


def t_cmd():
    print("[5] 指令：发起/状态/挂断")
    bot, p = _make()

    class Ctx:
        def __init__(self):
            self.replies = []

        async def reply(self, msg):
            self.replies.append(msg)

    c = Ctx()
    asyncio.run(p._cmd(c, "666 聊聊游戏"))
    check("指令发起", 666 in p._calls)
    c = Ctx()
    asyncio.run(p._cmd(c, "状态"))
    check("状态显示通话", "666" in c.replies[0])
    c = Ctx()
    asyncio.run(p._cmd(c, "挂断 666"))
    check("指令挂断", "已挂断" in c.replies[0] and 666 not in p._calls)
    c = Ctx()
    asyncio.run(p._cmd(c, "状态"))
    check("无通话提示", "没有进行中的通话" in c.replies[0])


def t_fallback():
    print("[6] TTS 失败降级文字")

    class FakeCfg:
        class bot:  # noqa: N801
            admins = [3227868908]

    class BadBot:
        config = FakeCfg()
        texts = []

        async def voice_segment(self, text):
            raise RuntimeError("tts down")

        async def send_private_msg(self, uid, message, *a, **k):
            BadBot.texts.append((uid, str(message)))
            return {}

        chat_client = lambda self: None  # noqa: E731

    from voice_call import VoiceCallPlugin
    p = VoiceCallPlugin(BadBot())
    asyncio.run(p._safe_voice(1, "测试语音"))
    check("降级为文字发送", any(u == 1 and "测试语音" in s for u, s in BadBot.texts))


if __name__ == "__main__":
    t_start()
    t_in_call()
    t_hangup()
    t_timeout()
    t_cmd()
    t_fallback()
    print(f"\n结果：{PASS} 通过 / {FAIL} 失败")
    sys.exit(1 if FAIL else 0)
