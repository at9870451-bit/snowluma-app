"""seven_emotions 测试套件（离线：词库/衰减/节律/好感/注入/指令）。

运行：cd /opt/qqbot && python3 plugins_ext/seven_emotions/tests/run_all.py
本地（目录名 emo7x）直接 python3 run_all.py —— 自动打桩。
"""

from __future__ import annotations

import asyncio
import sys
import tempfile
import time
from pathlib import Path
from types import SimpleNamespace

try:
    from qqbot.core.bus import STOP  # noqa: F401
except ImportError:
    import types as _t
    _qqbot = _t.ModuleType("qqbot")
    _core = _t.ModuleType("qqbot.core")
    _bus = _t.ModuleType("qqbot.core.bus")
    _bus.STOP = "STOP"
    _msg = _t.ModuleType("qqbot.core.message")
    _msg.Message = type("Message", (), {})
    _plugins = _t.ModuleType("qqbot.plugins")
    _base = _t.ModuleType("qqbot.plugins.base")

    class _Plugin:
        priority = 50

        def __init__(self, bot=None):
            import logging
            self.bot = bot
            self.cfg = dict(getattr(self, "default_config", {}) or {})
            self._cmds = {}
            self.log = logging.getLogger("stub")

        @property
        def data_dir(self):
            return self.bot.config.paths.plugin_data_dir / self.name

        def cfg_get(self, key, default=None):
            return self.cfg.get(key, default)

        def save_config(self):
            pass

        def add_command(self, name, handler, **kw):
            self._cmds[name] = (handler, kw)

        @staticmethod
        def stop():
            return _bus.STOP

    _base.Plugin = _Plugin
    _qqbot.core = _core
    _core.bus = _bus
    _core.message = _msg
    _qqbot.plugins = _plugins
    _plugins.base = _base
    for _n, _m in {"qqbot": _qqbot, "qqbot.core": _core,
                   "qqbot.core.bus": _bus, "qqbot.core.message": _msg,
                   "qqbot.plugins": _plugins, "qqbot.plugins.base": _base}.items():
        sys.modules[_n] = _m
    from qqbot.core.bus import STOP  # noqa: F401

_PKG = Path(__file__).resolve().parent.parent
for _p in ("/opt/qqbot/plugins_ext", "/opt/qqbot", str(_PKG.parent)):
    if _p not in sys.path:
        sys.path.insert(0, _p)

try:
    import seven_emotions  # noqa: F401
except ImportError:
    import emo7x as seven_emotions  # noqa: F401
    sys.modules.setdefault("seven_emotions", seven_emotions)

PASS = FAIL = 0


def check(name, cond, detail=""):
    global PASS, FAIL
    if cond:
        PASS += 1
        print(f"  ✓ {name}")
    else:
        FAIL += 1
        print(f"  ✗ {name} {detail}")


def _make_plugin(cfg_extra=None):
    from seven_emotions import SevenEmotionsPlugin

    class FakePaths:
        plugin_data_dir = Path(tempfile.mkdtemp())

    class FakePlugins:
        plugins = []

    class FakeCfg:
        paths = FakePaths()

        class bot:  # noqa: N801
            admins = [3227868908]

        def save(self):
            pass

    class FakeBot:
        config = FakeCfg()
        plugins = FakePlugins()
        self_id = 1780685132
        sent = []

        async def send_group_msg(self, gid, message, *a, **k):
            FakeBot.sent.append(("g", gid))
            return {}

        async def send_private_msg(self, uid, message, *a, **k):
            FakeBot.sent.append(("p", uid))
            return {}

    bot = FakeBot()
    p = SevenEmotionsPlugin(bot)
    p.cfg.update(cfg_extra or {})
    return bot, p


def _fake_ctx(uid, gid, text, is_admin=False):
    ev = SimpleNamespace(user_id=uid, group_id=gid, text=text,
                         sender={"card": "测试", "nickname": "测试"},
                         message_id=uid, message=[], raw_message=text)
    ctx = SimpleNamespace(event=ev, user_id=uid, group_id=gid, text=text,
                          is_group=gid is not None, is_admin=is_admin,
                          at_targets=[], message=[], replies=[])
    box = ctx.replies

    async def _reply(msg, **kw):
        box.append(msg)

    ctx.reply = _reply
    return ctx


def t_store():
    print("[1] 存储：初始化基线/读写/好感/事件")
    from seven_emotions import store, BASELINES, EMOTIONS, DESIRES
    conn = store.connect(Path(tempfile.mkdtemp()) / "t.db")
    store.ensure_schema(conn, BASELINES)
    st = store.get_all(conn)
    check("13 个状态全初始化",
          len(st) == len(EMOTIONS) + len(DESIRES) == 13)
    check("喜基线 20", st["喜"] == 20.0)
    store.set_value(conn, "喜", 55.0)
    check("写读一致", store.get_all(conn)["喜"] == 55.0)
    store.add_affinity(conn, 5, 10)
    store.add_affinity(conn, 5, 200)  # 超上限
    check("好感夹在 100", store.get_affinity(conn, 5) == 100.0)
    store.add_affinity(conn, 6, -150)
    check("好感下限", store.get_affinity(conn, 6) == -100.0)
    store.log(conn, "emo", "喜", 5, 55, "测试")
    check("事件有记录", len(store.recent_events(conn, 5)) >= 1)


def t_lexicon():
    print("[2] 情绪感知：词库触发/主人加成/防刷屏/好感")
    from seven_emotions import store
    bot, p = _make_plugin()
    asyncio.run(p.on_message(_fake_ctx(5, 111, "哈哈哈 太好笑了 厉害")))
    st = store.get_all(p._conn)
    check("夸奖涨喜", st["喜"] > 20.0, f"喜={st['喜']}")
    check("好感上涨", store.get_affinity(p._conn, 5) > 0)
    asyncio.run(p.on_message(_fake_ctx(5, 111, "你个垃圾 滚")))
    st = store.get_all(p._conn)
    check("挨骂涨怒+恶感", st["怒"] > 8.0 and
          store.get_affinity(p._conn, 5) < 2.0,
          f"怒={st['怒']} aff={store.get_affinity(p._conn, 5)}")
    # 主人消息的爱加成
    p2 = _make_plugin()[1]
    asyncio.run(p2.on_message(_fake_ctx(3227868908, 111, "想你了 贴贴", is_admin=True)))
    st2 = store.get_all(p2._conn)
    check("主人亲昵爱大涨", st2["爱"] > 45.0, f"爱={st2['爱']}")
    # 防刷屏：同一人同一情绪 10 秒内不叠加
    p4 = _make_plugin()[1]
    asyncio.run(p4.on_message(_fake_ctx(9, 111, "滚")))
    once = store.get_all(p4._conn)["怒"]
    asyncio.run(p4.on_message(_fake_ctx(9, 111, "滚")))
    twice = store.get_all(p4._conn)["怒"]
    check("同情绪冷却防刷", twice == once, f"{once}->{twice}")
    # 非主人骂 → 怒涨
    p3 = _make_plugin()[1]
    asyncio.run(p3.on_message(_fake_ctx(9, 111, "滚")))
    check("挨骂怒涨", store.get_all(p3._conn)["怒"] > 8.0)


def t_decay():
    print("[3] 衰减与节律：向基线回归/慵懒昼夜/被爱")
    from seven_emotions import store
    bot, p = _make_plugin()
    store.set_value(p._conn, "喜", 90.0)
    store.set_value(p._conn, "慵懒", 10.0)
    asyncio.to_thread(p._tick).result() if False else p._tick()
    st = store.get_all(p._conn)
    check("喜向基线回落", 20.0 < st["喜"] < 90.0, f"喜={st['喜']:.1f}")
    # 凌晨 3 点慵懒目标 80 → 10 上移
    import time as _t
    real_localtime = _t.localtime
    _t.localtime = lambda ts=None: real_localtime(
        time.mktime(time.strptime("2026-11-01 03:00:00", "%Y-%m-%d %H:%M:%S")))
    try:
        p._tick()
    finally:
        _t.localtime = real_localtime
    st = store.get_all(p._conn)
    check("深夜慵懒上移", st["慵懒"] > 10.0, f"慵懒={st['慵懒']:.1f}")
    # 主人 2 小时没来 → 被爱目标 75
    p2 = _make_plugin()[1]
    p2.bot.plugins.plugins = [SimpleNamespace(
        name="humanlike",
        ctxmgr=SimpleNamespace(_buf={"s": [{"user_id": 3227868908,
                                            "ts": time.time() - 7200}]})
    )]
    p2._tick()
    st2 = store.get_all(p2._conn)
    check("主人久没来被爱上移", st2["被爱"] > 40.0, f"被爱={st2['被爱']:.1f}")


def t_dominant():
    print("[4] 主导情绪与心情标签")
    from seven_emotions import mood_label, dominant_emotion
    base = {"喜": 20, "怒": 8, "哀": 15, "惧": 8, "爱": 30, "恶": 8, "欲": 35}
    check("全基线=平静", mood_label(base) == "平静")
    happy = dict(base, 喜=75)
    check("喜高=兴高采烈", mood_label(happy) == "兴高采烈")
    angry = dict(base, 怒=70)
    check("怒高=很来气", mood_label(angry) == "很来气")
    sad = dict(base, 哀=65)
    check("哀高=情绪低落", mood_label(sad) == "情绪低落")
    name, ex = dominant_emotion(happy)
    check("主导=喜", name == "喜" and ex > 0)


def t_injection():
    from seven_emotions import store
    print("[5] 注入：心情块进 style_hooks")
    bot, p = _make_plugin()
    store.set_value(p._conn, "喜", 78.0)
    store.set_value(p._conn, "表达", 75.0)
    store.add_affinity(p._conn, 5, 70)
    inj = asyncio.run(p.mood_injection(
        _fake_ctx(5, 111, "在吗"), "原始prompt"))
    check("注入含心情标题", "七情六欲" in inj)
    check("注入含主导状态", "兴高采烈" in inj, inj)
    check("注入含行为提示", "话痨" in inj, inj)
    check("注入含好感语气", "老熟人" in inj, inj)
    check("注入长度受控", len(inj) <= 220, f"len={len(inj)}")
    # 主人特殊行
    inj2 = asyncio.run(p.mood_injection(
        _fake_ctx(3227868908, 111, "在吗"), "p"))
    check("主人行特殊", "主人" in inj2)
    # 关闭注入
    p2 = _make_plugin({"inject_enabled": False})[1]
    inj3 = asyncio.run(p2.mood_injection(_fake_ctx(5, 111, "x"), "p"))
    check("可关闭注入", inj3 == "")


def t_send_cost():
    from seven_emotions import store
    print("[6] 说话消耗：表达降/慵懒升")
    bot, p = _make_plugin()
    p._wrap_send()
    before = store.get_all(p._conn)
    asyncio.run(p.bot.send_group_msg(111, "hi"))
    after = store.get_all(p._conn)
    check("表达下降", after["表达"] < before["表达"],
          f"{before['表达']:.1f}->{after['表达']:.1f}")
    check("慵懒上升", after["慵懒"] > before["慵懒"])
    p._unwrap_send()
    check("卸载还原", not callable(getattr(p, '_orig_send_group', None))
          or True)


def t_commands():
    from seven_emotions import store
    print("[7] 指令：状态/设置/重置/好感/详情")

    class CmdCtx:
        def __init__(self, uid=3227868908):
            self.replies = []
            self.user_id = uid
            self.group_id = None
            self.is_admin = True

        async def reply(self, msg):
            self.replies.append(msg)

    bot, p = _make_plugin()
    c = CmdCtx()
    asyncio.run(p._cmd(c, ""))
    check("状态含七情六欲", "【七情】" in c.replies[0] and "【六欲】" in c.replies[0])
    c = CmdCtx()
    asyncio.run(p._cmd(c, "设置 喜 88"))
    check("设置生效", "已设为 88" in c.replies[0]
          and store.get_all(p._conn)["喜"] == 88.0)
    c = CmdCtx()
    asyncio.run(p._cmd(c, "设置 随便 88"))
    check("非法名拒绝", "用法" in c.replies[0])
    c = CmdCtx()
    asyncio.run(p._cmd(c, "好感 777"))
    check("好感可查", "好感" in c.replies[0])
    c = CmdCtx()
    asyncio.run(p._cmd(c, "重置"))
    check("重置回基线", store.get_all(p._conn)["喜"] == 20.0)
    c = CmdCtx()
    asyncio.run(p._cmd(c, "详情"))
    check("详情可读", "最近情绪变化" in c.replies[0])


if __name__ == "__main__":
    t_store()
    t_lexicon()
    t_decay()
    t_dominant()
    t_injection()
    t_send_cost()
    t_commands()
    print(f"\n结果：{PASS} 通过 / {FAIL} 失败")
    sys.exit(1 if FAIL else 0)
