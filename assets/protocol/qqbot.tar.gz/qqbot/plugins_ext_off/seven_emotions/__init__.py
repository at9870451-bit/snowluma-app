"""QQBot SevenEmotions 七情六欲插件 v1.0.0

给菲比一套多维情绪引擎：
  七情（喜/怒/哀/惧/爱/恶/欲）：词库触发 + 事件驱动，随时间向基线衰减
  六欲（表达/求知/玩乐/分享/被爱/慵懒）：节律驱动的内在动机，影响说话状态
  好感：每用户独立积累（主人消息/夸奖涨，挨骂跌），影响对 TA 的语气

输出方式：
  - style_hooks 注入【七情六欲】状态块（心情主导色 + 欲望状态 + 对 TA 的感觉 +
    行为指引），模型据此调整语气/长度/积极性
  - bot 每发一条消息：表达欲-2、慵懒+0.6、分享+0.8（说话是消耗）
  - 每 5 分钟节拍：情绪向基线回归 6%、欲望向动态目标回归 8%、随机漂移 ±2、
    昼夜节律（深夜慵懒高、饭点食欲类话题敏感）

与 emotion 插件关系：emotion（单值心情+记仇）照常运行；本插件是更高维的状态层，
只读共存，不写对方数据。

管理员指令：/mood（心情）｜/mood 详情｜/mood 设置 <名> <值>｜/mood 重置｜
            /mood 好感 <QQ>
"""

from __future__ import annotations

import asyncio
import random
import re
import time
from pathlib import Path
from typing import Any

from qqbot.core.bus import STOP
from qqbot.plugins.base import Plugin

from . import store

# ---------------- 七情六欲定义 ----------------

EMOTIONS = {"喜": 20.0, "怒": 8.0, "哀": 15.0, "惧": 8.0,
            "爱": 30.0, "恶": 8.0, "欲": 35.0}
DESIRES = {"表达": 50.0, "求知": 40.0, "玩乐": 45.0,
           "分享": 40.0, "被爱": 40.0, "慵懒": 30.0}
BASELINES = {**EMOTIONS, **DESIRES}
ALL_NAMES = list(BASELINES.keys())

# 词库：命中即推情绪（值=单次增量）
LEXICONS: dict[str, tuple[str, ...]] = {
    "喜": ("谢谢", "哈哈", "嘻嘻", "厉害", "牛", "棒", "可爱", "开心", "好玩",
           "赞", "666", "搞笑", "乐死", "太好了", "支持"),
    "怒": ("滚", "傻逼", "sb", "垃圾", "闭嘴", "白痴", "蠢", "烦你", "讨厌你",
           "废物", "神经病", "滚蛋", "有病"),
    "哀": ("难过", "伤心", "哭", "呜呜", "累死", "emo", "抑郁", "分手", "加班",
           "委屈", "心痛", "烦死了", "失眠"),
    "惧": ("鬼", "恐怖", "吓死", "灵异", "惊悚", "噩梦", "好怕", "吓人"),
    "爱": ("亲亲", "抱抱", "爱你", "想你", "宝贝", "贴贴", "蹭", "喜欢菲比",
           "小菲比", "么么"),
    "恶": ("恶心", "呕", "屎", "便", "尿", "蛆", "腐烂", "腥", "臭"),
    "欲": ("饿", "馋", "吃", "喝", "奶茶", "火锅", "烧烤", "外卖", "夜宵",
           "好吃", "困", "想睡"),
}

_PLAY_WORDS = ("游戏", "开黑", "玩", "梗", "乐子", "整活", "段子", "电竞")

# 昼夜节律：小时 → 慵懒目标
_LAZY_TARGET = {**{h: 80.0 for h in range(0, 7)},
                7: 40, 8: 35, 9: 30, 10: 25, 11: 25, 12: 40,
                13: 55, 14: 50, 15: 35, 16: 30, 17: 30, 18: 30,
                19: 30, 20: 32, 21: 40, 22: 55, 23: 68}

_TICK_INTERVAL = 300  # 5 分钟


def _clamp(v: float, lo: float = 0.0, hi: float = 100.0) -> float:
    return max(lo, min(hi, v))


def dominant_emotion(states: dict[str, float]) -> tuple[str, float]:
    """主导情绪：超出基线最多的那种。"""
    best, best_ex = "平", 0.0
    for name, base in EMOTIONS.items():
        ex = states.get(name, base) - base
        if ex > best_ex:
            best, best_ex = name, ex
    return best, best_ex


def mood_label(states: dict[str, float]) -> str:
    name, _ = dominant_emotion(states)
    v = states.get(name, 0)
    if name == "平":
        return "平静"
    if name == "喜":
        return "兴高采烈" if v >= 70 else "挺开心" if v >= 45 else "心情不错"
    if name == "怒":
        return "很来气" if v >= 65 else "有点火" if v >= 40 else "微微不爽"
    if name == "哀":
        return "情绪低落" if v >= 60 else "有点丧" if v >= 40 else "略带忧郁"
    if name == "惧":
        return "有点怕怕" if v >= 45 else "隐隐不安"
    if name == "爱":
        return "心里暖暖的" if v >= 50 else "有点想人"
    if name == "恶":
        return "有点反感" if v >= 45 else "微微不适"
    return "平静"


def desire_notes(states: dict[str, float]) -> list[str]:
    """欲望 → 行为提示（最多 2 条）。"""
    notes: list[str] = []
    if states.get("表达", 50) >= 70:
        notes.append("话痨模式：可以多说两句，主动接话题")
    elif states.get("表达", 50) <= 25:
        notes.append("不太想说话：回复短一点、随意一点")
    if states.get("慵懒", 30) >= 70:
        notes.append("犯懒：语气可以带点敷衍和躺平感")
    if states.get("被爱", 40) >= 70:
        notes.append("有点想找人聊：可以主动一点")
    if states.get("求知", 40) >= 65:
        notes.append("好奇心强：可以多追问细节")
    if states.get("玩乐", 45) >= 65:
        notes.append("想玩：可以接梗、开玩笑")
    return notes[:2]


def affinity_tone(score: float) -> str:
    if score >= 60:
        return "老熟人，语气可以亲昵随意"
    if score >= 20:
        return "聊得来的朋友，自然一点"
    if score <= -30:
        return "这人老惹你，保持距离感，别热络"
    if score <= -10:
        return "有点烦这个人，客气但冷淡"
    return "普通群友，正常聊"


class SevenEmotionsPlugin(Plugin):
    name = "seven_emotions"
    display_name = "七情六欲"
    version = "1.0.0"
    description = ("七情（喜怒哀惧爱恶欲）+ 六欲（表达/求知/玩乐/分享/被爱/慵懒）"
                   "多维情绪引擎：词库触发、昼夜节律、好感系统，注入回复状态")
    priority = 16  # 早于 social_pro(18)/bot_teacher(19)/humanlike(20)：先更新情绪

    default_config = {
        "enabled": True,
        "tick_seconds": _TICK_INTERVAL,
        "emotion_decay": 0.06,     # 每拍向基线回归比例
        "desire_decay": 0.08,
        "drift": 2.0,              # 每拍随机漂移幅度
        "master_bonus": 2.0,       # 主人消息的爱加成倍数
        "aff_praise": 2.0,         # 夸奖好感增量
        "aff_insult": -5.0,        # 挨骂好感增量
        "reply_expression_cost": 2.0,  # bot 每条消息的表达消耗
        "inject_enabled": True,
        "inject_max_chars": 200,
        "spam_cooldown": 10,       # 同人同情绪加成冷却（秒）
    }

    config_labels = {
        "enabled": "启用七情六欲",
        "emotion_decay": "情绪衰减（每拍比例）",
        "desire_decay": "欲望衰减（每拍比例）",
        "inject_enabled": "注入心情状态到回复",
        "master_bonus": "主人消息爱加成倍数",
    }

    def __init__(self, bot) -> None:
        super().__init__(bot)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self._conn = store.connect(self.data_dir / "emo.sqlite3")
        store.ensure_schema(self._conn, BASELINES)
        self._last_hit: dict[tuple[int, str], float] = {}  # (uid, emo) -> ts
        self._tick_task: asyncio.Task | None = None
        self._orig_send_group = None
        self._orig_send_private = None

    # ---------- 生命周期 ----------

    async def on_load(self) -> None:
        if not self.cfg_get("enabled", True):
            return
        hooks = getattr(self.bot, "style_hooks", None)
        if hooks is None:
            hooks = []
            self.bot.style_hooks = hooks
        if self.mood_injection not in hooks:
            hooks.append(self.mood_injection)
        self.add_command("mood", self._cmd, aliases=("心情",),
                         admin=True, description="七情六欲：状态/详情/设置/重置")
        self._wrap_send()
        self._tick_task = asyncio.get_running_loop().create_task(self._tick_loop())
        st = store.get_all(self._conn)
        self.log.info("七情六欲已启用（心情=%s）", mood_label(st))

    async def on_unload(self) -> None:
        if self._tick_task:
            self._tick_task.cancel()
        hooks = getattr(self.bot, "style_hooks", None)
        if hooks and self.mood_injection in hooks:
            hooks.remove(self.mood_injection)
        self._unwrap_send()

    # ---------- 消息入口：情绪触发 ----------

    async def on_message(self, ctx) -> Any:
        if not self.cfg_get("enabled", True):
            return None
        m = self._norm(ctx)
        if not m["text"] or not m["user_id"]:
            return None
        try:
            self._sense(m)
        except Exception as exc:  # noqa: BLE001
            self.log.debug("情绪感知失败: %s", exc)
        return None  # 只感知，不拦截不回复

    def _sense(self, m: dict[str, Any]) -> None:
        now = time.time()
        uid = m["user_id"]
        is_master = uid in self._master_uins()
        text = m["text"].lower()
        states = store.get_all(self._conn)
        cd = max(1, int(self.cfg_get("spam_cooldown", 10)))

        for emo, words in LEXICONS.items():
            hits = sum(1 for w in words if w in text)
            if not hits:
                continue
            key = (uid, emo)
            if now - self._last_hit.get(key, 0) < cd:
                continue
            self._last_hit[key] = now
            delta = min(30.0, 6.0 + 2.0 * (hits - 1))
            if emo == "爱" and is_master:
                delta *= max(1.0, float(self.cfg_get("master_bonus", 2.0)))
            self._bump(emo, delta, f"uid{uid} {m['text'][:16]}")

        # 问句 → 求知欲
        if re.search(r"什么|怎么|为什么|如何|多少|吗[??]?|？|\?", m["text"]):
            self._bump("求知", 3.0, "问句")
        # 玩乐词 → 玩乐欲
        if any(w in text for w in _PLAY_WORDS):
            self._bump("玩乐", 2.5, "玩乐话题")
        # 群里热闹 → 表达欲（简版：长文本/感叹号多=活跃）
        if "!" in m["text"] or "！" in m["text"]:
            self._bump("表达", 1.5, "热烈气氛")

        # 好感：骂人跌、夸人涨
        if any(w in text for w in LEXICONS["怒"]):
            store.add_affinity(self._conn, uid,
                               float(self.cfg_get("aff_insult", -5.0)))
            store.log(self._conn, "aff", f"aff:{uid}",
                      float(self.cfg_get("aff_insult", -5.0)), 0, "挨骂")
        elif any(w in text for w in LEXICONS["喜"][:6]):
            store.add_affinity(self._conn, uid,
                               float(self.cfg_get("aff_praise", 2.0)))

    def _bump(self, name: str, delta: float, detail: str = "") -> float:
        states = store.get_all(self._conn)
        old = states.get(name, BASELINES.get(name, 50))
        new = _clamp(old + delta)
        if abs(new - old) < 0.01:
            return old
        store.set_value(self._conn, name, new)
        kind = "emo" if name in EMOTIONS else "desire"
        store.log(self._conn, kind, name, new - old, new, detail)
        return new

    def _master_uins(self) -> list[int]:
        try:
            return [int(a) for a in (self.bot.config.bot.admins or [])]
        except (TypeError, ValueError):
            return []

    # ---------- bot 发消息：表达消耗 ----------

    def _wrap_send(self) -> None:
        self._orig_send_group = self.bot.send_group_msg
        self._orig_send_private = self.bot.send_private_msg
        plugin = self

        async def wrapped_group(gid, message, *a, **k):
            plugin._on_self_send()
            return await plugin._orig_send_group(gid, message, *a, **k)

        async def wrapped_private(uid, message, *a, **k):
            plugin._on_self_send()
            return await plugin._orig_send_private(uid, message, *a, **k)

        self.bot.send_group_msg = wrapped_group
        self.bot.send_private_msg = wrapped_private

    def _unwrap_send(self) -> None:
        try:
            if self._orig_send_group:
                self.bot.send_group_msg = self._orig_send_group
            if self._orig_send_private:
                self.bot.send_private_msg = self._orig_send_private
        except Exception:
            pass

    def _on_self_send(self) -> None:
        try:
            cost = float(self.cfg_get("reply_expression_cost", 2.0))
            self._bump("表达", -cost, "自己说话")
            self._bump("慵懒", 0.6, "说话消耗")
            self._bump("分享", 0.8, "分享了")
        except Exception:
            pass

    # ---------- 节拍：衰减 / 节律 / 漂移 ----------

    async def _tick_loop(self) -> None:
        await asyncio.sleep(15)
        while True:
            try:
                await asyncio.to_thread(self._tick)
            except asyncio.CancelledError:
                raise
            except Exception as exc:  # noqa: BLE001
                self.log.warning("情绪节拍异常: %s", exc)
            await asyncio.sleep(max(30, int(self.cfg_get("tick_seconds",
                                                         _TICK_INTERVAL))))

    def _tick(self) -> None:
        edec = float(self.cfg_get("emotion_decay", 0.06))
        ddec = float(self.cfg_get("desire_decay", 0.08))
        drift = float(self.cfg_get("drift", 2.0))
        states = store.get_all(self._conn)
        hour = time.localtime().tm_hour

        for name, base in EMOTIONS.items():
            cur = states.get(name, base)
            new = _clamp(cur + (base - cur) * edec
                         + random.uniform(-drift, drift))
            if abs(new - cur) >= 0.05:
                store.set_value(self._conn, name, new)

        for name, base in DESIRES.items():
            cur = states.get(name, base)
            if name == "慵懒":
                target = float(_LAZY_TARGET.get(hour, 40))
            elif name == "被爱":
                # 主人 2 小时没来 → 涨想被关注
                target = 75.0 if self._master_idle_hours() >= 2 else base
            else:
                target = base
            new = _clamp(cur + (target - cur) * ddec
                         + random.uniform(-drift / 2, drift / 2))
            if abs(new - cur) >= 0.05:
                store.set_value(self._conn, name, new)

    def _master_idle_hours(self) -> float:
        """主人多久没说话了（从 emotion/humanlike 拿不到就退化为 0）。"""
        try:
            for p in self.bot.plugins.plugins:
                if getattr(p, "name", "") == "humanlike":
                    buf = getattr(p.ctxmgr, "_buf", {})
                    masters = self._master_uins()
                    latest = 0.0
                    for items in buf.values():
                        for it in items:
                            if it.get("user_id") in masters:
                                latest = max(latest, it.get("ts", 0))
                    return max(0.0, (time.time() - latest) / 3600) if latest else 9.9
        except Exception:
            pass
        return 0.0

    # ---------- 注入 ----------

    async def mood_injection(self, ctx, prompt: str) -> str:
        if not self.cfg_get("inject_enabled", True):
            return ""
        try:
            m = self._norm(ctx)
            states = store.get_all(self._conn)
            label = mood_label(states)
            notes = desire_notes(states)
            aff = store.get_affinity(self._conn, m["user_id"]) \
                if m["user_id"] else 0.0
            is_master = m["user_id"] in self._master_uins()
            top = " ".join(f"{n}{int(states.get(n, BASELINES[n]))}"
                           for n in EMOTIONS)
            lines = [f"【七情六欲·现在的心情】{label}（{top}）"]
            if notes:
                lines.append("状态：" + "；".join(notes))
            if is_master:
                lines.append("对TA：这是主人，心里一直有位置（好感拉满）")
            else:
                lines.append(f"对TA：{affinity_tone(aff)}")
            out = "\n".join(lines)
            return out[:int(self.cfg_get("inject_max_chars", 200))]
        except Exception:
            return ""

    # ---------- 指令 ----------

    async def _cmd(self, ctx, args: str) -> Any:
        a = (args or "").strip()
        head, _, rest = a.partition(" ")
        rest = rest.strip()

        states = store.get_all(self._conn)

        if head in ("", "状态", "心情"):
            emo_line = " ".join(f"{n}{int(states.get(n, 0))}" for n in EMOTIONS)
            des_line = " ".join(f"{n}{int(states.get(n, 0))}" for n in DESIRES)
            m = self._norm(ctx)
            aff = store.get_affinity(self._conn, m["user_id"])
            await self._reply(ctx, "\n".join([
                f"【七情】{emo_line}",
                f"【六欲】{des_line}",
                f"心情：{mood_label(states)}",
                f"对我的好感：{int(aff)}（{affinity_tone(aff)}）",
            ]))
            return self.stop()

        if head == "详情":
            evs = store.recent_events(self._conn, 10)
            lines = ["最近情绪变化："] + [
                f"{time.strftime('%H:%M', time.localtime(e['ts']))} "
                f"{e['name']} {e['delta']:+.1f} → {e['value']:.0f} "
                f"{e['detail']}" for e in evs]
            await self._reply(ctx, "\n".join(lines))
            return self.stop()

        if head == "设置" and rest:
            parts = rest.split()
            if len(parts) >= 2 and parts[0] in ALL_NAMES:
                try:
                    v = _clamp(float(parts[1]))
                except ValueError:
                    await self._reply(ctx, "值要是个数字（0~100）")
                    return self.stop()
                store.set_value(self._conn, parts[0], v)
                await self._reply(ctx, f"{parts[0]} 已设为 {v:.0f}")
                return self.stop()
            await self._reply(ctx, "用法：/mood 设置 <" + "/".join(ALL_NAMES) + "> <0~100>")
            return self.stop()

        if head == "重置":
            for name, base in BASELINES.items():
                store.set_value(self._conn, name, base)
            await self._reply(ctx, "所有情绪已重置到基线。")
            return self.stop()

        if head == "好感" and rest.isdigit():
            v = store.get_affinity(self._conn, int(rest))
            await self._reply(ctx, f"QQ {rest} 好感：{int(v)}（{affinity_tone(v)}）")
            return self.stop()

        await self._reply(ctx, "用法：/mood（看心情）｜详情｜设置 <名> <值>｜"
                               "重置｜好感 <QQ>")
        return self.stop()

    # ---------- 工具 ----------

    async def _reply(self, ctx, message: str) -> None:
        try:
            await ctx.reply(message)
        except Exception as exc:  # noqa: BLE001
            self.log.warning("回复失败: %s", exc)

    def _norm(self, ctx) -> dict[str, Any]:
        event = getattr(ctx, "event", ctx)
        sender = getattr(event, "sender", None) or {}
        try:
            uid = int(getattr(event, "user_id", 0) or 0)
        except (TypeError, ValueError):
            uid = 0
        gid = getattr(event, "group_id", None)
        try:
            gid = int(gid) if gid else None
        except (TypeError, ValueError):
            gid = None
        return {
            "user_id": uid,
            "group_id": gid,
            "is_group": gid is not None,
            "text": str(getattr(event, "text", "") or "").strip(),
            "is_admin": bool(getattr(ctx, "is_admin", False)),
        }
