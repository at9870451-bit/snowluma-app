"""seven_emotions store — 七情六欲持久化（SQLite）。

states: 每种情绪/欲望一行（value 0~100）
affinity: 每用户好感（-100~100）
events: 情绪变化流水（审计/调参用）
"""

from __future__ import annotations

import sqlite3
import time
from pathlib import Path

SCHEMA = """
CREATE TABLE IF NOT EXISTS states(
  name TEXT PRIMARY KEY,
  value REAL NOT NULL,
  updated_at REAL
);
CREATE TABLE IF NOT EXISTS affinity(
  user_id INTEGER PRIMARY KEY,
  score REAL NOT NULL DEFAULT 0,
  updated_at REAL
);
CREATE TABLE IF NOT EXISTS events(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ts REAL,
  kind TEXT,          -- emo / desire / aff
  name TEXT,          -- 喜/怒/…/表达/…/aff:<uid>
  delta REAL,
  value REAL,
  detail TEXT
);
"""


def connect(path: Path) -> sqlite3.Connection:
    conn = sqlite3.connect(str(path), check_same_thread=False, timeout=10)
    conn.row_factory = sqlite3.Row
    return conn


def ensure_schema(conn: sqlite3.Connection, baselines: dict[str, float]) -> None:
    conn.executescript(SCHEMA)
    now = time.time()
    for name, base in baselines.items():
        conn.execute(
            "INSERT OR IGNORE INTO states(name, value, updated_at) VALUES(?,?,?)",
            (name, base, now))
    conn.commit()


def get_all(conn: sqlite3.Connection) -> dict[str, float]:
    return {r["name"]: float(r["value"])
            for r in conn.execute("SELECT name, value FROM states")}


def set_value(conn: sqlite3.Connection, name: str, value: float) -> None:
    conn.execute(
        "INSERT INTO states(name, value, updated_at) VALUES(?,?,?) "
        "ON CONFLICT(name) DO UPDATE SET value=?, updated_at=?",
        (name, value, time.time(), value, time.time()))
    conn.commit()


def log(conn: sqlite3.Connection, kind: str, name: str, delta: float,
        value: float, detail: str = "") -> None:
    conn.execute(
        "INSERT INTO events(ts, kind, name, delta, value, detail)"
        " VALUES(?,?,?,?,?,?)",
        (time.time(), kind, name, delta, value, detail))
    conn.commit()


def get_affinity(conn: sqlite3.Connection, user_id: int) -> float:
    row = conn.execute("SELECT score FROM affinity WHERE user_id=?",
                       (int(user_id),)).fetchone()
    return float(row["score"]) if row else 0.0


def add_affinity(conn: sqlite3.Connection, user_id: int, delta: float,
                 lo: float = -100, hi: float = 100) -> float:
    cur = max(lo, min(hi, get_affinity(conn, user_id) + delta))
    conn.execute(
        "INSERT INTO affinity(user_id, score, updated_at) VALUES(?,?,?) "
        "ON CONFLICT(user_id) DO UPDATE SET score=?, updated_at=?",
        (int(user_id), cur, time.time(), cur, time.time()))
    conn.commit()
    return cur


def recent_events(conn: sqlite3.Connection, n: int = 10) -> list[dict]:
    rows = conn.execute(
        "SELECT ts, kind, name, delta, value, detail FROM events"
        " ORDER BY id DESC LIMIT ?", (n,)).fetchall()
    return [dict(r) for r in rows]
